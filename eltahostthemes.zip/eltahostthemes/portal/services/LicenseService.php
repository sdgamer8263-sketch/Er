<?php

namespace Pterodactyl\Services\Addons;

use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class LicenseService
{
    /**
     * License server URL
     */
    protected string $licenseServer = 'https://license.eltahost.com/api/v1';

    /**
     * Cache key for license data
     */
    protected string $cacheKey = 'eltahost_license';

    /**
     * Grace period in days when license server is unreachable
     */
    protected int $gracePeriodDays = 15;

    /**
     * Validate the license key
     */
    public function validate(string $licenseKey): array
    {
        // Check cache first
        $cached = $this->getCachedLicense();
        if ($cached && $cached['valid'] && !$this->isExpiringSoon($cached)) {
            return $cached;
        }

        try {
            $response = Http::timeout(10)->post("{$this->licenseServer}/validate", [
                'license_key' => $licenseKey,
                'domain' => request()->getHost(),
                'ip' => request()->ip(),
                'product' => 'neon-gaming-panel',
                'version' => config('theme.version', '1.0.0'),
            ]);

            if ($response->successful()) {
                $data = $response->json();

                if ($data['valid'] ?? false) {
                    $licenseData = [
                        'valid' => true,
                        'license_key' => $licenseKey,
                        'type' => $data['type'] ?? 'standard',
                        'expires_at' => $data['expires_at'] ?? null,
                        'features' => $data['features'] ?? [],
                        'domains' => $data['domains'] ?? [],
                        'validated_at' => now()->toIso8601String(),
                        'grace_until' => null,
                    ];

                    $this->cacheLicense($licenseData);
                    return $licenseData;
                }

                return [
                    'valid' => false,
                    'error' => $data['message'] ?? 'Invalid license key',
                ];
            }

            // Server returned error - check grace period
            return $this->handleServerError($licenseKey, 'Server returned error');

        } catch (\Exception $e) {
            Log::warning('License validation failed', [
                'error' => $e->getMessage(),
            ]);

            // Network error - check grace period
            return $this->handleServerError($licenseKey, $e->getMessage());
        }
    }

    /**
     * Handle server errors with grace period
     */
    protected function handleServerError(string $licenseKey, string $error): array
    {
        $cached = $this->getCachedLicense();

        // If we have a valid cached license, use grace period
        if ($cached && $cached['valid']) {
            $graceUntil = $cached['grace_until'] ?? now()->addDays($this->gracePeriodDays)->toIso8601String();

            if (now()->lt(Carbon::parse($graceUntil))) {
                // Still within grace period
                $cached['grace_until'] = $graceUntil;
                $cached['grace_mode'] = true;
                $cached['grace_reason'] = $error;
                $this->cacheLicense($cached);

                return $cached;
            }
        }

        return [
            'valid' => false,
            'error' => 'Unable to validate license and grace period expired',
            'grace_expired' => true,
        ];
    }

    /**
     * Check if license is expiring soon (within 7 days)
     */
    protected function isExpiringSoon(array $license): bool
    {
        if (empty($license['expires_at'])) {
            return false; // Lifetime license
        }

        $expiresAt = Carbon::parse($license['expires_at']);
        return $expiresAt->diffInDays(now()) <= 7;
    }

    /**
     * Get cached license data
     */
    public function getCachedLicense(): ?array
    {
        return Cache::get($this->cacheKey);
    }

    /**
     * Cache license data
     */
    protected function cacheLicense(array $data): void
    {
        // Cache for 24 hours
        Cache::put($this->cacheKey, $data, now()->addHours(24));
    }

    /**
     * Clear cached license
     */
    public function clearCache(): void
    {
        Cache::forget($this->cacheKey);
    }

    /**
     * Check if a feature is enabled
     */
    public function hasFeature(string $feature): bool
    {
        $license = $this->getCachedLicense();

        if (!$license || !$license['valid']) {
            return false;
        }

        // All features for enterprise licenses
        if (($license['type'] ?? 'standard') === 'enterprise') {
            return true;
        }

        return in_array($feature, $license['features'] ?? []);
    }

    /**
     * Get license status for display
     */
    public function getStatus(): array
    {
        $license = $this->getCachedLicense();

        if (!$license) {
            return [
                'status' => 'unlicensed',
                'message' => 'No license configured',
                'color' => 'red',
            ];
        }

        if (!$license['valid']) {
            return [
                'status' => 'invalid',
                'message' => $license['error'] ?? 'Invalid license',
                'color' => 'red',
            ];
        }

        if ($license['grace_mode'] ?? false) {
            $graceUntil = Carbon::parse($license['grace_until']);
            $daysLeft = now()->diffInDays($graceUntil);

            return [
                'status' => 'grace_period',
                'message' => "License server unreachable. {$daysLeft} days remaining in grace period.",
                'color' => 'yellow',
                'grace_until' => $license['grace_until'],
            ];
        }

        if (!empty($license['expires_at'])) {
            $expiresAt = Carbon::parse($license['expires_at']);

            if ($expiresAt->isPast()) {
                return [
                    'status' => 'expired',
                    'message' => 'License has expired',
                    'color' => 'red',
                    'expired_at' => $license['expires_at'],
                ];
            }

            $daysLeft = now()->diffInDays($expiresAt);
            if ($daysLeft <= 7) {
                return [
                    'status' => 'expiring_soon',
                    'message' => "License expires in {$daysLeft} days",
                    'color' => 'yellow',
                    'expires_at' => $license['expires_at'],
                ];
            }
        }

        return [
            'status' => 'active',
            'message' => 'License is active',
            'color' => 'green',
            'type' => $license['type'] ?? 'standard',
            'expires_at' => $license['expires_at'] ?? null,
        ];
    }

    /**
     * Soft-disable features when license is invalid
     * Returns false only for premium features, keeps basic functionality
     */
    public function shouldDisableFeature(string $feature): bool
    {
        $license = $this->getCachedLicense();

        // Always allow basic features
        $basicFeatures = [
            'dashboard',
            'server_list',
            'console',
            'files',
            'backups',
        ];

        if (in_array($feature, $basicFeatures)) {
            return false; // Never disable basic features
        }

        // Check license validity
        if (!$license || !$license['valid']) {
            return true; // Disable premium features
        }

        // Check feature availability
        return !$this->hasFeature($feature);
    }
}
