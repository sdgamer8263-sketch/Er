/**
 * NEON GAMING PANEL - Theme Injector
 * Applies the gaming theme to Pterodactyl Panel
 */

(function() {
    'use strict';

    const THEME_VERSION = '1.0.0';
    const THEME_NAME = 'Neon Gaming Panel';

    // Theme configuration
    const config = {
        enableAnimations: true,
        enableGlowEffects: true,
        enableParticles: false, // Performance option
        sidebarCollapsed: false,
        debugMode: false
    };

    // Initialize theme
    function init() {
        log('Initializing ' + THEME_NAME + ' v' + THEME_VERSION);

        // Wait for DOM
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', applyTheme);
        } else {
            applyTheme();
        }

        // Watch for React route changes
        observeDOMChanges();
    }

    // Apply theme styles and modifications
    function applyTheme() {
        log('Applying theme...');

        // Add theme class to body
        document.body.classList.add('neon-gaming-theme');
        document.documentElement.setAttribute('data-theme', 'neon-gaming');

        // Inject critical overrides
        injectCriticalStyles();

        // Enhance existing elements
        enhanceElements();

        // Setup event listeners
        setupEventListeners();

        log('Theme applied successfully');
    }

    // Inject critical CSS overrides
    function injectCriticalStyles() {
        if (document.getElementById('neon-gaming-critical')) return;

        const style = document.createElement('style');
        style.id = 'neon-gaming-critical';
        style.textContent = `
            /* === CRITICAL PTERODACTYL OVERRIDES === */

            /* Force dark backgrounds */
            html, body, #app, #app > div, [class*="min-h-screen"] {
                background: linear-gradient(180deg, #0a1628 0%, #050a14 100%) !important;
                color: #ffffff !important;
            }

            /* Sidebar override */
            aside, nav[class*="w-"], [class*="sidebar"] {
                background: linear-gradient(180deg, #0a1628 0%, #071020 100%) !important;
                border-right: 1px solid #1a3050 !important;
            }

            /* Cards and panels */
            [class*="bg-neutral-700"], [class*="bg-neutral-800"], [class*="bg-gray-700"], [class*="bg-gray-800"] {
                background: linear-gradient(145deg, #0f1f3d 0%, #0a1628 100%) !important;
                border: 1px solid #1a3050 !important;
                border-radius: 12px !important;
            }

            /* Neutral color replacements */
            .bg-neutral-900 { background-color: #050a14 !important; }
            .bg-neutral-800 { background-color: #0a1628 !important; }
            .bg-neutral-700 { background-color: #0f1f3d !important; }
            .bg-neutral-600 { background-color: #162a4a !important; }

            /* Text colors */
            .text-neutral-100, .text-neutral-200, .text-white { color: #ffffff !important; }
            .text-neutral-300, .text-neutral-400 { color: #a0b4c8 !important; }
            .text-neutral-500 { color: #5a7a9a !important; }

            /* Borders */
            [class*="border-neutral"], [class*="border-gray"] {
                border-color: #1a3050 !important;
            }

            /* Primary buttons with neon glow */
            button[class*="bg-primary"], button[class*="bg-cyan"],
            [class*="bg-primary-500"], [class*="bg-cyan-500"] {
                background: linear-gradient(135deg, #00d4ff 0%, #00aadd 100%) !important;
                border: 1px solid #00d4ff !important;
                color: #050a14 !important;
                box-shadow: 0 0 15px rgba(0, 212, 255, 0.4) !important;
                font-weight: 600 !important;
                transition: all 0.2s ease !important;
            }

            button[class*="bg-primary"]:hover, button[class*="bg-cyan"]:hover {
                box-shadow: 0 0 25px rgba(0, 212, 255, 0.6), 0 4px 15px rgba(0, 0, 0, 0.3) !important;
                transform: translateY(-2px) !important;
            }

            /* Danger buttons */
            button[class*="bg-red"], [class*="bg-red-500"] {
                background: linear-gradient(135deg, #ff3366 0%, #cc2952 100%) !important;
                border: 1px solid #ff3366 !important;
                box-shadow: 0 0 15px rgba(255, 51, 102, 0.4) !important;
            }

            /* Success buttons */
            button[class*="bg-green"], [class*="bg-green-500"] {
                background: linear-gradient(135deg, #00ff88 0%, #00cc6a 100%) !important;
                border: 1px solid #00ff88 !important;
                color: #050a14 !important;
                box-shadow: 0 0 15px rgba(0, 255, 136, 0.4) !important;
            }

            /* Inputs with neon focus */
            input, select, textarea {
                background-color: #0f1f3d !important;
                border: 1px solid #1a3050 !important;
                color: #ffffff !important;
                transition: all 0.2s ease !important;
            }

            input:focus, select:focus, textarea:focus {
                border-color: #00d4ff !important;
                box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.15), 0 0 15px rgba(0, 212, 255, 0.3) !important;
                outline: none !important;
            }

            /* Links */
            a { color: #00d4ff !important; }
            a:hover {
                color: #ffffff !important;
                text-shadow: 0 0 10px rgba(0, 212, 255, 0.6) !important;
            }

            /* Console area */
            [class*="console"], .xterm, .xterm-viewport {
                background-color: #0a0a12 !important;
                border-radius: 12px !important;
            }

            /* Tables */
            table th {
                background-color: #0f1f3d !important;
                color: #5a7a9a !important;
                text-transform: uppercase !important;
                letter-spacing: 1px !important;
                font-size: 11px !important;
            }

            table td {
                border-color: #1a3050 !important;
            }

            table tbody tr:hover {
                background-color: #0f1f3d !important;
            }

            /* Status colors with glow */
            .bg-green-500, .bg-emerald-500 {
                background-color: #00ff88 !important;
                box-shadow: 0 0 10px rgba(0, 255, 136, 0.5) !important;
            }

            .bg-red-500, .bg-rose-500 {
                background-color: #ff3366 !important;
                box-shadow: 0 0 10px rgba(255, 51, 102, 0.5) !important;
            }

            .bg-yellow-500, .bg-amber-500 {
                background-color: #ffcc00 !important;
                box-shadow: 0 0 10px rgba(255, 204, 0, 0.5) !important;
            }

            /* Modals */
            [role="dialog"], [class*="modal"] {
                background-color: #0a1628 !important;
                border: 1px solid #2a4a6a !important;
                border-radius: 16px !important;
                box-shadow: 0 0 60px rgba(0, 212, 255, 0.1) !important;
            }

            /* Dropdowns */
            [class*="dropdown"], [role="menu"] {
                background-color: #0a1628 !important;
                border: 1px solid #2a4a6a !important;
                border-radius: 12px !important;
            }

            /* Hover states */
            [class*="hover:bg-neutral-700"]:hover, [class*="hover:bg-gray-700"]:hover {
                background-color: #0f1f3d !important;
            }

            [class*="hover:bg-neutral-600"]:hover, [class*="hover:bg-gray-600"]:hover {
                background-color: #162a4a !important;
            }

            /* Focus rings */
            [class*="focus:ring"] {
                --tw-ring-color: rgba(0, 212, 255, 0.5) !important;
            }

            /* Scrollbars */
            ::-webkit-scrollbar {
                width: 8px;
                height: 8px;
            }

            ::-webkit-scrollbar-track {
                background: #0a1628;
                border-radius: 4px;
            }

            ::-webkit-scrollbar-thumb {
                background: #2a4a6a;
                border-radius: 4px;
            }

            ::-webkit-scrollbar-thumb:hover {
                background: #00d4ff;
                box-shadow: 0 0 10px rgba(0, 212, 255, 0.5);
            }

            /* Selection */
            ::selection {
                background: #00d4ff;
                color: #050a14;
            }

            /* Transitions for smooth theme */
            *, *::before, *::after {
                transition-property: background-color, border-color, color, box-shadow;
                transition-duration: 0.15s;
                transition-timing-function: ease;
            }
        `;

        document.head.appendChild(style);
    }

    // Enhance existing DOM elements
    function enhanceElements() {
        // Add glow effect to status indicators
        document.querySelectorAll('[class*="bg-green-500"]').forEach(el => {
            el.classList.add('neon-status-glow-green');
        });

        document.querySelectorAll('[class*="bg-red-500"]').forEach(el => {
            el.classList.add('neon-status-glow-red');
        });

        // Enhance server cards
        document.querySelectorAll('a[href*="/server/"]').forEach(el => {
            if (el.classList.contains('flex') || el.classList.contains('block')) {
                el.classList.add('neon-server-card-enhanced');
            }
        });
    }

    // Setup event listeners
    function setupEventListeners() {
        // Sidebar toggle (if we add custom sidebar)
        document.addEventListener('click', function(e) {
            if (e.target.closest('.sidebar-toggle')) {
                document.body.classList.toggle('sidebar-collapsed');
            }
        });

        // Add hover glow effects to buttons
        document.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('mouseenter', function() {
                this.style.transition = 'all 0.2s ease';
            });
        });
    }

    // Observe DOM changes for React updates
    function observeDOMChanges() {
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.addedNodes.length) {
                    // Re-enhance new elements
                    enhanceElements();

                    // Ensure critical styles remain
                    if (!document.getElementById('neon-gaming-critical')) {
                        injectCriticalStyles();
                    }
                }
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    // Debug logging
    function log(message) {
        if (config.debugMode) {
            console.log('[' + THEME_NAME + '] ' + message);
        }
    }

    // Public API
    window.NeonGamingTheme = {
        version: THEME_VERSION,
        config: config,
        refresh: applyTheme,
        toggleSidebar: function() {
            document.body.classList.toggle('sidebar-collapsed');
        }
    };

    // Initialize
    init();

})();
