@extends('templates/wrapper', [
    'css' => ['body' => 'neon-gaming-theme']
])

@section('meta')
    @parent
    <style>
        /* Login page specific styles */
        .neon-login-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            background: linear-gradient(180deg, #0a1628 0%, #050a14 100%);
            position: relative;
            overflow: hidden;
        }

        /* Animated grid background */
        .neon-login-page::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-image:
                linear-gradient(rgba(0, 212, 255, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 212, 255, 0.03) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: gridMove 20s linear infinite;
        }

        @keyframes gridMove {
            0% { transform: translate(0, 0); }
            100% { transform: translate(50px, 50px); }
        }

        /* Glow orbs */
        .neon-login-page::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background:
                radial-gradient(circle at 20% 30%, rgba(0, 212, 255, 0.15) 0%, transparent 40%),
                radial-gradient(circle at 80% 70%, rgba(168, 85, 247, 0.15) 0%, transparent 40%);
            pointer-events: none;
        }

        .neon-login-container {
            width: 100%;
            max-width: 440px;
            position: relative;
            z-index: 1;
        }

        .neon-login-card {
            background: #0a1628;
            border: 1px solid #2a4a6a;
            border-radius: 24px;
            overflow: hidden;
            box-shadow: 0 25px 80px rgba(0, 0, 0, 0.5), 0 0 60px rgba(0, 212, 255, 0.1);
            position: relative;
        }

        /* Top glow border */
        .neon-login-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #00d4ff, #a855f7, #00d4ff);
            box-shadow: 0 0 30px rgba(0, 212, 255, 0.5);
        }

        .neon-login-header {
            padding: 48px 32px 32px;
            text-align: center;
            background: linear-gradient(180deg, #0f1f3d 0%, #0a1628 100%);
            border-bottom: 1px solid #1a3050;
        }

        .login-logo {
            width: 80px;
            height: 80px;
            margin: 0 auto 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #00d4ff 0%, #00aadd 100%);
            border-radius: 16px;
            box-shadow: 0 0 30px rgba(0, 212, 255, 0.5);
            position: relative;
        }

        .login-logo::before {
            content: '';
            position: absolute;
            inset: -4px;
            background: linear-gradient(135deg, #00d4ff, #a855f7);
            border-radius: 20px;
            z-index: -1;
            opacity: 0.5;
            filter: blur(10px);
        }

        .login-logo span {
            font-family: 'Rajdhani', sans-serif;
            font-size: 36px;
            font-weight: 800;
            color: #050a14;
        }

        .login-title {
            margin: 0 0 8px 0;
            font-family: 'Rajdhani', sans-serif;
            font-size: 28px;
            font-weight: 700;
            color: #ffffff;
            text-transform: uppercase;
            letter-spacing: 3px;
        }

        .login-subtitle {
            margin: 0;
            font-size: 14px;
            color: #5a7a9a;
        }

        .neon-login-form {
            padding: 32px;
        }

        .login-form-group {
            margin-bottom: 24px;
        }

        .login-label {
            display: block;
            margin-bottom: 8px;
            font-size: 12px;
            font-weight: 600;
            color: #a0b4c8;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .login-input-wrapper {
            position: relative;
        }

        .login-input {
            width: 100%;
            padding: 14px 16px 14px 48px;
            background: #0f1f3d;
            border: 1px solid #1a3050;
            border-radius: 12px;
            color: #ffffff;
            font-size: 15px;
            transition: all 0.2s ease;
        }

        .login-input::placeholder {
            color: #3a5a7a;
        }

        .login-input:hover {
            border-color: #2a4a6a;
        }

        .login-input:focus {
            outline: none;
            border-color: #00d4ff;
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.15), 0 0 20px rgba(0, 212, 255, 0.3);
        }

        .login-input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #5a7a9a;
            font-size: 18px;
            transition: color 0.2s ease;
        }

        .login-input:focus ~ .login-input-icon {
            color: #00d4ff;
        }

        .login-options {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }

        .remember-me {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }

        .remember-me input[type="checkbox"] {
            width: 18px;
            height: 18px;
            appearance: none;
            background: #0f1f3d;
            border: 2px solid #2a4a6a;
            border-radius: 4px;
            cursor: pointer;
            position: relative;
            transition: all 0.2s ease;
        }

        .remember-me input[type="checkbox"]:checked {
            background: #00d4ff;
            border-color: #00d4ff;
        }

        .remember-me input[type="checkbox"]:checked::after {
            content: '';
            position: absolute;
            top: 1px;
            left: 5px;
            width: 4px;
            height: 8px;
            border: solid #050a14;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
        }

        .remember-me span {
            font-size: 13px;
            color: #a0b4c8;
        }

        .forgot-password {
            font-size: 13px;
            color: #00d4ff;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .forgot-password:hover {
            color: #ffffff;
            text-shadow: 0 0 10px rgba(0, 212, 255, 0.6);
        }

        .login-submit {
            width: 100%;
            padding: 16px 32px;
            background: linear-gradient(135deg, #00d4ff 0%, #00aadd 100%);
            border: 1px solid #00d4ff;
            border-radius: 12px;
            color: #050a14;
            font-family: 'Rajdhani', sans-serif;
            font-size: 16px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 0 20px rgba(0, 212, 255, 0.4);
            position: relative;
            overflow: hidden;
        }

        .login-submit::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }

        .login-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 0 30px rgba(0, 212, 255, 0.6), 0 4px 20px rgba(0, 0, 0, 0.3);
        }

        .login-submit:hover::before {
            left: 100%;
        }

        .login-submit:active {
            transform: translateY(0);
        }

        .neon-login-footer {
            padding: 20px 32px;
            background: #0f1f3d;
            border-top: 1px solid #1a3050;
            text-align: center;
        }

        .login-footer-text {
            font-size: 13px;
            color: #5a7a9a;
        }

        .login-footer-text a {
            color: #00d4ff;
            text-decoration: none;
        }

        .login-footer-text a:hover {
            text-decoration: underline;
        }

        /* Error message */
        .login-error {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: rgba(255, 51, 102, 0.1);
            border: 1px solid #ff3366;
            border-radius: 8px;
            margin-bottom: 24px;
        }

        .login-error-icon {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 51, 102, 0.2);
            border-radius: 8px;
            color: #ff3366;
            flex-shrink: 0;
        }

        .login-error-text {
            font-size: 13px;
            color: #ff3366;
        }

        @media (max-width: 480px) {
            .neon-login-page {
                padding: 16px;
            }

            .neon-login-card {
                border-radius: 16px;
            }

            .neon-login-header {
                padding: 32px 24px 24px;
            }

            .neon-login-form {
                padding: 24px;
            }

            .login-options {
                flex-direction: column;
                gap: 16px;
                align-items: flex-start;
            }
        }
    </style>
@endsection

@section('container')
    <div class="neon-login-page">
        <div class="neon-login-container">
            <div class="neon-login-card">
                <div class="neon-login-header">
                    <div class="login-logo">
                        <span>G</span>
                    </div>
                    <h1 class="login-title">Gaming Panel</h1>
                    <p class="login-subtitle">Sign in to manage your servers</p>
                </div>

                <form class="neon-login-form" method="POST" action="{{ route('auth.login') }}">
                    @csrf

                    @if(session('error'))
                        <div class="login-error">
                            <div class="login-error-icon">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="12" r="10"></circle>
                                    <line x1="15" y1="9" x2="9" y2="15"></line>
                                    <line x1="9" y1="9" x2="15" y2="15"></line>
                                </svg>
                            </div>
                            <span class="login-error-text">{{ session('error') }}</span>
                        </div>
                    @endif

                    @if($errors->any())
                        <div class="login-error">
                            <div class="login-error-icon">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="12" r="10"></circle>
                                    <line x1="12" y1="8" x2="12" y2="12"></line>
                                    <line x1="12" y1="16" x2="12.01" y2="16"></line>
                                </svg>
                            </div>
                            <span class="login-error-text">{{ $errors->first() }}</span>
                        </div>
                    @endif

                    <div class="login-form-group">
                        <label class="login-label" for="user">Username or Email</label>
                        <div class="login-input-wrapper">
                            <input
                                type="text"
                                id="user"
                                name="user"
                                class="login-input"
                                placeholder="Enter your username or email"
                                value="{{ old('user') }}"
                                required
                                autofocus
                            >
                            <svg class="login-input-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                <circle cx="12" cy="7" r="4"></circle>
                            </svg>
                        </div>
                    </div>

                    <div class="login-form-group">
                        <label class="login-label" for="password">Password</label>
                        <div class="login-input-wrapper">
                            <input
                                type="password"
                                id="password"
                                name="password"
                                class="login-input"
                                placeholder="Enter your password"
                                required
                            >
                            <svg class="login-input-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                            </svg>
                        </div>
                    </div>

                    <div class="login-options">
                        <label class="remember-me">
                            <input type="checkbox" name="remember">
                            <span>Remember me</span>
                        </label>
                        @if(config('pterodactyl.auth.password_resets'))
                            <a href="{{ route('auth.password') }}" class="forgot-password">Forgot password?</a>
                        @endif
                    </div>

                    <button type="submit" class="login-submit">
                        Sign In
                    </button>
                </form>

                @if(config('pterodactyl.auth.register'))
                    <div class="neon-login-footer">
                        <p class="login-footer-text">
                            Don't have an account? <a href="{{ route('auth.register') }}">Create one</a>
                        </p>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection
