<!DOCTYPE html>
<html lang="en" data-theme="neon-gaming">
    <head>
        <title>{{ config('app.name', 'Pterodactyl') }}</title>

        @section('meta')
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <meta name="robots" content="noindex">
            <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
            <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
            <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
            <link rel="manifest" href="/favicons/manifest.json">
            <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#bc6e3c">
            <link rel="shortcut icon" href="/favicons/favicon.ico">
            <meta name="msapplication-config" content="/favicons/browserconfig.xml">

            {{-- Neon Gaming Theme --}}
            <meta name="theme-color" content="#0a1628">

            {{-- Google Fonts for Gaming Theme --}}
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Rajdhani:wght@400;500;600;700&family=Orbitron:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">

            {{-- Neon Gaming Theme CSS --}}
            <link rel="stylesheet" href="/themes/neon-gaming/css/neon-gaming.css?v={{ config('app.version', '1.0') }}">
        @show

        @section('user-data')
            @if(!is_null(Auth::user()))
                <script>
                    window.PterodactylUser = {!! json_encode(Auth::user()->toVueObject()) !!};
                </script>
            @endif
            @if(!empty($siteConfiguration))
                <script>
                    window.SiteConfiguration = {!! json_encode($siteConfiguration) !!};
                </script>
            @endif
        @show

        {{-- Neon Gaming Theme Config --}}
        <script>
            window.NeonGamingConfig = {
                theme: 'neon-gaming',
                version: '1.0.0',
                animations: true,
                glowEffects: true
            };
        </script>

        <style>
            @import url('//fonts.googleapis.com/css?family=Rubik:300,400,500&display=swap');
            @import url('//fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&display=swap');

            /* Critical loading styles */
            body {
                background: linear-gradient(180deg, #0a1628 0%, #050a14 100%) !important;
                min-height: 100vh;
            }

            /* Loading spinner */
            #neon-loading {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: linear-gradient(180deg, #0a1628 0%, #050a14 100%);
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                z-index: 9999;
                transition: opacity 0.5s ease;
            }

            #neon-loading.fade-out {
                opacity: 0;
                pointer-events: none;
            }

            .neon-loader {
                width: 60px;
                height: 60px;
                border: 3px solid #1a3050;
                border-top-color: #00d4ff;
                border-radius: 50%;
                animation: neon-spin 1s linear infinite;
                box-shadow: 0 0 20px rgba(0, 212, 255, 0.3);
            }

            .neon-loader-text {
                margin-top: 20px;
                font-family: 'Rajdhani', sans-serif;
                font-size: 14px;
                color: #5a7a9a;
                text-transform: uppercase;
                letter-spacing: 3px;
            }

            @keyframes neon-spin {
                to { transform: rotate(360deg); }
            }
        </style>
    </head>
    <body class="{{ $css['body'] ?? 'bg-neutral-900' }} neon-gaming-theme">
        {{-- Loading Screen --}}
        <div id="neon-loading">
            <div class="neon-loader"></div>
            <div class="neon-loader-text">Loading</div>
        </div>

        @section('content')
            @yield('above-container')
            @yield('container')
            @yield('below-container')
        @show

        {{-- Neon Gaming Theme JavaScript --}}
        <script src="/themes/neon-gaming/js/neon-gaming.js?v={{ config('app.version', '1.0') }}" defer></script>

        {{-- Hide loading screen when app is ready --}}
        <script>
            (function() {
                function hideLoader() {
                    var loader = document.getElementById('neon-loading');
                    if (loader) {
                        loader.classList.add('fade-out');
                        setTimeout(function() {
                            loader.remove();
                        }, 500);
                    }
                }

                // Hide on window load
                window.addEventListener('load', function() {
                    setTimeout(hideLoader, 300);
                });

                // Fallback - hide after 3 seconds
                setTimeout(hideLoader, 3000);
            })();
        </script>
    </body>
</html>
