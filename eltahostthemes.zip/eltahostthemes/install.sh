#!/bin/bash

###########################################
# NEON GAMING PANEL - Installation Script
# For Pterodactyl Panel
###########################################

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Configuration
PTERODACTYL_DIR="/var/www/pterodactyl"
THEME_NAME="neon-gaming"
BACKUP_DIR="/var/www/pterodactyl-backups"

# Functions
print_header() {
    echo -e "${CYAN}"
    echo "╔═══════════════════════════════════════════════════════════╗"
    echo "║            NEON GAMING PANEL - INSTALLER                  ║"
    echo "║                    Version 1.0.0                          ║"
    echo "╚═══════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_step() {
    echo -e "${CYAN}[STEP]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root"
        exit 1
    fi
}

check_pterodactyl() {
    if [ ! -d "$PTERODACTYL_DIR" ]; then
        print_error "Pterodactyl not found at $PTERODACTYL_DIR"
        exit 1
    fi
    print_success "Pterodactyl installation found"
}

create_backup() {
    print_step "Creating backup..."

    TIMESTAMP=$(date +%Y%m%d_%H%M%S)
    mkdir -p "$BACKUP_DIR"

    # Backup original views
    if [ -d "$PTERODACTYL_DIR/resources/views" ]; then
        cp -r "$PTERODACTYL_DIR/resources/views" "$BACKUP_DIR/views_$TIMESTAMP"
    fi

    print_success "Backup created at $BACKUP_DIR"
}

install_theme_assets() {
    print_step "Installing theme assets..."

    # Create theme directories
    mkdir -p "$PTERODACTYL_DIR/public/themes/$THEME_NAME/css/components"
    mkdir -p "$PTERODACTYL_DIR/public/themes/$THEME_NAME/css/pages"
    mkdir -p "$PTERODACTYL_DIR/public/themes/$THEME_NAME/js"
    mkdir -p "$PTERODACTYL_DIR/public/themes/$THEME_NAME/assets"

    # Copy CSS files
    cp -r theme/css/* "$PTERODACTYL_DIR/public/themes/$THEME_NAME/css/"

    # Copy JS files
    cp -r theme/js/* "$PTERODACTYL_DIR/public/themes/$THEME_NAME/js/"

    # Copy assets if they exist
    if [ -d "theme/assets" ]; then
        cp -r theme/assets/* "$PTERODACTYL_DIR/public/themes/$THEME_NAME/assets/"
    fi

    # Set permissions
    chown -R www-data:www-data "$PTERODACTYL_DIR/public/themes/$THEME_NAME"
    chmod -R 755 "$PTERODACTYL_DIR/public/themes/$THEME_NAME"

    print_success "Theme assets installed"
}

install_blade_overrides() {
    print_step "Installing Blade template overrides..."

    # Backup and copy wrapper template
    if [ -f "theme/views/templates/wrapper.blade.php" ]; then
        cp "$PTERODACTYL_DIR/resources/views/templates/wrapper.blade.php" \
           "$PTERODACTYL_DIR/resources/views/templates/wrapper.blade.php.backup" 2>/dev/null || true
        cp "theme/views/templates/wrapper.blade.php" \
           "$PTERODACTYL_DIR/resources/views/templates/wrapper.blade.php"
    fi

    # Copy login template
    if [ -f "theme/views/auth/login.blade.php" ]; then
        cp "$PTERODACTYL_DIR/resources/views/auth/login.blade.php" \
           "$PTERODACTYL_DIR/resources/views/auth/login.blade.php.backup" 2>/dev/null || true
        cp "theme/views/auth/login.blade.php" \
           "$PTERODACTYL_DIR/resources/views/auth/login.blade.php"
    fi

    # Set permissions
    chown -R www-data:www-data "$PTERODACTYL_DIR/resources/views"

    print_success "Blade templates installed"
}

install_config() {
    print_step "Installing configuration..."

    mkdir -p "$PTERODACTYL_DIR/config/themes"
    cp config/theme.json "$PTERODACTYL_DIR/config/themes/$THEME_NAME.json"

    print_success "Configuration installed"
}

clear_cache() {
    print_step "Clearing caches..."

    cd "$PTERODACTYL_DIR"

    php artisan view:clear
    php artisan cache:clear
    php artisan config:clear

    print_success "Caches cleared"
}

install_addons() {
    print_step "Installing addons..."

    # Create addons directory
    mkdir -p "$PTERODACTYL_DIR/addons"

    # Copy addon files
    if [ -d "addons" ]; then
        cp -r addons/* "$PTERODACTYL_DIR/addons/" 2>/dev/null || true
    fi

    # Copy portal files
    if [ -d "portal" ]; then
        # Routes
        if [ -f "portal/routes/api.php" ]; then
            cat "portal/routes/api.php" >> "$PTERODACTYL_DIR/routes/api.php"
        fi

        # Controllers
        if [ -d "portal/controllers" ]; then
            cp -r portal/controllers/* "$PTERODACTYL_DIR/app/Http/Controllers/" 2>/dev/null || true
        fi

        # Models
        if [ -d "portal/models" ]; then
            cp -r portal/models/* "$PTERODACTYL_DIR/app/Models/" 2>/dev/null || true
        fi

        # Migrations
        if [ -d "portal/migrations" ]; then
            cp -r portal/migrations/* "$PTERODACTYL_DIR/database/migrations/" 2>/dev/null || true
        fi

        # Services
        if [ -d "portal/services" ]; then
            mkdir -p "$PTERODACTYL_DIR/app/Services"
            cp -r portal/services/* "$PTERODACTYL_DIR/app/Services/" 2>/dev/null || true
        fi
    fi

    # Set permissions
    chown -R www-data:www-data "$PTERODACTYL_DIR/addons"

    print_success "Addons installed"
}

run_migrations() {
    print_step "Running database migrations..."

    cd "$PTERODACTYL_DIR"
    php artisan migrate --force

    print_success "Migrations completed"
}

restart_services() {
    print_step "Restarting services..."

    systemctl restart php*-fpm 2>/dev/null || true
    systemctl restart nginx 2>/dev/null || true
    systemctl restart apache2 2>/dev/null || true

    print_success "Services restarted"
}

# Main installation
main() {
    print_header

    check_root
    check_pterodactyl
    create_backup
    install_theme_assets
    install_blade_overrides
    install_config
    install_addons
    run_migrations
    clear_cache
    restart_services

    echo ""
    print_success "═══════════════════════════════════════════════════════════"
    print_success "  NEON GAMING PANEL installed successfully!"
    print_success "═══════════════════════════════════════════════════════════"
    echo ""
    echo -e "  ${CYAN}Theme Location:${NC} $PTERODACTYL_DIR/public/themes/$THEME_NAME"
    echo -e "  ${CYAN}Backup Location:${NC} $BACKUP_DIR"
    echo ""
    echo -e "  ${YELLOW}Note:${NC} Clear your browser cache to see the new theme."
    echo ""
}

# Run installer
main "$@"
