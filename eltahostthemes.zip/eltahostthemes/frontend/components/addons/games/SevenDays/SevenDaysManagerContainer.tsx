import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineGlobe, HiOutlineTrash, HiOutlineClock, HiOutlineSave, HiOutlineRefresh, HiOutlineCalendar, HiOutlineExclamation, HiOutlineDownload, HiOutlinePlus } from 'react-icons/hi';

interface World {
    id: string;
    name: string;
    seed: string;
    size: string;
    createdAt: string;
    lastPlayed: string;
    daysPassed: number;
    isActive: boolean;
}

interface WipeSchedule {
    id: string;
    name: string;
    interval: 'weekly' | 'biweekly' | 'monthly' | 'custom';
    nextWipe: string;
    preserveBlueprints: boolean;
    preserveCharacters: boolean;
    enabled: boolean;
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #8b4513, #cd853f, #8b4513);
    }
`;

const HeaderContent = styled.div`
    ${tw`flex items-center justify-between`}
`;

const HeaderInfo = styled.div`
    ${tw`flex items-center gap-4`}
`;

const GameLogo = styled.div`
    ${tw`w-16 h-16 rounded-xl flex items-center justify-center text-xl font-bold`}
    background: linear-gradient(135deg, #8b4513 0%, #cd853f 100%);
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const HeaderText = styled.div``;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const HeaderActions = styled.div`
    ${tw`flex gap-3`}
`;

const PrimaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: linear-gradient(135deg, #8b4513 0%, #cd853f 100%);
    color: #ffffff;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(139, 69, 19, 0.3);
    }
`;

const DangerButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: rgba(255, 51, 102, 0.15);
    color: #ff3366;
    border: 1px solid rgba(255, 51, 102, 0.5);
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        background: rgba(255, 51, 102, 0.25);
    }
`;

const ContentGrid = styled.div`
    ${tw`grid gap-6`}
    grid-template-columns: 1fr 400px;

    @media (max-width: 1200px) {
        grid-template-columns: 1fr;
    }
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const CardBody = styled.div`
    ${tw`p-5`}
`;

const WorldGrid = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
`;

const WorldCard = styled.div<{ $active?: boolean }>`
    ${tw`p-4 rounded-xl relative`}
    background: ${props => props.$active
        ? 'linear-gradient(145deg, rgba(139, 69, 19, 0.15) 0%, rgba(205, 133, 63, 0.1) 100%)'
        : 'rgba(15, 31, 61, 0.5)'};
    border: 2px solid ${props => props.$active ? '#cd853f' : 'rgba(26, 48, 80, 0.8)'};
    transition: all 0.3s ease;

    ${props => props.$active && `
        &::after {
            content: 'ACTIVE';
            position: absolute;
            top: -10px;
            right: 10px;
            padding: 2px 8px;
            background: #cd853f;
            color: #050a14;
            font-size: 10px;
            font-weight: 700;
            border-radius: 4px;
            font-family: 'Rajdhani', sans-serif;
        }
    `}

    &:hover {
        border-color: ${props => props.$active ? '#cd853f' : '#00d4ff'};
    }
`;

const WorldHeader = styled.div`
    ${tw`flex items-center gap-3 mb-4`}
`;

const WorldIcon = styled.div`
    ${tw`w-12 h-12 rounded-lg flex items-center justify-center text-xl`}
    background: rgba(139, 69, 19, 0.15);
    border: 1px solid #cd853f;
    color: #cd853f;
`;

const WorldInfo = styled.div``;

const WorldName = styled.h4`
    ${tw`text-lg font-bold`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const WorldSeed = styled.span`
    ${tw`text-xs font-mono`}
    color: #5a7a9a;
`;

const WorldStats = styled.div`
    ${tw`grid grid-cols-2 gap-3 mb-4`}
`;

const WorldStat = styled.div`
    ${tw`text-center p-2 rounded-lg`}
    background: rgba(5, 10, 20, 0.5);
`;

const WorldStatValue = styled.span`
    ${tw`text-lg font-bold block`}
    color: #cd853f;
    font-family: 'Rajdhani', sans-serif;
`;

const WorldStatLabel = styled.span`
    ${tw`text-xs`}
    color: #5a7a9a;
`;

const WorldActions = styled.div`
    ${tw`flex gap-2`}
`;

const SmallButton = styled.button<{ $variant?: 'primary' | 'danger' }>`
    ${tw`flex-1 py-2 px-3 rounded-lg font-semibold text-xs flex items-center justify-center gap-1`}
    background: ${props => {
        switch(props.$variant) {
            case 'primary': return 'linear-gradient(135deg, #8b4513 0%, #cd853f 100%)';
            case 'danger': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(26, 48, 80, 0.5)';
        }
    }};
    border: 1px solid ${props => {
        switch(props.$variant) {
            case 'primary': return 'transparent';
            case 'danger': return '#ff3366';
            default: return 'rgba(26, 48, 80, 0.8)';
        }
    }};
    color: ${props => {
        switch(props.$variant) {
            case 'primary': return '#ffffff';
            case 'danger': return '#ff3366';
            default: return '#a0b4c8';
        }
    }};
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-1px);
    }
`;

const WipeCard = styled.div`
    ${tw`p-4 rounded-xl mb-4`}
    background: rgba(255, 51, 102, 0.1);
    border: 1px solid rgba(255, 51, 102, 0.3);
`;

const WipeHeader = styled.div`
    ${tw`flex items-center justify-between mb-3`}
`;

const WipeTitle = styled.h4`
    ${tw`text-sm font-bold flex items-center gap-2`}
    color: #ff3366;
    font-family: 'Rajdhani', sans-serif;
`;

const WipeCountdown = styled.div`
    ${tw`text-center py-4`}
`;

const WipeTime = styled.span`
    ${tw`text-3xl font-bold block`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const WipeLabel = styled.span`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const WipeOptions = styled.div`
    ${tw`flex flex-col gap-2 mt-4`}
`;

const WipeOption = styled.label`
    ${tw`flex items-center gap-3 p-2 rounded-lg cursor-pointer`}
    background: rgba(15, 31, 61, 0.5);

    input {
        ${tw`w-4 h-4`}
        accent-color: #cd853f;
    }

    span {
        ${tw`text-sm`}
        color: #a0b4c8;
    }
`;

const ScheduleItem = styled.div`
    ${tw`p-4 flex items-center justify-between`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.5);

    &:last-child {
        border-bottom: none;
    }
`;

const ScheduleInfo = styled.div``;

const ScheduleName = styled.h4`
    ${tw`text-sm font-semibold`}
    color: #ffffff;
`;

const ScheduleDetails = styled.span`
    ${tw`text-xs block mt-1`}
    color: #5a7a9a;
`;

const ToggleSwitch = styled.label`
    ${tw`relative inline-block w-12 h-6 cursor-pointer`}

    input {
        ${tw`opacity-0 w-0 h-0`}
    }

    span {
        ${tw`absolute inset-0 rounded-full transition-colors`}
        background: rgba(26, 48, 80, 0.8);

        &::before {
            content: '';
            ${tw`absolute w-5 h-5 rounded-full transition-transform`}
            background: #ffffff;
            top: 2px;
            left: 2px;
        }
    }

    input:checked + span {
        background: linear-gradient(135deg, #8b4513 0%, #cd853f 100%);
    }

    input:checked + span::before {
        transform: translateX(24px);
    }
`;

const CreateWorldButton = styled.button`
    ${tw`w-full py-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2`}
    background: rgba(26, 48, 80, 0.3);
    border: 2px dashed rgba(26, 48, 80, 0.8);
    color: #5a7a9a;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #cd853f;
        color: #cd853f;
    }
`;

// Mock data
const mockWorlds: World[] = [
    { id: '1', name: 'Navezgane', seed: 'navezgane', size: '6144x6144', createdAt: '2024-01-01', lastPlayed: '2024-01-19', daysPassed: 42, isActive: true },
    { id: '2', name: 'Random Gen Alpha', seed: 'abc123xyz', size: '8192x8192', createdAt: '2024-01-10', lastPlayed: '2024-01-15', daysPassed: 21, isActive: false },
    { id: '3', name: 'PvP World', seed: 'pvpworld2024', size: '4096x4096', createdAt: '2023-12-15', lastPlayed: '2024-01-12', daysPassed: 63, isActive: false },
];

const mockSchedules: WipeSchedule[] = [
    { id: '1', name: 'Bi-Weekly Wipe', interval: 'biweekly', nextWipe: '2024-01-28 04:00', preserveBlueprints: true, preserveCharacters: false, enabled: true },
    { id: '2', name: 'Monthly Fresh Start', interval: 'monthly', nextWipe: '2024-02-01 04:00', preserveBlueprints: false, preserveCharacters: false, enabled: false },
];

const SevenDaysManagerContainer: React.FC = () => {
    const [worlds] = useState<World[]>(mockWorlds);
    const [schedules, setSchedules] = useState<WipeSchedule[]>(mockSchedules);

    const toggleSchedule = (id: string) => {
        setSchedules(prev => prev.map(s =>
            s.id === id ? { ...s, enabled: !s.enabled } : s
        ));
    };

    const activeWorld = worlds.find(w => w.isActive);

    return (
        <Container>
            <PageHeader>
                <HeaderContent>
                    <HeaderInfo>
                        <GameLogo>7D2D</GameLogo>
                        <HeaderText>
                            <PageTitle>7 Days to Die Manager</PageTitle>
                            <PageSubtitle>Manage worlds, wipes, and server settings</PageSubtitle>
                        </HeaderText>
                    </HeaderInfo>
                    <HeaderActions>
                        <DangerButton>
                            <HiOutlineTrash /> Wipe Now
                        </DangerButton>
                        <PrimaryButton>
                            <HiOutlineSave /> Save World
                        </PrimaryButton>
                    </HeaderActions>
                </HeaderContent>
            </PageHeader>

            <ContentGrid>
                <div css={tw`flex flex-col gap-6`}>
                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineGlobe /> Saved Worlds
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <WorldGrid>
                                {worlds.map(world => (
                                    <WorldCard key={world.id} $active={world.isActive}>
                                        <WorldHeader>
                                            <WorldIcon>
                                                <HiOutlineGlobe />
                                            </WorldIcon>
                                            <WorldInfo>
                                                <WorldName>{world.name}</WorldName>
                                                <WorldSeed>Seed: {world.seed}</WorldSeed>
                                            </WorldInfo>
                                        </WorldHeader>
                                        <WorldStats>
                                            <WorldStat>
                                                <WorldStatValue>{world.daysPassed}</WorldStatValue>
                                                <WorldStatLabel>Days Passed</WorldStatLabel>
                                            </WorldStat>
                                            <WorldStat>
                                                <WorldStatValue>{world.size}</WorldStatValue>
                                                <WorldStatLabel>World Size</WorldStatLabel>
                                            </WorldStat>
                                        </WorldStats>
                                        <WorldActions>
                                            {!world.isActive && (
                                                <SmallButton $variant="primary">
                                                    <HiOutlineRefresh /> Load
                                                </SmallButton>
                                            )}
                                            <SmallButton>
                                                <HiOutlineDownload /> Backup
                                            </SmallButton>
                                            <SmallButton $variant="danger">
                                                <HiOutlineTrash />
                                            </SmallButton>
                                        </WorldActions>
                                    </WorldCard>
                                ))}
                                <CreateWorldButton>
                                    <HiOutlinePlus /> Generate New World
                                </CreateWorldButton>
                            </WorldGrid>
                        </CardBody>
                    </Card>
                </div>

                <div css={tw`flex flex-col gap-4`}>
                    {activeWorld && (
                        <WipeCard>
                            <WipeHeader>
                                <WipeTitle>
                                    <HiOutlineExclamation /> Next Scheduled Wipe
                                </WipeTitle>
                            </WipeHeader>
                            <WipeCountdown>
                                <WipeTime>9d 4h 32m</WipeTime>
                                <WipeLabel>Jan 28, 2024 at 04:00 AM</WipeLabel>
                            </WipeCountdown>
                            <WipeOptions>
                                <WipeOption>
                                    <input type="checkbox" defaultChecked />
                                    <span>Preserve player blueprints</span>
                                </WipeOption>
                                <WipeOption>
                                    <input type="checkbox" />
                                    <span>Preserve player characters</span>
                                </WipeOption>
                                <WipeOption>
                                    <input type="checkbox" defaultChecked />
                                    <span>Announce 24h before wipe</span>
                                </WipeOption>
                            </WipeOptions>
                        </WipeCard>
                    )}

                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineCalendar /> Wipe Schedules
                            </CardTitle>
                        </CardHeader>
                        <CardBody css={tw`p-0`}>
                            {schedules.map(schedule => (
                                <ScheduleItem key={schedule.id}>
                                    <ScheduleInfo>
                                        <ScheduleName>{schedule.name}</ScheduleName>
                                        <ScheduleDetails>
                                            {schedule.interval} · Next: {schedule.nextWipe}
                                        </ScheduleDetails>
                                    </ScheduleInfo>
                                    <ToggleSwitch>
                                        <input
                                            type="checkbox"
                                            checked={schedule.enabled}
                                            onChange={() => toggleSchedule(schedule.id)}
                                        />
                                        <span />
                                    </ToggleSwitch>
                                </ScheduleItem>
                            ))}
                        </CardBody>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineClock /> Current World Info
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            {activeWorld && (
                                <div css={tw`flex flex-col gap-3`}>
                                    <div css={tw`flex justify-between text-sm`}>
                                        <span style={{ color: '#5a7a9a' }}>World Name</span>
                                        <span style={{ color: '#ffffff' }}>{activeWorld.name}</span>
                                    </div>
                                    <div css={tw`flex justify-between text-sm`}>
                                        <span style={{ color: '#5a7a9a' }}>Game Day</span>
                                        <span style={{ color: '#cd853f' }}>Day {activeWorld.daysPassed}</span>
                                    </div>
                                    <div css={tw`flex justify-between text-sm`}>
                                        <span style={{ color: '#5a7a9a' }}>World Size</span>
                                        <span style={{ color: '#ffffff' }}>{activeWorld.size}</span>
                                    </div>
                                    <div css={tw`flex justify-between text-sm`}>
                                        <span style={{ color: '#5a7a9a' }}>Created</span>
                                        <span style={{ color: '#ffffff' }}>{activeWorld.createdAt}</span>
                                    </div>
                                </div>
                            )}
                        </CardBody>
                    </Card>
                </div>
            </ContentGrid>
        </Container>
    );
};

export default SevenDaysManagerContainer;
