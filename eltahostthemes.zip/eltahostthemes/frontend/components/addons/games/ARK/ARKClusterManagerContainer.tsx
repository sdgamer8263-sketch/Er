import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineLink, HiOutlineServer, HiOutlineUsers, HiOutlineCog, HiOutlinePlus, HiOutlineRefresh, HiOutlineTrash, HiOutlineChartBar, HiOutlineGlobe, HiOutlineDatabase } from 'react-icons/hi';

interface ClusterServer {
    id: string;
    name: string;
    map: string;
    players: { current: number; max: number };
    status: 'online' | 'offline' | 'starting';
    isMain: boolean;
    mods: number;
    lastRestart: string;
}

interface ClusterSettings {
    name: string;
    transfersEnabled: boolean;
    dinoTransfer: boolean;
    itemTransfer: boolean;
    characterTransfer: boolean;
    tributeDownload: boolean;
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #00ff88, #00d4ff, #00ff88);
    }
`;

const HeaderContent = styled.div`
    ${tw`flex items-center justify-between`}
`;

const HeaderInfo = styled.div`
    ${tw`flex items-center gap-4`}
`;

const GameLogo = styled.div`
    ${tw`w-16 h-16 rounded-xl flex items-center justify-center text-xl font-bold`}
    background: linear-gradient(135deg, #00ff88 0%, #00d4ff 100%);
    color: #050a14;
    font-family: 'Rajdhani', sans-serif;
`;

const HeaderText = styled.div``;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const HeaderActions = styled.div`
    ${tw`flex gap-3`}
`;

const PrimaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: linear-gradient(135deg, #00ff88 0%, #00d4ff 100%);
    color: #050a14;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 255, 136, 0.3);
    }
`;

const SecondaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: rgba(26, 48, 80, 0.5);
    color: #a0b4c8;
    border: 1px solid rgba(26, 48, 80, 0.8);
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #00d4ff;
        color: #00d4ff;
    }
`;

const ClusterStats = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(4, 1fr);

    @media (max-width: 1000px) {
        grid-template-columns: repeat(2, 1fr);
    }

    @media (max-width: 600px) {
        grid-template-columns: 1fr;
    }
`;

const StatCard = styled.div`
    ${tw`p-4 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 3px;
        height: 100%;
        background: #00ff88;
    }
`;

const StatLabel = styled.span`
    ${tw`text-xs uppercase tracking-wide block mb-1`}
    color: #5a7a9a;
    font-family: 'Rajdhani', sans-serif;
`;

const StatValue = styled.span`
    ${tw`text-2xl font-bold`}
    color: #00ff88;
    font-family: 'Rajdhani', sans-serif;
`;

const ContentGrid = styled.div`
    ${tw`grid gap-6`}
    grid-template-columns: 1fr 380px;

    @media (max-width: 1200px) {
        grid-template-columns: 1fr;
    }
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const CardBody = styled.div`
    ${tw`p-5`}
`;

const ServerList = styled.div`
    ${tw`flex flex-col gap-4`}
`;

const ServerCard = styled.div<{ $status: string }>`
    ${tw`p-4 rounded-xl relative`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid ${props => {
        switch(props.$status) {
            case 'online': return 'rgba(0, 255, 136, 0.5)';
            case 'offline': return 'rgba(255, 51, 102, 0.5)';
            case 'starting': return 'rgba(255, 204, 0, 0.5)';
            default: return 'rgba(26, 48, 80, 0.8)';
        }
    }};
    transition: all 0.3s ease;

    &:hover {
        border-color: ${props => {
            switch(props.$status) {
                case 'online': return '#00ff88';
                case 'offline': return '#ff3366';
                case 'starting': return '#ffcc00';
                default: return '#00d4ff';
            }
        }};
    }
`;

const ServerHeader = styled.div`
    ${tw`flex items-center justify-between mb-3`}
`;

const ServerInfo = styled.div`
    ${tw`flex items-center gap-3`}
`;

const ServerIcon = styled.div<{ $status: string }>`
    ${tw`w-12 h-12 rounded-lg flex items-center justify-center text-lg`}
    background: ${props => {
        switch(props.$status) {
            case 'online': return 'rgba(0, 255, 136, 0.15)';
            case 'offline': return 'rgba(255, 51, 102, 0.15)';
            case 'starting': return 'rgba(255, 204, 0, 0.15)';
            default: return 'rgba(0, 212, 255, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$status) {
            case 'online': return '#00ff88';
            case 'offline': return '#ff3366';
            case 'starting': return '#ffcc00';
            default: return '#00d4ff';
        }
    }};
`;

const ServerDetails = styled.div``;

const ServerName = styled.h4`
    ${tw`text-sm font-bold flex items-center gap-2`}
    color: #ffffff;
`;

const MainBadge = styled.span`
    ${tw`px-2 py-0.5 rounded text-xs uppercase`}
    background: rgba(0, 212, 255, 0.15);
    color: #00d4ff;
`;

const ServerMap = styled.span`
    ${tw`text-xs block mt-1`}
    color: #5a7a9a;
`;

const ServerStatus = styled.span<{ $status: string }>`
    ${tw`px-3 py-1 rounded-full text-xs uppercase font-bold flex items-center gap-1`}
    background: ${props => {
        switch(props.$status) {
            case 'online': return 'rgba(0, 255, 136, 0.15)';
            case 'offline': return 'rgba(255, 51, 102, 0.15)';
            case 'starting': return 'rgba(255, 204, 0, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    border: 1px solid ${props => {
        switch(props.$status) {
            case 'online': return '#00ff88';
            case 'offline': return '#ff3366';
            case 'starting': return '#ffcc00';
            default: return '#5a7a9a';
        }
    }};
    color: ${props => {
        switch(props.$status) {
            case 'online': return '#00ff88';
            case 'offline': return '#ff3366';
            case 'starting': return '#ffcc00';
            default: return '#5a7a9a';
        }
    }};

    span {
        ${tw`w-1.5 h-1.5 rounded-full`}
        background: currentColor;
    }
`;

const ServerStats = styled.div`
    ${tw`grid grid-cols-3 gap-3 mt-3`}
`;

const ServerStat = styled.div`
    ${tw`text-center p-2 rounded-lg`}
    background: rgba(5, 10, 20, 0.5);
`;

const ServerStatValue = styled.span`
    ${tw`text-sm font-bold block`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const ServerStatLabel = styled.span`
    ${tw`text-xs`}
    color: #5a7a9a;
`;

const ServerActions = styled.div`
    ${tw`flex gap-2 mt-3`}
`;

const IconButton = styled.button<{ $variant?: 'primary' | 'danger' }>`
    ${tw`flex-1 py-2 px-3 rounded-lg font-semibold text-xs flex items-center justify-center gap-1`}
    background: ${props => props.$variant === 'danger' ? 'rgba(255, 51, 102, 0.15)' : 'rgba(26, 48, 80, 0.5)'};
    border: 1px solid ${props => props.$variant === 'danger' ? 'rgba(255, 51, 102, 0.5)' : 'rgba(26, 48, 80, 0.8)'};
    color: ${props => props.$variant === 'danger' ? '#ff3366' : '#a0b4c8'};
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: ${props => props.$variant === 'danger' ? '#ff3366' : '#00d4ff'};
        color: ${props => props.$variant === 'danger' ? '#ff3366' : '#00d4ff'};
    }
`;

const SettingItem = styled.div`
    ${tw`flex items-center justify-between p-3 rounded-lg mb-2`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.6);
`;

const SettingLabel = styled.span`
    ${tw`text-sm`}
    color: #a0b4c8;
`;

const ToggleSwitch = styled.label`
    ${tw`relative inline-block w-12 h-6 cursor-pointer`}

    input {
        ${tw`opacity-0 w-0 h-0`}
    }

    span {
        ${tw`absolute inset-0 rounded-full transition-colors`}
        background: rgba(26, 48, 80, 0.8);

        &::before {
            content: '';
            ${tw`absolute w-5 h-5 rounded-full transition-transform`}
            background: #ffffff;
            top: 2px;
            left: 2px;
        }
    }

    input:checked + span {
        background: linear-gradient(135deg, #00ff88 0%, #00d4ff 100%);
    }

    input:checked + span::before {
        transform: translateX(24px);
    }
`;

const AddServerButton = styled.button`
    ${tw`w-full py-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2`}
    background: rgba(26, 48, 80, 0.3);
    border: 2px dashed rgba(26, 48, 80, 0.8);
    color: #5a7a9a;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #00ff88;
        color: #00ff88;
    }
`;

// Mock data
const mockServers: ClusterServer[] = [
    { id: '1', name: 'The Island', map: 'TheIsland', players: { current: 24, max: 70 }, status: 'online', isMain: true, mods: 15, lastRestart: '2024-01-19 04:00' },
    { id: '2', name: 'Ragnarok', map: 'Ragnarok', players: { current: 18, max: 70 }, status: 'online', isMain: false, mods: 15, lastRestart: '2024-01-19 04:00' },
    { id: '3', name: 'Aberration', map: 'Aberration_P', players: { current: 0, max: 70 }, status: 'offline', isMain: false, mods: 15, lastRestart: '2024-01-18 04:00' },
    { id: '4', name: 'Genesis', map: 'Genesis', players: { current: 8, max: 70 }, status: 'starting', isMain: false, mods: 15, lastRestart: '2024-01-19 15:30' },
];

const ARKClusterManagerContainer: React.FC = () => {
    const [servers] = useState<ClusterServer[]>(mockServers);
    const [settings, setSettings] = useState<ClusterSettings>({
        name: 'My ARK Cluster',
        transfersEnabled: true,
        dinoTransfer: true,
        itemTransfer: true,
        characterTransfer: true,
        tributeDownload: false,
    });

    const toggleSetting = (key: keyof ClusterSettings) => {
        if (typeof settings[key] === 'boolean') {
            setSettings(prev => ({ ...prev, [key]: !prev[key] }));
        }
    };

    const totalPlayers = servers.reduce((acc, s) => acc + s.players.current, 0);
    const onlineServers = servers.filter(s => s.status === 'online').length;

    return (
        <Container>
            <PageHeader>
                <HeaderContent>
                    <HeaderInfo>
                        <GameLogo>ARK</GameLogo>
                        <HeaderText>
                            <PageTitle>ARK Cluster Manager</PageTitle>
                            <PageSubtitle>Manage your ARK server cluster and cross-server settings</PageSubtitle>
                        </HeaderText>
                    </HeaderInfo>
                    <HeaderActions>
                        <SecondaryButton>
                            <HiOutlineRefresh /> Restart All
                        </SecondaryButton>
                        <PrimaryButton>
                            <HiOutlinePlus /> Add Server
                        </PrimaryButton>
                    </HeaderActions>
                </HeaderContent>
            </PageHeader>

            <ClusterStats>
                <StatCard>
                    <StatLabel>Total Players</StatLabel>
                    <StatValue>{totalPlayers}</StatValue>
                </StatCard>
                <StatCard>
                    <StatLabel>Online Servers</StatLabel>
                    <StatValue>{onlineServers}/{servers.length}</StatValue>
                </StatCard>
                <StatCard>
                    <StatLabel>Active Mods</StatLabel>
                    <StatValue>15</StatValue>
                </StatCard>
                <StatCard>
                    <StatLabel>Cluster Size</StatLabel>
                    <StatValue>45.2 GB</StatValue>
                </StatCard>
            </ClusterStats>

            <ContentGrid>
                <div css={tw`flex flex-col gap-6`}>
                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineServer /> Cluster Servers
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <ServerList>
                                {servers.map(server => (
                                    <ServerCard key={server.id} $status={server.status}>
                                        <ServerHeader>
                                            <ServerInfo>
                                                <ServerIcon $status={server.status}>
                                                    <HiOutlineGlobe />
                                                </ServerIcon>
                                                <ServerDetails>
                                                    <ServerName>
                                                        {server.name}
                                                        {server.isMain && <MainBadge>Main</MainBadge>}
                                                    </ServerName>
                                                    <ServerMap>Map: {server.map}</ServerMap>
                                                </ServerDetails>
                                            </ServerInfo>
                                            <ServerStatus $status={server.status}>
                                                <span />
                                                {server.status}
                                            </ServerStatus>
                                        </ServerHeader>
                                        <ServerStats>
                                            <ServerStat>
                                                <ServerStatValue>{server.players.current}/{server.players.max}</ServerStatValue>
                                                <ServerStatLabel>Players</ServerStatLabel>
                                            </ServerStat>
                                            <ServerStat>
                                                <ServerStatValue>{server.mods}</ServerStatValue>
                                                <ServerStatLabel>Mods</ServerStatLabel>
                                            </ServerStat>
                                            <ServerStat>
                                                <ServerStatValue>128</ServerStatValue>
                                                <ServerStatLabel>Tick Rate</ServerStatLabel>
                                            </ServerStat>
                                        </ServerStats>
                                        <ServerActions>
                                            <IconButton>
                                                <HiOutlineCog /> Manage
                                            </IconButton>
                                            <IconButton>
                                                <HiOutlineRefresh /> Restart
                                            </IconButton>
                                            <IconButton $variant="danger">
                                                <HiOutlineTrash />
                                            </IconButton>
                                        </ServerActions>
                                    </ServerCard>
                                ))}
                                <AddServerButton>
                                    <HiOutlinePlus /> Add Server to Cluster
                                </AddServerButton>
                            </ServerList>
                        </CardBody>
                    </Card>
                </div>

                <div css={tw`flex flex-col gap-4`}>
                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineLink /> Cluster Settings
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <SettingItem>
                                <SettingLabel>Cross-Server Transfers</SettingLabel>
                                <ToggleSwitch>
                                    <input
                                        type="checkbox"
                                        checked={settings.transfersEnabled}
                                        onChange={() => toggleSetting('transfersEnabled')}
                                    />
                                    <span />
                                </ToggleSwitch>
                            </SettingItem>
                            <SettingItem>
                                <SettingLabel>Dino Transfers</SettingLabel>
                                <ToggleSwitch>
                                    <input
                                        type="checkbox"
                                        checked={settings.dinoTransfer}
                                        onChange={() => toggleSetting('dinoTransfer')}
                                    />
                                    <span />
                                </ToggleSwitch>
                            </SettingItem>
                            <SettingItem>
                                <SettingLabel>Item Transfers</SettingLabel>
                                <ToggleSwitch>
                                    <input
                                        type="checkbox"
                                        checked={settings.itemTransfer}
                                        onChange={() => toggleSetting('itemTransfer')}
                                    />
                                    <span />
                                </ToggleSwitch>
                            </SettingItem>
                            <SettingItem>
                                <SettingLabel>Character Transfers</SettingLabel>
                                <ToggleSwitch>
                                    <input
                                        type="checkbox"
                                        checked={settings.characterTransfer}
                                        onChange={() => toggleSetting('characterTransfer')}
                                    />
                                    <span />
                                </ToggleSwitch>
                            </SettingItem>
                            <SettingItem>
                                <SettingLabel>Tribute Downloads</SettingLabel>
                                <ToggleSwitch>
                                    <input
                                        type="checkbox"
                                        checked={settings.tributeDownload}
                                        onChange={() => toggleSetting('tributeDownload')}
                                    />
                                    <span />
                                </ToggleSwitch>
                            </SettingItem>
                        </CardBody>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineDatabase /> Cluster Data
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <div css={tw`flex flex-col gap-3`}>
                                <div css={tw`flex justify-between text-sm`}>
                                    <span style={{ color: '#5a7a9a' }}>Shared Cluster ID</span>
                                    <span style={{ color: '#00ff88', fontFamily: 'JetBrains Mono' }}>ark-cluster-01</span>
                                </div>
                                <div css={tw`flex justify-between text-sm`}>
                                    <span style={{ color: '#5a7a9a' }}>Cluster Data Size</span>
                                    <span style={{ color: '#ffffff' }}>2.4 GB</span>
                                </div>
                                <div css={tw`flex justify-between text-sm`}>
                                    <span style={{ color: '#5a7a9a' }}>Pending Transfers</span>
                                    <span style={{ color: '#ffcc00' }}>3 items</span>
                                </div>
                                <SecondaryButton css={tw`w-full justify-center mt-2`}>
                                    <HiOutlineTrash /> Clear Expired Transfers
                                </SecondaryButton>
                            </div>
                        </CardBody>
                    </Card>
                </div>
            </ContentGrid>
        </Container>
    );
};

export default ARKClusterManagerContainer;
