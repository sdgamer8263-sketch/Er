import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlinePuzzle, HiOutlineRefresh, HiOutlinePlay, HiOutlinePause, HiOutlineTrash, HiOutlinePlus, HiOutlineSearch, HiOutlineDownload, HiOutlineUpload, HiOutlineChevronUp, HiOutlineChevronDown, HiOutlineFolder } from 'react-icons/hi';

interface Resource {
    id: string;
    name: string;
    author: string;
    version: string;
    status: 'running' | 'stopped' | 'error';
    type: 'script' | 'map' | 'vehicle' | 'eup' | 'framework';
    dependencies: string[];
    loadOrder: number;
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #f97316, #fbbf24, #f97316);
    }
`;

const HeaderContent = styled.div`
    ${tw`flex items-center justify-between`}
`;

const HeaderInfo = styled.div`
    ${tw`flex items-center gap-4`}
`;

const GameLogo = styled.div`
    ${tw`w-16 h-16 rounded-xl flex items-center justify-center text-lg font-bold`}
    background: linear-gradient(135deg, #f97316 0%, #fbbf24 100%);
    color: #050a14;
    font-family: 'Rajdhani', sans-serif;
`;

const HeaderText = styled.div``;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const HeaderActions = styled.div`
    ${tw`flex gap-3`}
`;

const PrimaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: linear-gradient(135deg, #f97316 0%, #fbbf24 100%);
    color: #050a14;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(249, 115, 22, 0.3);
    }
`;

const SecondaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: rgba(26, 48, 80, 0.5);
    color: #a0b4c8;
    border: 1px solid rgba(26, 48, 80, 0.8);
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #00d4ff;
        color: #00d4ff;
    }
`;

const ResourceStats = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(4, 1fr);

    @media (max-width: 1000px) {
        grid-template-columns: repeat(2, 1fr);
    }
`;

const StatCard = styled.div<{ $color: string }>`
    ${tw`p-4 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 3px;
        height: 100%;
        background: ${props => props.$color};
    }
`;

const StatLabel = styled.span`
    ${tw`text-xs uppercase tracking-wide block mb-1`}
    color: #5a7a9a;
`;

const StatValue = styled.span<{ $color: string }>`
    ${tw`text-2xl font-bold`}
    color: ${props => props.$color};
    font-family: 'Rajdhani', sans-serif;
`;

const ToolbarContainer = styled.div`
    ${tw`flex items-center justify-between gap-4 p-4 rounded-xl`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const SearchBar = styled.div`
    ${tw`flex-1 relative`}
`;

const SearchInput = styled.input`
    ${tw`w-full pl-10 pr-4 py-2.5 rounded-lg text-sm`}
    background: rgba(5, 10, 20, 0.8);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #ffffff;
    font-family: 'Inter', sans-serif;

    &:focus {
        outline: none;
        border-color: #f97316;
    }

    &::placeholder {
        color: #5a7a9a;
    }
`;

const SearchIcon = styled.div`
    ${tw`absolute left-3 top-1/2 transform -translate-y-1/2`}
    color: #5a7a9a;
`;

const FilterTabs = styled.div`
    ${tw`flex gap-2`}
`;

const FilterTab = styled.button<{ $active?: boolean }>`
    ${tw`px-4 py-2 rounded-lg font-semibold text-xs uppercase`}
    background: ${props => props.$active ? 'linear-gradient(135deg, #f97316 0%, #fbbf24 100%)' : 'rgba(26, 48, 80, 0.5)'};
    color: ${props => props.$active ? '#050a14' : '#5a7a9a'};
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        color: ${props => props.$active ? '#050a14' : '#ffffff'};
    }
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const ResourceList = styled.div`
    ${tw`max-h-[600px] overflow-y-auto`}
`;

const ResourceItem = styled.div<{ $status: string }>`
    ${tw`flex items-center justify-between p-4`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.5);
    opacity: ${props => props.$status === 'stopped' ? 0.6 : 1};
    transition: all 0.3s ease;

    &:hover {
        background: rgba(15, 31, 61, 0.5);
    }

    &:last-child {
        border-bottom: none;
    }
`;

const ResourceInfo = styled.div`
    ${tw`flex items-center gap-3`}
`;

const ResourceIcon = styled.div<{ $type: string }>`
    ${tw`w-10 h-10 rounded-lg flex items-center justify-center text-lg`}
    background: ${props => {
        switch(props.$type) {
            case 'script': return 'rgba(0, 212, 255, 0.15)';
            case 'map': return 'rgba(0, 255, 136, 0.15)';
            case 'vehicle': return 'rgba(168, 85, 247, 0.15)';
            case 'eup': return 'rgba(255, 204, 0, 0.15)';
            case 'framework': return 'rgba(249, 115, 22, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$type) {
            case 'script': return '#00d4ff';
            case 'map': return '#00ff88';
            case 'vehicle': return '#a855f7';
            case 'eup': return '#ffcc00';
            case 'framework': return '#f97316';
            default: return '#5a7a9a';
        }
    }};
`;

const ResourceDetails = styled.div``;

const ResourceName = styled.h4`
    ${tw`text-sm font-semibold flex items-center gap-2`}
    color: #ffffff;
`;

const ResourceMeta = styled.div`
    ${tw`flex items-center gap-3 text-xs mt-1`}
    color: #5a7a9a;
`;

const ResourceBadge = styled.span<{ $type: string }>`
    ${tw`px-2 py-0.5 rounded text-xs uppercase`}
    background: ${props => {
        switch(props.$type) {
            case 'script': return 'rgba(0, 212, 255, 0.15)';
            case 'map': return 'rgba(0, 255, 136, 0.15)';
            case 'vehicle': return 'rgba(168, 85, 247, 0.15)';
            case 'eup': return 'rgba(255, 204, 0, 0.15)';
            case 'framework': return 'rgba(249, 115, 22, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$type) {
            case 'script': return '#00d4ff';
            case 'map': return '#00ff88';
            case 'vehicle': return '#a855f7';
            case 'eup': return '#ffcc00';
            case 'framework': return '#f97316';
            default: return '#5a7a9a';
        }
    }};
`;

const ResourceActions = styled.div`
    ${tw`flex items-center gap-2`}
`;

const IconButton = styled.button<{ $variant?: 'primary' | 'danger' | 'success' }>`
    ${tw`w-8 h-8 rounded-lg flex items-center justify-center`}
    background: ${props => {
        switch(props.$variant) {
            case 'danger': return 'rgba(255, 51, 102, 0.15)';
            case 'success': return 'rgba(0, 255, 136, 0.15)';
            case 'primary': return 'rgba(249, 115, 22, 0.15)';
            default: return 'rgba(26, 48, 80, 0.5)';
        }
    }};
    border: 1px solid ${props => {
        switch(props.$variant) {
            case 'danger': return 'rgba(255, 51, 102, 0.5)';
            case 'success': return 'rgba(0, 255, 136, 0.5)';
            case 'primary': return 'rgba(249, 115, 22, 0.5)';
            default: return 'rgba(26, 48, 80, 0.8)';
        }
    }};
    color: ${props => {
        switch(props.$variant) {
            case 'danger': return '#ff3366';
            case 'success': return '#00ff88';
            case 'primary': return '#f97316';
            default: return '#a0b4c8';
        }
    }};
    cursor: pointer;
    transition: all 0.3s ease;

    &:hover {
        transform: scale(1.1);
    }
`;

const StatusDot = styled.span<{ $status: string }>`
    ${tw`w-2 h-2 rounded-full`}
    background: ${props => {
        switch(props.$status) {
            case 'running': return '#00ff88';
            case 'stopped': return '#5a7a9a';
            case 'error': return '#ff3366';
            default: return '#5a7a9a';
        }
    }};
`;

// Mock data
const mockResources: Resource[] = [
    { id: '1', name: 'es_extended', author: 'ESX Team', version: '1.10.2', status: 'running', type: 'framework', dependencies: [], loadOrder: 1 },
    { id: '2', name: 'esx_society', author: 'ESX Team', version: '1.0.0', status: 'running', type: 'script', dependencies: ['es_extended'], loadOrder: 2 },
    { id: '3', name: 'esx_jobs', author: 'ESX Team', version: '1.1.0', status: 'running', type: 'script', dependencies: ['es_extended', 'esx_society'], loadOrder: 3 },
    { id: '4', name: 'esx_policejob', author: 'ESX Team', version: '1.0.5', status: 'running', type: 'script', dependencies: ['es_extended'], loadOrder: 4 },
    { id: '5', name: 'esx_ambulancejob', author: 'ESX Team', version: '1.0.3', status: 'stopped', type: 'script', dependencies: ['es_extended'], loadOrder: 5 },
    { id: '6', name: 'vehicle_pack_premium', author: 'Custom', version: '2.0.0', status: 'running', type: 'vehicle', dependencies: [], loadOrder: 10 },
    { id: '7', name: 'eup_stream', author: 'EUP Team', version: '8.2', status: 'running', type: 'eup', dependencies: [], loadOrder: 11 },
    { id: '8', name: 'custom_map_mrpd', author: 'MapBuilder', version: '1.0.0', status: 'error', type: 'map', dependencies: [], loadOrder: 12 },
];

const FiveMResourceController: React.FC = () => {
    const [resources, setResources] = useState<Resource[]>(mockResources);
    const [searchQuery, setSearchQuery] = useState('');
    const [activeFilter, setActiveFilter] = useState<string>('all');

    const toggleResource = (id: string) => {
        setResources(prev => prev.map(r =>
            r.id === id ? { ...r, status: r.status === 'running' ? 'stopped' : 'running' } : r
        ));
    };

    const moveResource = (id: string, direction: 'up' | 'down') => {
        const index = resources.findIndex(r => r.id === id);
        if (direction === 'up' && index > 0) {
            const newResources = [...resources];
            [newResources[index - 1], newResources[index]] = [newResources[index], newResources[index - 1]];
            setResources(newResources);
        } else if (direction === 'down' && index < resources.length - 1) {
            const newResources = [...resources];
            [newResources[index], newResources[index + 1]] = [newResources[index + 1], newResources[index]];
            setResources(newResources);
        }
    };

    const filteredResources = resources.filter(r => {
        const matchesSearch = r.name.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesFilter = activeFilter === 'all' || r.type === activeFilter;
        return matchesSearch && matchesFilter;
    });

    const runningCount = resources.filter(r => r.status === 'running').length;
    const errorCount = resources.filter(r => r.status === 'error').length;

    return (
        <Container>
            <PageHeader>
                <HeaderContent>
                    <HeaderInfo>
                        <GameLogo>FiveM</GameLogo>
                        <HeaderText>
                            <PageTitle>FiveM Resource Controller</PageTitle>
                            <PageSubtitle>Manage server resources, scripts, and load order</PageSubtitle>
                        </HeaderText>
                    </HeaderInfo>
                    <HeaderActions>
                        <SecondaryButton>
                            <HiOutlineDownload /> Import
                        </SecondaryButton>
                        <PrimaryButton>
                            <HiOutlinePlus /> Add Resource
                        </PrimaryButton>
                    </HeaderActions>
                </HeaderContent>
            </PageHeader>

            <ResourceStats>
                <StatCard $color="#f97316">
                    <StatLabel>Total Resources</StatLabel>
                    <StatValue $color="#f97316">{resources.length}</StatValue>
                </StatCard>
                <StatCard $color="#00ff88">
                    <StatLabel>Running</StatLabel>
                    <StatValue $color="#00ff88">{runningCount}</StatValue>
                </StatCard>
                <StatCard $color="#5a7a9a">
                    <StatLabel>Stopped</StatLabel>
                    <StatValue $color="#5a7a9a">{resources.length - runningCount - errorCount}</StatValue>
                </StatCard>
                <StatCard $color="#ff3366">
                    <StatLabel>Errors</StatLabel>
                    <StatValue $color="#ff3366">{errorCount}</StatValue>
                </StatCard>
            </ResourceStats>

            <ToolbarContainer>
                <SearchBar>
                    <SearchIcon><HiOutlineSearch /></SearchIcon>
                    <SearchInput
                        type="text"
                        placeholder="Search resources..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </SearchBar>
                <FilterTabs>
                    <FilterTab $active={activeFilter === 'all'} onClick={() => setActiveFilter('all')}>All</FilterTab>
                    <FilterTab $active={activeFilter === 'framework'} onClick={() => setActiveFilter('framework')}>Framework</FilterTab>
                    <FilterTab $active={activeFilter === 'script'} onClick={() => setActiveFilter('script')}>Scripts</FilterTab>
                    <FilterTab $active={activeFilter === 'vehicle'} onClick={() => setActiveFilter('vehicle')}>Vehicles</FilterTab>
                    <FilterTab $active={activeFilter === 'map'} onClick={() => setActiveFilter('map')}>Maps</FilterTab>
                </FilterTabs>
            </ToolbarContainer>

            <Card>
                <CardHeader>
                    <CardTitle>
                        <HiOutlinePuzzle /> Resources ({filteredResources.length})
                    </CardTitle>
                    <SecondaryButton>
                        <HiOutlineRefresh /> Refresh All
                    </SecondaryButton>
                </CardHeader>
                <ResourceList>
                    {filteredResources.map((resource, index) => (
                        <ResourceItem key={resource.id} $status={resource.status}>
                            <ResourceInfo>
                                <ResourceIcon $type={resource.type}>
                                    <HiOutlinePuzzle />
                                </ResourceIcon>
                                <ResourceDetails>
                                    <ResourceName>
                                        <StatusDot $status={resource.status} />
                                        {resource.name}
                                    </ResourceName>
                                    <ResourceMeta>
                                        <span>v{resource.version}</span>
                                        <span>by {resource.author}</span>
                                        <ResourceBadge $type={resource.type}>{resource.type}</ResourceBadge>
                                    </ResourceMeta>
                                </ResourceDetails>
                            </ResourceInfo>
                            <ResourceActions>
                                <IconButton onClick={() => moveResource(resource.id, 'up')} title="Move Up">
                                    <HiOutlineChevronUp />
                                </IconButton>
                                <IconButton onClick={() => moveResource(resource.id, 'down')} title="Move Down">
                                    <HiOutlineChevronDown />
                                </IconButton>
                                <IconButton
                                    $variant={resource.status === 'running' ? 'success' : undefined}
                                    onClick={() => toggleResource(resource.id)}
                                    title={resource.status === 'running' ? 'Stop' : 'Start'}
                                >
                                    {resource.status === 'running' ? <HiOutlinePause /> : <HiOutlinePlay />}
                                </IconButton>
                                <IconButton title="Restart">
                                    <HiOutlineRefresh />
                                </IconButton>
                                <IconButton $variant="danger" title="Delete">
                                    <HiOutlineTrash />
                                </IconButton>
                            </ResourceActions>
                        </ResourceItem>
                    ))}
                </ResourceList>
            </Card>
        </Container>
    );
};

export default FiveMResourceController;
