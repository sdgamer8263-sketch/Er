import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineMap, HiOutlineCog, HiOutlineUsers, HiOutlineRefresh, HiOutlineSave, HiOutlinePlay, HiOutlinePause, HiOutlineChevronUp, HiOutlineChevronDown } from 'react-icons/hi';

interface Map {
    id: string;
    name: string;
    workshopId?: string;
    enabled: boolean;
    order: number;
}

interface Preset {
    id: string;
    name: string;
    description: string;
    type: 'competitive' | 'casual' | 'wingman' | 'deathmatch' | 'custom';
    settings: Record<string, any>;
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #ff6b00, #ffcc00, #ff6b00);
    }
`;

const HeaderContent = styled.div`
    ${tw`flex items-center justify-between`}
`;

const HeaderInfo = styled.div`
    ${tw`flex items-center gap-4`}
`;

const GameLogo = styled.div`
    ${tw`w-16 h-16 rounded-xl flex items-center justify-center text-2xl font-bold`}
    background: linear-gradient(135deg, #ff6b00 0%, #ffcc00 100%);
    color: #050a14;
    font-family: 'Rajdhani', sans-serif;
`;

const HeaderText = styled.div``;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const HeaderActions = styled.div`
    ${tw`flex gap-3`}
`;

const PrimaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: linear-gradient(135deg, #ff6b00 0%, #ffcc00 100%);
    color: #050a14;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(255, 107, 0, 0.3);
    }
`;

const SecondaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: rgba(26, 48, 80, 0.5);
    color: #a0b4c8;
    border: 1px solid rgba(26, 48, 80, 0.8);
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #00d4ff;
        color: #00d4ff;
    }
`;

const ContentGrid = styled.div`
    ${tw`grid gap-6`}
    grid-template-columns: 1fr 400px;

    @media (max-width: 1200px) {
        grid-template-columns: 1fr;
    }
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const CardBody = styled.div`
    ${tw`p-5`}
`;

const TabsContainer = styled.div`
    ${tw`flex gap-2 mb-4`}
`;

const Tab = styled.button<{ $active?: boolean }>`
    ${tw`px-4 py-2 rounded-lg font-semibold text-sm uppercase tracking-wide`}
    background: ${props => props.$active ? 'linear-gradient(135deg, #ff6b00 0%, #ffcc00 100%)' : 'rgba(26, 48, 80, 0.5)'};
    color: ${props => props.$active ? '#050a14' : '#5a7a9a'};
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        color: ${props => props.$active ? '#050a14' : '#ffffff'};
    }
`;

const PresetsGrid = styled.div`
    ${tw`grid gap-3`}
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
`;

const PresetCard = styled.div<{ $active?: boolean }>`
    ${tw`p-4 rounded-xl cursor-pointer`}
    background: ${props => props.$active
        ? 'linear-gradient(145deg, rgba(255, 107, 0, 0.15) 0%, rgba(255, 204, 0, 0.1) 100%)'
        : 'rgba(15, 31, 61, 0.5)'};
    border: 2px solid ${props => props.$active ? '#ff6b00' : 'rgba(26, 48, 80, 0.8)'};
    transition: all 0.3s ease;

    &:hover {
        border-color: ${props => props.$active ? '#ff6b00' : '#00d4ff'};
    }
`;

const PresetIcon = styled.div<{ $type: string }>`
    ${tw`w-10 h-10 rounded-lg flex items-center justify-center text-lg mb-3`}
    background: ${props => {
        switch(props.$type) {
            case 'competitive': return 'rgba(255, 107, 0, 0.15)';
            case 'casual': return 'rgba(0, 212, 255, 0.15)';
            case 'wingman': return 'rgba(168, 85, 247, 0.15)';
            case 'deathmatch': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(0, 255, 136, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$type) {
            case 'competitive': return '#ff6b00';
            case 'casual': return '#00d4ff';
            case 'wingman': return '#a855f7';
            case 'deathmatch': return '#ff3366';
            default: return '#00ff88';
        }
    }};
`;

const PresetName = styled.h4`
    ${tw`text-sm font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PresetDesc = styled.p`
    ${tw`text-xs`}
    color: #5a7a9a;
`;

const MapList = styled.div`
    ${tw`flex flex-col gap-2`}
`;

const MapItem = styled.div<{ $enabled: boolean }>`
    ${tw`flex items-center justify-between p-3 rounded-lg`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.6);
    opacity: ${props => props.$enabled ? 1 : 0.5};
    transition: all 0.3s ease;

    &:hover {
        border-color: rgba(42, 74, 106, 0.8);
    }
`;

const MapInfo = styled.div`
    ${tw`flex items-center gap-3`}
`;

const MapIcon = styled.div`
    ${tw`w-10 h-10 rounded-lg flex items-center justify-center`}
    background: rgba(0, 212, 255, 0.15);
    color: #00d4ff;
`;

const MapName = styled.span`
    ${tw`text-sm font-semibold`}
    color: #ffffff;
`;

const MapWorkshop = styled.span`
    ${tw`text-xs`}
    color: #5a7a9a;
`;

const MapActions = styled.div`
    ${tw`flex gap-2`}
`;

const IconButton = styled.button<{ $variant?: 'primary' | 'danger' }>`
    ${tw`w-8 h-8 rounded-lg flex items-center justify-center`}
    background: ${props => props.$variant === 'primary' ? 'rgba(0, 212, 255, 0.15)' : 'rgba(26, 48, 80, 0.5)'};
    border: 1px solid ${props => props.$variant === 'primary' ? 'rgba(0, 212, 255, 0.5)' : 'rgba(26, 48, 80, 0.8)'};
    color: ${props => props.$variant === 'primary' ? '#00d4ff' : '#a0b4c8'};
    cursor: pointer;
    transition: all 0.3s ease;

    &:hover {
        transform: scale(1.1);
    }
`;

const ToggleSwitch = styled.label`
    ${tw`relative inline-block w-10 h-5 cursor-pointer`}

    input {
        ${tw`opacity-0 w-0 h-0`}
    }

    span {
        ${tw`absolute inset-0 rounded-full transition-colors`}
        background: rgba(26, 48, 80, 0.8);

        &::before {
            content: '';
            ${tw`absolute w-4 h-4 rounded-full transition-transform`}
            background: #ffffff;
            top: 2px;
            left: 2px;
        }
    }

    input:checked + span {
        background: linear-gradient(135deg, #ff6b00 0%, #ffcc00 100%);
    }

    input:checked + span::before {
        transform: translateX(20px);
    }
`;

const SettingsGrid = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(2, 1fr);
`;

const SettingItem = styled.div`
    ${tw`flex items-center justify-between p-3 rounded-lg`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.6);
`;

const SettingLabel = styled.span`
    ${tw`text-sm`}
    color: #a0b4c8;
`;

const SettingValue = styled.input`
    ${tw`w-20 px-2 py-1 rounded text-sm text-right`}
    background: rgba(5, 10, 20, 0.8);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #ffffff;
    font-family: 'JetBrains Mono', monospace;

    &:focus {
        outline: none;
        border-color: #ff6b00;
    }
`;

const QuickStats = styled.div`
    ${tw`grid grid-cols-2 gap-3 mb-4`}
`;

const QuickStat = styled.div`
    ${tw`p-3 rounded-lg text-center`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.6);
`;

const QuickStatValue = styled.span`
    ${tw`text-xl font-bold block`}
    color: #ff6b00;
    font-family: 'Rajdhani', sans-serif;
`;

const QuickStatLabel = styled.span`
    ${tw`text-xs`}
    color: #5a7a9a;
`;

// Mock data
const mockPresets: Preset[] = [
    { id: '1', name: 'Competitive', description: '5v5 Ranked Mode', type: 'competitive', settings: {} },
    { id: '2', name: 'Casual', description: '10v10 Fun Mode', type: 'casual', settings: {} },
    { id: '3', name: 'Wingman', description: '2v2 Ranked', type: 'wingman', settings: {} },
    { id: '4', name: 'Deathmatch', description: 'FFA Deathmatch', type: 'deathmatch', settings: {} },
    { id: '5', name: 'Custom', description: 'Your Settings', type: 'custom', settings: {} },
];

const mockMaps: Map[] = [
    { id: '1', name: 'de_dust2', enabled: true, order: 1 },
    { id: '2', name: 'de_mirage', enabled: true, order: 2 },
    { id: '3', name: 'de_inferno', enabled: true, order: 3 },
    { id: '4', name: 'de_nuke', enabled: true, order: 4 },
    { id: '5', name: 'de_ancient', enabled: false, order: 5 },
    { id: '6', name: 'de_anubis', enabled: true, order: 6 },
    { id: '7', name: 'de_vertigo', enabled: false, order: 7 },
];

const CS2ManagerContainer: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'presets' | 'maps' | 'settings'>('presets');
    const [selectedPreset, setSelectedPreset] = useState<string>('1');
    const [maps, setMaps] = useState<Map[]>(mockMaps);

    const toggleMap = (id: string) => {
        setMaps(prev => prev.map(map =>
            map.id === id ? { ...map, enabled: !map.enabled } : map
        ));
    };

    const moveMap = (id: string, direction: 'up' | 'down') => {
        const index = maps.findIndex(m => m.id === id);
        if (direction === 'up' && index > 0) {
            const newMaps = [...maps];
            [newMaps[index - 1], newMaps[index]] = [newMaps[index], newMaps[index - 1]];
            setMaps(newMaps);
        } else if (direction === 'down' && index < maps.length - 1) {
            const newMaps = [...maps];
            [newMaps[index], newMaps[index + 1]] = [newMaps[index + 1], newMaps[index]];
            setMaps(newMaps);
        }
    };

    return (
        <Container>
            <PageHeader>
                <HeaderContent>
                    <HeaderInfo>
                        <GameLogo>CS2</GameLogo>
                        <HeaderText>
                            <PageTitle>Counter-Strike 2 Manager</PageTitle>
                            <PageSubtitle>Configure presets, map rotation, and server settings</PageSubtitle>
                        </HeaderText>
                    </HeaderInfo>
                    <HeaderActions>
                        <SecondaryButton>
                            <HiOutlineRefresh /> Restart Server
                        </SecondaryButton>
                        <PrimaryButton>
                            <HiOutlineSave /> Save & Apply
                        </PrimaryButton>
                    </HeaderActions>
                </HeaderContent>
            </PageHeader>

            <ContentGrid>
                <div css={tw`flex flex-col gap-6`}>
                    <Card>
                        <CardHeader>
                            <TabsContainer>
                                <Tab $active={activeTab === 'presets'} onClick={() => setActiveTab('presets')}>
                                    <HiOutlineCog css={tw`inline mr-1`} /> Presets
                                </Tab>
                                <Tab $active={activeTab === 'maps'} onClick={() => setActiveTab('maps')}>
                                    <HiOutlineMap css={tw`inline mr-1`} /> Map Rotation
                                </Tab>
                                <Tab $active={activeTab === 'settings'} onClick={() => setActiveTab('settings')}>
                                    <HiOutlineUsers css={tw`inline mr-1`} /> Settings
                                </Tab>
                            </TabsContainer>
                        </CardHeader>
                        <CardBody>
                            {activeTab === 'presets' && (
                                <PresetsGrid>
                                    {mockPresets.map(preset => (
                                        <PresetCard
                                            key={preset.id}
                                            $active={selectedPreset === preset.id}
                                            onClick={() => setSelectedPreset(preset.id)}
                                        >
                                            <PresetIcon $type={preset.type}>
                                                <HiOutlineCog />
                                            </PresetIcon>
                                            <PresetName>{preset.name}</PresetName>
                                            <PresetDesc>{preset.description}</PresetDesc>
                                        </PresetCard>
                                    ))}
                                </PresetsGrid>
                            )}

                            {activeTab === 'maps' && (
                                <MapList>
                                    {maps.map((map, index) => (
                                        <MapItem key={map.id} $enabled={map.enabled}>
                                            <MapInfo>
                                                <MapIcon>
                                                    <HiOutlineMap />
                                                </MapIcon>
                                                <div>
                                                    <MapName>{map.name}</MapName>
                                                    {map.workshopId && (
                                                        <MapWorkshop>Workshop: {map.workshopId}</MapWorkshop>
                                                    )}
                                                </div>
                                            </MapInfo>
                                            <MapActions>
                                                <IconButton onClick={() => moveMap(map.id, 'up')} disabled={index === 0}>
                                                    <HiOutlineChevronUp />
                                                </IconButton>
                                                <IconButton onClick={() => moveMap(map.id, 'down')} disabled={index === maps.length - 1}>
                                                    <HiOutlineChevronDown />
                                                </IconButton>
                                                <ToggleSwitch>
                                                    <input
                                                        type="checkbox"
                                                        checked={map.enabled}
                                                        onChange={() => toggleMap(map.id)}
                                                    />
                                                    <span />
                                                </ToggleSwitch>
                                            </MapActions>
                                        </MapItem>
                                    ))}
                                </MapList>
                            )}

                            {activeTab === 'settings' && (
                                <SettingsGrid>
                                    <SettingItem>
                                        <SettingLabel>Max Players</SettingLabel>
                                        <SettingValue type="number" defaultValue="10" />
                                    </SettingItem>
                                    <SettingItem>
                                        <SettingLabel>Tick Rate</SettingLabel>
                                        <SettingValue type="number" defaultValue="128" />
                                    </SettingItem>
                                    <SettingItem>
                                        <SettingLabel>Round Time (sec)</SettingLabel>
                                        <SettingValue type="number" defaultValue="115" />
                                    </SettingItem>
                                    <SettingItem>
                                        <SettingLabel>Freeze Time (sec)</SettingLabel>
                                        <SettingValue type="number" defaultValue="15" />
                                    </SettingItem>
                                    <SettingItem>
                                        <SettingLabel>Buy Time (sec)</SettingLabel>
                                        <SettingValue type="number" defaultValue="20" />
                                    </SettingItem>
                                    <SettingItem>
                                        <SettingLabel>Max Rounds</SettingLabel>
                                        <SettingValue type="number" defaultValue="24" />
                                    </SettingItem>
                                </SettingsGrid>
                            )}
                        </CardBody>
                    </Card>
                </div>

                <div css={tw`flex flex-col gap-4`}>
                    <Card>
                        <CardHeader>
                            <CardTitle>Quick Stats</CardTitle>
                        </CardHeader>
                        <CardBody>
                            <QuickStats>
                                <QuickStat>
                                    <QuickStatValue>8/10</QuickStatValue>
                                    <QuickStatLabel>Players Online</QuickStatLabel>
                                </QuickStat>
                                <QuickStat>
                                    <QuickStatValue>de_dust2</QuickStatValue>
                                    <QuickStatLabel>Current Map</QuickStatLabel>
                                </QuickStat>
                                <QuickStat>
                                    <QuickStatValue>12</QuickStatValue>
                                    <QuickStatLabel>Current Round</QuickStatLabel>
                                </QuickStat>
                                <QuickStat>
                                    <QuickStatValue>128</QuickStatValue>
                                    <QuickStatLabel>Tick Rate</QuickStatLabel>
                                </QuickStat>
                            </QuickStats>
                        </CardBody>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>Quick Actions</CardTitle>
                        </CardHeader>
                        <CardBody>
                            <div css={tw`flex flex-col gap-2`}>
                                <SecondaryButton css={tw`w-full justify-center`}>
                                    <HiOutlineMap /> Change Map
                                </SecondaryButton>
                                <SecondaryButton css={tw`w-full justify-center`}>
                                    <HiOutlineRefresh /> Restart Match
                                </SecondaryButton>
                                <SecondaryButton css={tw`w-full justify-center`}>
                                    <HiOutlineUsers /> Kick All Bots
                                </SecondaryButton>
                            </div>
                        </CardBody>
                    </Card>
                </div>
            </ContentGrid>
        </Container>
    );
};

export default CS2ManagerContainer;
