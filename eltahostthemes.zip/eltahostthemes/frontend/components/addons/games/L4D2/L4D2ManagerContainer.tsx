import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineMap, HiOutlinePlay, HiOutlineCog, HiOutlineUsers, HiOutlineRefresh, HiOutlineSave, HiOutlineLightningBolt, HiOutlineChevronRight } from 'react-icons/hi';

interface Campaign {
    id: string;
    name: string;
    maps: number;
    difficulty: 'easy' | 'normal' | 'advanced' | 'expert';
    enabled: boolean;
    isWorkshop: boolean;
}

interface Mutation {
    id: string;
    name: string;
    description: string;
    type: 'official' | 'custom';
    enabled: boolean;
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #dc2626, #ef4444, #dc2626);
    }
`;

const HeaderContent = styled.div`
    ${tw`flex items-center justify-between`}
`;

const HeaderInfo = styled.div`
    ${tw`flex items-center gap-4`}
`;

const GameLogo = styled.div`
    ${tw`w-16 h-16 rounded-xl flex items-center justify-center text-lg font-bold`}
    background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const HeaderText = styled.div``;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const HeaderActions = styled.div`
    ${tw`flex gap-3`}
`;

const PrimaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
    color: #ffffff;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(220, 38, 38, 0.3);
    }
`;

const SecondaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: rgba(26, 48, 80, 0.5);
    color: #a0b4c8;
    border: 1px solid rgba(26, 48, 80, 0.8);
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #00d4ff;
        color: #00d4ff;
    }
`;

const ContentGrid = styled.div`
    ${tw`grid gap-6`}
    grid-template-columns: 1fr 380px;

    @media (max-width: 1200px) {
        grid-template-columns: 1fr;
    }
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const CardBody = styled.div`
    ${tw`p-5`}
`;

const TabsContainer = styled.div`
    ${tw`flex gap-2 mb-4`}
`;

const Tab = styled.button<{ $active?: boolean }>`
    ${tw`px-4 py-2 rounded-lg font-semibold text-sm uppercase tracking-wide`}
    background: ${props => props.$active ? 'linear-gradient(135deg, #dc2626 0%, #ef4444 100%)' : 'rgba(26, 48, 80, 0.5)'};
    color: ${props => props.$active ? '#ffffff' : '#5a7a9a'};
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        color: #ffffff;
    }
`;

const CampaignList = styled.div`
    ${tw`flex flex-col gap-3`}
`;

const CampaignCard = styled.div<{ $enabled: boolean }>`
    ${tw`p-4 rounded-xl`}
    background: ${props => props.$enabled ? 'rgba(15, 31, 61, 0.5)' : 'rgba(15, 31, 61, 0.3)'};
    border: 1px solid ${props => props.$enabled ? 'rgba(220, 38, 38, 0.5)' : 'rgba(26, 48, 80, 0.6)'};
    opacity: ${props => props.$enabled ? 1 : 0.6};
    transition: all 0.3s ease;

    &:hover {
        border-color: ${props => props.$enabled ? '#dc2626' : '#00d4ff'};
    }
`;

const CampaignHeader = styled.div`
    ${tw`flex items-center justify-between mb-3`}
`;

const CampaignInfo = styled.div`
    ${tw`flex items-center gap-3`}
`;

const CampaignIcon = styled.div`
    ${tw`w-12 h-12 rounded-lg flex items-center justify-center text-xl`}
    background: rgba(220, 38, 38, 0.15);
    border: 1px solid rgba(220, 38, 38, 0.5);
    color: #ef4444;
`;

const CampaignDetails = styled.div``;

const CampaignName = styled.h4`
    ${tw`text-sm font-bold flex items-center gap-2`}
    color: #ffffff;
`;

const WorkshopBadge = styled.span`
    ${tw`px-2 py-0.5 rounded text-xs uppercase`}
    background: rgba(168, 85, 247, 0.15);
    color: #a855f7;
`;

const CampaignMeta = styled.div`
    ${tw`flex items-center gap-3 text-xs mt-1`}
    color: #5a7a9a;
`;

const DifficultyBadge = styled.span<{ $difficulty: string }>`
    ${tw`px-2 py-0.5 rounded text-xs uppercase font-bold`}
    background: ${props => {
        switch(props.$difficulty) {
            case 'easy': return 'rgba(0, 255, 136, 0.15)';
            case 'normal': return 'rgba(0, 212, 255, 0.15)';
            case 'advanced': return 'rgba(255, 204, 0, 0.15)';
            case 'expert': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$difficulty) {
            case 'easy': return '#00ff88';
            case 'normal': return '#00d4ff';
            case 'advanced': return '#ffcc00';
            case 'expert': return '#ff3366';
            default: return '#5a7a9a';
        }
    }};
`;

const ToggleSwitch = styled.label`
    ${tw`relative inline-block w-12 h-6 cursor-pointer`}

    input {
        ${tw`opacity-0 w-0 h-0`}
    }

    span {
        ${tw`absolute inset-0 rounded-full transition-colors`}
        background: rgba(26, 48, 80, 0.8);

        &::before {
            content: '';
            ${tw`absolute w-5 h-5 rounded-full transition-transform`}
            background: #ffffff;
            top: 2px;
            left: 2px;
        }
    }

    input:checked + span {
        background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
    }

    input:checked + span::before {
        transform: translateX(24px);
    }
`;

const MutationList = styled.div`
    ${tw`flex flex-col gap-2`}
`;

const MutationItem = styled.div<{ $enabled: boolean }>`
    ${tw`flex items-center justify-between p-3 rounded-lg`}
    background: ${props => props.$enabled ? 'rgba(220, 38, 38, 0.1)' : 'rgba(15, 31, 61, 0.5)'};
    border: 1px solid ${props => props.$enabled ? 'rgba(220, 38, 38, 0.3)' : 'rgba(26, 48, 80, 0.6)'};
    transition: all 0.3s ease;
`;

const MutationInfo = styled.div`
    ${tw`flex items-center gap-3`}
`;

const MutationIcon = styled.div<{ $enabled: boolean }>`
    ${tw`w-8 h-8 rounded-lg flex items-center justify-center text-sm`}
    background: ${props => props.$enabled ? 'rgba(220, 38, 38, 0.15)' : 'rgba(26, 48, 80, 0.5)'};
    color: ${props => props.$enabled ? '#ef4444' : '#5a7a9a'};
`;

const MutationDetails = styled.div``;

const MutationName = styled.span`
    ${tw`text-sm font-semibold block`}
    color: #ffffff;
`;

const MutationDesc = styled.span`
    ${tw`text-xs`}
    color: #5a7a9a;
`;

const ServerSettings = styled.div`
    ${tw`flex flex-col gap-4`}
`;

const SettingItem = styled.div`
    ${tw`flex items-center justify-between p-3 rounded-lg`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.6);
`;

const SettingLabel = styled.span`
    ${tw`text-sm`}
    color: #a0b4c8;
`;

const SettingValue = styled.select`
    ${tw`px-3 py-1.5 rounded-lg text-sm`}
    background: rgba(5, 10, 20, 0.8);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #ffffff;

    &:focus {
        outline: none;
        border-color: #dc2626;
    }

    option {
        background: #0a1628;
    }
`;

const QuickActions = styled.div`
    ${tw`flex flex-col gap-2`}
`;

const QuickActionButton = styled.button`
    ${tw`w-full py-3 px-4 rounded-lg font-semibold text-sm flex items-center justify-between`}
    background: rgba(26, 48, 80, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #a0b4c8;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #dc2626;
        color: #dc2626;
    }
`;

const CurrentGame = styled.div`
    ${tw`p-4 rounded-xl mb-4`}
    background: linear-gradient(145deg, rgba(220, 38, 38, 0.1) 0%, rgba(239, 68, 68, 0.05) 100%);
    border: 1px solid rgba(220, 38, 38, 0.3);
`;

const CurrentLabel = styled.span`
    ${tw`text-xs uppercase tracking-wide block mb-2`}
    color: #ef4444;
    font-family: 'Rajdhani', sans-serif;
`;

const CurrentValue = styled.span`
    ${tw`text-lg font-bold block`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const CurrentMeta = styled.span`
    ${tw`text-sm block mt-1`}
    color: #5a7a9a;
`;

// Mock data
const mockCampaigns: Campaign[] = [
    { id: '1', name: 'Dead Center', maps: 4, difficulty: 'normal', enabled: true, isWorkshop: false },
    { id: '2', name: 'Dark Carnival', maps: 5, difficulty: 'normal', enabled: true, isWorkshop: false },
    { id: '3', name: 'Swamp Fever', maps: 4, difficulty: 'advanced', enabled: true, isWorkshop: false },
    { id: '4', name: 'Hard Rain', maps: 5, difficulty: 'expert', enabled: false, isWorkshop: false },
    { id: '5', name: 'The Parish', maps: 5, difficulty: 'normal', enabled: true, isWorkshop: false },
    { id: '6', name: 'Custom Campaign: City 17', maps: 6, difficulty: 'advanced', enabled: true, isWorkshop: true },
];

const mockMutations: Mutation[] = [
    { id: '1', name: 'Realism', description: 'No glows, headshots only', type: 'official', enabled: false },
    { id: '2', name: 'Versus', description: 'Players control infected', type: 'official', enabled: true },
    { id: '3', name: 'Survival', description: 'Hold out as long as possible', type: 'official', enabled: false },
    { id: '4', name: 'Scavenge', description: 'Collect gas cans', type: 'official', enabled: false },
    { id: '5', name: 'Last Man On Earth', description: 'Solo survival mode', type: 'custom', enabled: false },
    { id: '6', name: 'Gib Fest', description: 'Explosive kills only', type: 'custom', enabled: false },
];

const L4D2ManagerContainer: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'campaigns' | 'mutations'>('campaigns');
    const [campaigns, setCampaigns] = useState<Campaign[]>(mockCampaigns);
    const [mutations, setMutations] = useState<Mutation[]>(mockMutations);

    const toggleCampaign = (id: string) => {
        setCampaigns(prev => prev.map(c =>
            c.id === id ? { ...c, enabled: !c.enabled } : c
        ));
    };

    const toggleMutation = (id: string) => {
        setMutations(prev => prev.map(m =>
            m.id === id ? { ...m, enabled: !m.enabled } : m
        ));
    };

    const activeMutation = mutations.find(m => m.enabled);

    return (
        <Container>
            <PageHeader>
                <HeaderContent>
                    <HeaderInfo>
                        <GameLogo>L4D2</GameLogo>
                        <HeaderText>
                            <PageTitle>Left 4 Dead 2 Manager</PageTitle>
                            <PageSubtitle>Manage campaigns, mutations, and server settings</PageSubtitle>
                        </HeaderText>
                    </HeaderInfo>
                    <HeaderActions>
                        <SecondaryButton>
                            <HiOutlineRefresh /> Restart
                        </SecondaryButton>
                        <PrimaryButton>
                            <HiOutlineSave /> Save Config
                        </PrimaryButton>
                    </HeaderActions>
                </HeaderContent>
            </PageHeader>

            <ContentGrid>
                <div css={tw`flex flex-col gap-6`}>
                    <Card>
                        <CardHeader>
                            <TabsContainer>
                                <Tab $active={activeTab === 'campaigns'} onClick={() => setActiveTab('campaigns')}>
                                    <HiOutlineMap css={tw`inline mr-1`} /> Campaigns
                                </Tab>
                                <Tab $active={activeTab === 'mutations'} onClick={() => setActiveTab('mutations')}>
                                    <HiOutlineLightningBolt css={tw`inline mr-1`} /> Mutations
                                </Tab>
                            </TabsContainer>
                        </CardHeader>
                        <CardBody>
                            {activeTab === 'campaigns' && (
                                <CampaignList>
                                    {campaigns.map(campaign => (
                                        <CampaignCard key={campaign.id} $enabled={campaign.enabled}>
                                            <CampaignHeader>
                                                <CampaignInfo>
                                                    <CampaignIcon>
                                                        <HiOutlineMap />
                                                    </CampaignIcon>
                                                    <CampaignDetails>
                                                        <CampaignName>
                                                            {campaign.name}
                                                            {campaign.isWorkshop && <WorkshopBadge>Workshop</WorkshopBadge>}
                                                        </CampaignName>
                                                        <CampaignMeta>
                                                            <span>{campaign.maps} maps</span>
                                                            <DifficultyBadge $difficulty={campaign.difficulty}>
                                                                {campaign.difficulty}
                                                            </DifficultyBadge>
                                                        </CampaignMeta>
                                                    </CampaignDetails>
                                                </CampaignInfo>
                                                <ToggleSwitch>
                                                    <input
                                                        type="checkbox"
                                                        checked={campaign.enabled}
                                                        onChange={() => toggleCampaign(campaign.id)}
                                                    />
                                                    <span />
                                                </ToggleSwitch>
                                            </CampaignHeader>
                                        </CampaignCard>
                                    ))}
                                </CampaignList>
                            )}

                            {activeTab === 'mutations' && (
                                <MutationList>
                                    {mutations.map(mutation => (
                                        <MutationItem key={mutation.id} $enabled={mutation.enabled}>
                                            <MutationInfo>
                                                <MutationIcon $enabled={mutation.enabled}>
                                                    <HiOutlineLightningBolt />
                                                </MutationIcon>
                                                <MutationDetails>
                                                    <MutationName>{mutation.name}</MutationName>
                                                    <MutationDesc>{mutation.description}</MutationDesc>
                                                </MutationDetails>
                                            </MutationInfo>
                                            <ToggleSwitch>
                                                <input
                                                    type="checkbox"
                                                    checked={mutation.enabled}
                                                    onChange={() => toggleMutation(mutation.id)}
                                                />
                                                <span />
                                            </ToggleSwitch>
                                        </MutationItem>
                                    ))}
                                </MutationList>
                            )}
                        </CardBody>
                    </Card>
                </div>

                <div css={tw`flex flex-col gap-4`}>
                    <CurrentGame>
                        <CurrentLabel>Currently Playing</CurrentLabel>
                        <CurrentValue>Dark Carnival</CurrentValue>
                        <CurrentMeta>
                            {activeMutation ? `${activeMutation.name} Mode` : 'Campaign Mode'} • 4/4 Players
                        </CurrentMeta>
                    </CurrentGame>

                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineCog /> Server Settings
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <ServerSettings>
                                <SettingItem>
                                    <SettingLabel>Difficulty</SettingLabel>
                                    <SettingValue defaultValue="normal">
                                        <option value="easy">Easy</option>
                                        <option value="normal">Normal</option>
                                        <option value="advanced">Advanced</option>
                                        <option value="expert">Expert</option>
                                    </SettingValue>
                                </SettingItem>
                                <SettingItem>
                                    <SettingLabel>Max Players</SettingLabel>
                                    <SettingValue defaultValue="4">
                                        <option value="4">4 Players</option>
                                        <option value="8">8 Players</option>
                                        <option value="16">16 Players</option>
                                    </SettingValue>
                                </SettingItem>
                                <SettingItem>
                                    <SettingLabel>Friendly Fire</SettingLabel>
                                    <SettingValue defaultValue="full">
                                        <option value="off">Off</option>
                                        <option value="half">Half Damage</option>
                                        <option value="full">Full Damage</option>
                                    </SettingValue>
                                </SettingItem>
                            </ServerSettings>
                        </CardBody>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlinePlay /> Quick Actions
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <QuickActions>
                                <QuickActionButton>
                                    <span><HiOutlineMap css={tw`inline mr-2`} /> Change Campaign</span>
                                    <HiOutlineChevronRight />
                                </QuickActionButton>
                                <QuickActionButton>
                                    <span><HiOutlineLightningBolt css={tw`inline mr-2`} /> Change Mutation</span>
                                    <HiOutlineChevronRight />
                                </QuickActionButton>
                                <QuickActionButton>
                                    <span><HiOutlineUsers css={tw`inline mr-2`} /> Kick All Bots</span>
                                    <HiOutlineChevronRight />
                                </QuickActionButton>
                                <QuickActionButton>
                                    <span><HiOutlineRefresh css={tw`inline mr-2`} /> Restart Round</span>
                                    <HiOutlineChevronRight />
                                </QuickActionButton>
                            </QuickActions>
                        </CardBody>
                    </Card>
                </div>
            </ContentGrid>
        </Container>
    );
};

export default L4D2ManagerContainer;
