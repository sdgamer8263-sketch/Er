import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineSpeakerphone, HiOutlinePlus, HiOutlinePencil, HiOutlineTrash, HiOutlineEye, HiOutlineClock, HiOutlineGlobe } from 'react-icons/hi';

interface Announcement {
    id: string;
    title: string;
    content: string;
    type: 'info' | 'warning' | 'maintenance' | 'promotion';
    status: 'draft' | 'active' | 'scheduled' | 'expired';
    publishedAt: string | null;
    expiresAt: string | null;
    views: number;
    targetAudience: 'all' | 'users' | 'admins';
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #ffcc00, #ff6b00, #ffcc00);
    }
`;

const HeaderContent = styled.div`
    ${tw`flex items-center justify-between`}
`;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const PrimaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: linear-gradient(135deg, #ffcc00 0%, #ff6b00 100%);
    color: #050a14;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(255, 204, 0, 0.3);
    }
`;

const StatsGrid = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(4, 1fr);

    @media (max-width: 1000px) {
        grid-template-columns: repeat(2, 1fr);
    }
`;

const StatCard = styled.div<{ $color: string }>`
    ${tw`p-4 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 3px;
        height: 100%;
        background: ${props => props.$color};
    }
`;

const StatLabel = styled.span`
    ${tw`text-xs uppercase tracking-wide block mb-1`}
    color: #5a7a9a;
`;

const StatValue = styled.span<{ $color: string }>`
    ${tw`text-2xl font-bold`}
    color: ${props => props.$color};
    font-family: 'Rajdhani', sans-serif;
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const AnnouncementList = styled.div`
    ${tw`flex flex-col`}
`;

const AnnouncementItem = styled.div<{ $type: string }>`
    ${tw`p-5 relative`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.5);
    border-left: 3px solid ${props => {
        switch(props.$type) {
            case 'info': return '#00d4ff';
            case 'warning': return '#ffcc00';
            case 'maintenance': return '#ff6b00';
            case 'promotion': return '#00ff88';
            default: return '#5a7a9a';
        }
    }};

    &:last-child {
        border-bottom: none;
    }

    &:hover {
        background: rgba(15, 31, 61, 0.5);
    }
`;

const AnnouncementHeader = styled.div`
    ${tw`flex items-start justify-between mb-2`}
`;

const AnnouncementInfo = styled.div``;

const AnnouncementTitle = styled.h4`
    ${tw`text-lg font-bold flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const TypeBadge = styled.span<{ $type: string }>`
    ${tw`px-2 py-0.5 rounded text-xs uppercase font-bold`}
    background: ${props => {
        switch(props.$type) {
            case 'info': return 'rgba(0, 212, 255, 0.15)';
            case 'warning': return 'rgba(255, 204, 0, 0.15)';
            case 'maintenance': return 'rgba(255, 107, 0, 0.15)';
            case 'promotion': return 'rgba(0, 255, 136, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$type) {
            case 'info': return '#00d4ff';
            case 'warning': return '#ffcc00';
            case 'maintenance': return '#ff6b00';
            case 'promotion': return '#00ff88';
            default: return '#5a7a9a';
        }
    }};
`;

const StatusBadge = styled.span<{ $status: string }>`
    ${tw`px-2 py-0.5 rounded text-xs uppercase`}
    background: ${props => {
        switch(props.$status) {
            case 'active': return 'rgba(0, 255, 136, 0.15)';
            case 'scheduled': return 'rgba(0, 212, 255, 0.15)';
            case 'draft': return 'rgba(90, 122, 154, 0.15)';
            case 'expired': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$status) {
            case 'active': return '#00ff88';
            case 'scheduled': return '#00d4ff';
            case 'draft': return '#5a7a9a';
            case 'expired': return '#ff3366';
            default: return '#5a7a9a';
        }
    }};
`;

const AnnouncementContent = styled.p`
    ${tw`text-sm mb-3`}
    color: #a0b4c8;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
`;

const AnnouncementMeta = styled.div`
    ${tw`flex items-center gap-4 text-xs`}
    color: #5a7a9a;
`;

const MetaItem = styled.span`
    ${tw`flex items-center gap-1`}
`;

const AnnouncementActions = styled.div`
    ${tw`flex gap-2`}
`;

const IconButton = styled.button<{ $variant?: 'primary' | 'danger' }>`
    ${tw`w-8 h-8 rounded-lg flex items-center justify-center`}
    background: ${props => props.$variant === 'danger' ? 'rgba(255, 51, 102, 0.15)' : 'rgba(26, 48, 80, 0.5)'};
    border: 1px solid ${props => props.$variant === 'danger' ? 'rgba(255, 51, 102, 0.5)' : 'rgba(26, 48, 80, 0.8)'};
    color: ${props => props.$variant === 'danger' ? '#ff3366' : '#a0b4c8'};
    cursor: pointer;
    transition: all 0.3s ease;

    &:hover {
        transform: scale(1.1);
    }
`;

// Mock data
const mockAnnouncements: Announcement[] = [
    { id: '1', title: 'Scheduled Maintenance - January 25th', content: 'We will be performing scheduled maintenance on our EU servers. Expect up to 2 hours of downtime.', type: 'maintenance', status: 'active', publishedAt: '2024-01-19 10:00', expiresAt: '2024-01-25 23:59', views: 1542, targetAudience: 'all' },
    { id: '2', title: '50% Off All Game Servers!', content: 'New year special! Get 50% off on all new server orders. Use code NEWYEAR2024 at checkout.', type: 'promotion', status: 'active', publishedAt: '2024-01-01 00:00', expiresAt: '2024-01-31 23:59', views: 3821, targetAudience: 'users' },
    { id: '3', title: 'New Feature: Advanced Scheduler', content: 'We have released the new Advanced Scheduler addon. Schedule commands, restarts, and more!', type: 'info', status: 'active', publishedAt: '2024-01-15 12:00', expiresAt: null, views: 892, targetAudience: 'all' },
    { id: '4', title: 'System Performance Warning', content: 'We are experiencing higher than normal load on US-02 node. Some users may experience slower performance.', type: 'warning', status: 'expired', publishedAt: '2024-01-18 08:00', expiresAt: '2024-01-18 18:00', views: 456, targetAudience: 'all' },
    { id: '5', title: 'Upcoming: FiveM Support', content: 'Draft for upcoming FiveM server support announcement.', type: 'info', status: 'draft', publishedAt: null, expiresAt: null, views: 0, targetAudience: 'all' },
];

const AnnouncementsContainer: React.FC = () => {
    const [announcements] = useState<Announcement[]>(mockAnnouncements);

    const activeCount = announcements.filter(a => a.status === 'active').length;
    const scheduledCount = announcements.filter(a => a.status === 'scheduled').length;
    const totalViews = announcements.reduce((acc, a) => acc + a.views, 0);

    return (
        <Container>
            <PageHeader>
                <HeaderContent>
                    <div>
                        <PageTitle>Announcements</PageTitle>
                        <PageSubtitle>Create and manage system-wide announcements</PageSubtitle>
                    </div>
                    <PrimaryButton>
                        <HiOutlinePlus /> New Announcement
                    </PrimaryButton>
                </HeaderContent>
            </PageHeader>

            <StatsGrid>
                <StatCard $color="#00ff88">
                    <StatLabel>Active</StatLabel>
                    <StatValue $color="#00ff88">{activeCount}</StatValue>
                </StatCard>
                <StatCard $color="#00d4ff">
                    <StatLabel>Scheduled</StatLabel>
                    <StatValue $color="#00d4ff">{scheduledCount}</StatValue>
                </StatCard>
                <StatCard $color="#a855f7">
                    <StatLabel>Total Views</StatLabel>
                    <StatValue $color="#a855f7">{totalViews.toLocaleString()}</StatValue>
                </StatCard>
                <StatCard $color="#5a7a9a">
                    <StatLabel>Drafts</StatLabel>
                    <StatValue $color="#5a7a9a">{announcements.filter(a => a.status === 'draft').length}</StatValue>
                </StatCard>
            </StatsGrid>

            <Card>
                <CardHeader>
                    <CardTitle>
                        <HiOutlineSpeakerphone /> All Announcements
                    </CardTitle>
                </CardHeader>
                <AnnouncementList>
                    {announcements.map(announcement => (
                        <AnnouncementItem key={announcement.id} $type={announcement.type}>
                            <AnnouncementHeader>
                                <AnnouncementInfo>
                                    <AnnouncementTitle>
                                        {announcement.title}
                                        <TypeBadge $type={announcement.type}>{announcement.type}</TypeBadge>
                                        <StatusBadge $status={announcement.status}>{announcement.status}</StatusBadge>
                                    </AnnouncementTitle>
                                </AnnouncementInfo>
                                <AnnouncementActions>
                                    <IconButton title="Edit">
                                        <HiOutlinePencil />
                                    </IconButton>
                                    <IconButton $variant="danger" title="Delete">
                                        <HiOutlineTrash />
                                    </IconButton>
                                </AnnouncementActions>
                            </AnnouncementHeader>
                            <AnnouncementContent>{announcement.content}</AnnouncementContent>
                            <AnnouncementMeta>
                                <MetaItem>
                                    <HiOutlineEye /> {announcement.views.toLocaleString()} views
                                </MetaItem>
                                <MetaItem>
                                    <HiOutlineClock /> {announcement.publishedAt || 'Not published'}
                                </MetaItem>
                                <MetaItem>
                                    <HiOutlineGlobe /> {announcement.targetAudience === 'all' ? 'Everyone' : announcement.targetAudience}
                                </MetaItem>
                            </AnnouncementMeta>
                        </AnnouncementItem>
                    ))}
                </AnnouncementList>
            </Card>
        </Container>
    );
};

export default AnnouncementsContainer;
