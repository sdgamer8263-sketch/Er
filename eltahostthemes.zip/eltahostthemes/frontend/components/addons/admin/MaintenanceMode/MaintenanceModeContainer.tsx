import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineCog, HiOutlineExclamation, HiOutlineClock, HiOutlineCheck, HiOutlineServer, HiOutlineGlobe } from 'react-icons/hi';

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #ff6b00, #ffcc00, #ff6b00);
    }
`;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const ContentGrid = styled.div`
    ${tw`grid gap-6`}
    grid-template-columns: 1fr 400px;

    @media (max-width: 1200px) {
        grid-template-columns: 1fr;
    }
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const CardBody = styled.div`
    ${tw`p-5`}
`;

const StatusCard = styled.div<{ $active: boolean }>`
    ${tw`p-6 rounded-xl text-center mb-6`}
    background: ${props => props.$active
        ? 'linear-gradient(145deg, rgba(255, 107, 0, 0.15) 0%, rgba(255, 204, 0, 0.1) 100%)'
        : 'linear-gradient(145deg, rgba(0, 255, 136, 0.15) 0%, rgba(0, 212, 255, 0.1) 100%)'};
    border: 2px solid ${props => props.$active ? '#ff6b00' : '#00ff88'};
`;

const StatusIcon = styled.div<{ $active: boolean }>`
    ${tw`w-20 h-20 rounded-full flex items-center justify-center text-4xl mx-auto mb-4`}
    background: ${props => props.$active ? 'rgba(255, 107, 0, 0.2)' : 'rgba(0, 255, 136, 0.2)'};
    color: ${props => props.$active ? '#ff6b00' : '#00ff88'};
`;

const StatusText = styled.h2`
    ${tw`text-2xl font-bold mb-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const StatusDesc = styled.p`
    ${tw`text-sm`}
    color: #a0b4c8;
`;

const ToggleButton = styled.button<{ $active: boolean }>`
    ${tw`w-full py-4 rounded-xl font-bold uppercase tracking-wide text-lg`}
    background: ${props => props.$active
        ? 'linear-gradient(135deg, #00ff88 0%, #00d4ff 100%)'
        : 'linear-gradient(135deg, #ff6b00 0%, #ffcc00 100%)'};
    color: #050a14;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px ${props => props.$active ? 'rgba(0, 255, 136, 0.3)' : 'rgba(255, 107, 0, 0.3)'};
    }
`;

const FormGroup = styled.div`
    ${tw`mb-4`}
`;

const FormLabel = styled.label`
    ${tw`block text-sm font-medium mb-2`}
    color: #a0b4c8;
`;

const FormInput = styled.input`
    ${tw`w-full px-4 py-3 rounded-lg text-sm`}
    background: rgba(5, 10, 20, 0.8);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #ffffff;

    &:focus {
        outline: none;
        border-color: #ff6b00;
    }

    &::placeholder {
        color: #5a7a9a;
    }
`;

const FormTextarea = styled.textarea`
    ${tw`w-full px-4 py-3 rounded-lg text-sm resize-none`}
    background: rgba(5, 10, 20, 0.8);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #ffffff;
    min-height: 100px;

    &:focus {
        outline: none;
        border-color: #ff6b00;
    }

    &::placeholder {
        color: #5a7a9a;
    }
`;

const CheckboxGroup = styled.div`
    ${tw`flex flex-col gap-2`}
`;

const Checkbox = styled.label`
    ${tw`flex items-center gap-3 p-3 rounded-lg cursor-pointer`}
    background: rgba(15, 31, 61, 0.5);

    input {
        ${tw`w-5 h-5`}
        accent-color: #ff6b00;
    }

    span {
        ${tw`text-sm`}
        color: #a0b4c8;
    }
`;

const InfoBox = styled.div`
    ${tw`p-4 rounded-lg flex items-start gap-3`}
    background: rgba(255, 107, 0, 0.1);
    border: 1px solid rgba(255, 107, 0, 0.3);
`;

const InfoIcon = styled.div`
    ${tw`w-6 h-6 rounded flex items-center justify-center flex-shrink-0`}
    background: rgba(255, 107, 0, 0.2);
    color: #ff6b00;
`;

const InfoText = styled.p`
    ${tw`text-sm`}
    color: #a0b4c8;
`;

const MaintenanceModeContainer: React.FC = () => {
    const [isActive, setIsActive] = useState(false);
    const [message, setMessage] = useState('We are currently performing scheduled maintenance. Please check back soon.');
    const [estimatedTime, setEstimatedTime] = useState('2 hours');

    return (
        <Container>
            <PageHeader>
                <PageTitle>Maintenance Mode</PageTitle>
                <PageSubtitle>Control panel and server availability during maintenance</PageSubtitle>
            </PageHeader>

            <ContentGrid>
                <Card>
                    <CardHeader>
                        <CardTitle>
                            <HiOutlineCog /> Maintenance Settings
                        </CardTitle>
                    </CardHeader>
                    <CardBody>
                        <StatusCard $active={isActive}>
                            <StatusIcon $active={isActive}>
                                {isActive ? <HiOutlineExclamation /> : <HiOutlineCheck />}
                            </StatusIcon>
                            <StatusText>
                                {isActive ? 'Maintenance Mode Active' : 'System Operational'}
                            </StatusText>
                            <StatusDesc>
                                {isActive
                                    ? 'Users cannot access the panel. Admin access remains available.'
                                    : 'All systems are running normally.'}
                            </StatusDesc>
                        </StatusCard>

                        <ToggleButton $active={isActive} onClick={() => setIsActive(!isActive)}>
                            {isActive ? 'Disable Maintenance Mode' : 'Enable Maintenance Mode'}
                        </ToggleButton>

                        <div css={tw`mt-6`}>
                            <FormGroup>
                                <FormLabel>Maintenance Message</FormLabel>
                                <FormTextarea
                                    value={message}
                                    onChange={(e) => setMessage(e.target.value)}
                                    placeholder="Enter message to display to users..."
                                />
                            </FormGroup>

                            <FormGroup>
                                <FormLabel>Estimated Duration</FormLabel>
                                <FormInput
                                    type="text"
                                    value={estimatedTime}
                                    onChange={(e) => setEstimatedTime(e.target.value)}
                                    placeholder="e.g., 2 hours"
                                />
                            </FormGroup>

                            <FormGroup>
                                <FormLabel>Options</FormLabel>
                                <CheckboxGroup>
                                    <Checkbox>
                                        <input type="checkbox" defaultChecked />
                                        <span>Allow admin access during maintenance</span>
                                    </Checkbox>
                                    <Checkbox>
                                        <input type="checkbox" defaultChecked />
                                        <span>Stop all running servers</span>
                                    </Checkbox>
                                    <Checkbox>
                                        <input type="checkbox" />
                                        <span>Send email notification to users</span>
                                    </Checkbox>
                                    <Checkbox>
                                        <input type="checkbox" defaultChecked />
                                        <span>Display countdown timer</span>
                                    </Checkbox>
                                </CheckboxGroup>
                            </FormGroup>
                        </div>
                    </CardBody>
                </Card>

                <div css={tw`flex flex-col gap-4`}>
                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineClock /> Schedule
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <FormGroup>
                                <FormLabel>Start Time (Optional)</FormLabel>
                                <FormInput type="datetime-local" />
                            </FormGroup>
                            <FormGroup>
                                <FormLabel>End Time (Optional)</FormLabel>
                                <FormInput type="datetime-local" />
                            </FormGroup>
                            <InfoBox>
                                <InfoIcon><HiOutlineExclamation /></InfoIcon>
                                <InfoText>
                                    Leave times empty to manually control maintenance mode.
                                </InfoText>
                            </InfoBox>
                        </CardBody>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineServer /> System Status
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <div css={tw`flex flex-col gap-3`}>
                                <div css={tw`flex justify-between items-center`}>
                                    <span css={tw`text-sm`} style={{ color: '#a0b4c8' }}>Panel</span>
                                    <span css={tw`text-sm font-bold`} style={{ color: isActive ? '#ff6b00' : '#00ff88' }}>
                                        {isActive ? 'Maintenance' : 'Online'}
                                    </span>
                                </div>
                                <div css={tw`flex justify-between items-center`}>
                                    <span css={tw`text-sm`} style={{ color: '#a0b4c8' }}>API</span>
                                    <span css={tw`text-sm font-bold`} style={{ color: '#00ff88' }}>Online</span>
                                </div>
                                <div css={tw`flex justify-between items-center`}>
                                    <span css={tw`text-sm`} style={{ color: '#a0b4c8' }}>Servers</span>
                                    <span css={tw`text-sm font-bold`} style={{ color: '#00ff88' }}>42 Running</span>
                                </div>
                            </div>
                        </CardBody>
                    </Card>
                </div>
            </ContentGrid>
        </Container>
    );
};

export default MaintenanceModeContainer;
