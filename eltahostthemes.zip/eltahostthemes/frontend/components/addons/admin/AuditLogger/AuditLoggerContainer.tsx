import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineDocumentText, HiOutlineSearch, HiOutlineFilter, HiOutlineDownload, HiOutlineUser, HiOutlineServer, HiOutlineCog, HiOutlineShieldCheck, HiOutlineExclamation } from 'react-icons/hi';

interface AuditLog {
    id: string;
    timestamp: string;
    user: string;
    action: string;
    resource: string;
    resourceId: string;
    ipAddress: string;
    severity: 'info' | 'warning' | 'critical';
    details: string;
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #a855f7, #00d4ff, #a855f7);
    }
`;

const HeaderContent = styled.div`
    ${tw`flex items-center justify-between`}
`;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const HeaderActions = styled.div`
    ${tw`flex gap-3`}
`;

const SecondaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: rgba(26, 48, 80, 0.5);
    color: #a0b4c8;
    border: 1px solid rgba(26, 48, 80, 0.8);
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #00d4ff;
        color: #00d4ff;
    }
`;

const FiltersBar = styled.div`
    ${tw`flex items-center gap-4 p-4 rounded-xl`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const SearchBar = styled.div`
    ${tw`flex-1 relative`}
`;

const SearchInput = styled.input`
    ${tw`w-full pl-10 pr-4 py-2.5 rounded-lg text-sm`}
    background: rgba(5, 10, 20, 0.8);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #ffffff;

    &:focus {
        outline: none;
        border-color: #a855f7;
    }

    &::placeholder {
        color: #5a7a9a;
    }
`;

const SearchIcon = styled.div`
    ${tw`absolute left-3 top-1/2 transform -translate-y-1/2`}
    color: #5a7a9a;
`;

const FilterSelect = styled.select`
    ${tw`px-4 py-2.5 rounded-lg text-sm`}
    background: rgba(5, 10, 20, 0.8);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #ffffff;

    &:focus {
        outline: none;
        border-color: #a855f7;
    }

    option {
        background: #0a1628;
    }
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const LogTable = styled.div`
    ${tw`overflow-x-auto`}
`;

const Table = styled.table`
    ${tw`w-full`}
    border-collapse: collapse;
`;

const Th = styled.th`
    ${tw`px-4 py-3 text-left text-xs uppercase tracking-wide font-semibold`}
    background: rgba(15, 31, 61, 0.5);
    color: #5a7a9a;
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const Td = styled.td`
    ${tw`px-4 py-3 text-sm`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.5);
    color: #a0b4c8;
`;

const Tr = styled.tr`
    transition: background 0.2s ease;

    &:hover {
        background: rgba(15, 31, 61, 0.5);
    }
`;

const SeverityBadge = styled.span<{ $severity: string }>`
    ${tw`px-2 py-1 rounded text-xs uppercase font-bold flex items-center gap-1 w-fit`}
    background: ${props => {
        switch(props.$severity) {
            case 'info': return 'rgba(0, 212, 255, 0.15)';
            case 'warning': return 'rgba(255, 204, 0, 0.15)';
            case 'critical': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$severity) {
            case 'info': return '#00d4ff';
            case 'warning': return '#ffcc00';
            case 'critical': return '#ff3366';
            default: return '#5a7a9a';
        }
    }};
`;

const ActionIcon = styled.span<{ $type: string }>`
    ${tw`w-8 h-8 rounded-lg flex items-center justify-center`}
    background: ${props => {
        if (props.$type.includes('user')) return 'rgba(168, 85, 247, 0.15)';
        if (props.$type.includes('server')) return 'rgba(0, 212, 255, 0.15)';
        if (props.$type.includes('security')) return 'rgba(255, 51, 102, 0.15)';
        return 'rgba(0, 255, 136, 0.15)';
    }};
    color: ${props => {
        if (props.$type.includes('user')) return '#a855f7';
        if (props.$type.includes('server')) return '#00d4ff';
        if (props.$type.includes('security')) return '#ff3366';
        return '#00ff88';
    }};
`;

const Pagination = styled.div`
    ${tw`flex items-center justify-between px-5 py-4`}
    border-top: 1px solid rgba(26, 48, 80, 0.8);
`;

const PageInfo = styled.span`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const PageButtons = styled.div`
    ${tw`flex gap-2`}
`;

const PageButton = styled.button<{ $active?: boolean }>`
    ${tw`w-8 h-8 rounded-lg flex items-center justify-center text-sm`}
    background: ${props => props.$active ? 'linear-gradient(135deg, #a855f7 0%, #00d4ff 100%)' : 'rgba(26, 48, 80, 0.5)'};
    color: ${props => props.$active ? '#ffffff' : '#a0b4c8'};
    border: none;
    cursor: pointer;
    transition: all 0.3s ease;

    &:hover:not(:disabled) {
        background: ${props => props.$active ? undefined : 'rgba(26, 48, 80, 0.8)'};
    }

    &:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }
`;

// Mock data
const mockLogs: AuditLog[] = [
    { id: '1', timestamp: '2024-01-19 15:45:23', user: 'admin@example.com', action: 'user.login', resource: 'User', resourceId: '1', ipAddress: '192.168.1.100', severity: 'info', details: 'Successful login' },
    { id: '2', timestamp: '2024-01-19 15:42:10', user: 'admin@example.com', action: 'server.create', resource: 'Server', resourceId: '42', ipAddress: '192.168.1.100', severity: 'info', details: 'Created Minecraft server' },
    { id: '3', timestamp: '2024-01-19 15:38:55', user: 'john@example.com', action: 'security.failed_login', resource: 'User', resourceId: '5', ipAddress: '10.0.0.55', severity: 'warning', details: 'Failed login attempt (3rd attempt)' },
    { id: '4', timestamp: '2024-01-19 15:35:00', user: 'system', action: 'server.stop', resource: 'Server', resourceId: '38', ipAddress: 'internal', severity: 'info', details: 'Server stopped due to inactivity' },
    { id: '5', timestamp: '2024-01-19 15:30:12', user: 'hacker@unknown.com', action: 'security.blocked', resource: 'System', resourceId: '-', ipAddress: '45.33.32.156', severity: 'critical', details: 'IP blocked after 10 failed attempts' },
    { id: '6', timestamp: '2024-01-19 15:25:00', user: 'admin@example.com', action: 'settings.update', resource: 'Settings', resourceId: 'smtp', ipAddress: '192.168.1.100', severity: 'warning', details: 'SMTP settings modified' },
    { id: '7', timestamp: '2024-01-19 15:20:45', user: 'jane@example.com', action: 'user.password_change', resource: 'User', resourceId: '3', ipAddress: '192.168.1.105', severity: 'info', details: 'Password changed successfully' },
];

const AuditLoggerContainer: React.FC = () => {
    const [logs] = useState<AuditLog[]>(mockLogs);
    const [searchQuery, setSearchQuery] = useState('');
    const [severityFilter, setSeverityFilter] = useState('all');

    const filteredLogs = logs.filter(log => {
        const matchesSearch = log.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
                              log.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
                              log.details.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesSeverity = severityFilter === 'all' || log.severity === severityFilter;
        return matchesSearch && matchesSeverity;
    });

    const getActionIcon = (action: string) => {
        if (action.includes('user') || action.includes('login')) return <HiOutlineUser />;
        if (action.includes('server')) return <HiOutlineServer />;
        if (action.includes('security')) return <HiOutlineShieldCheck />;
        if (action.includes('settings')) return <HiOutlineCog />;
        return <HiOutlineDocumentText />;
    };

    return (
        <Container>
            <PageHeader>
                <HeaderContent>
                    <div>
                        <PageTitle>Audit Logger</PageTitle>
                        <PageSubtitle>Track all system activities and security events</PageSubtitle>
                    </div>
                    <HeaderActions>
                        <SecondaryButton>
                            <HiOutlineDownload /> Export Logs
                        </SecondaryButton>
                    </HeaderActions>
                </HeaderContent>
            </PageHeader>

            <FiltersBar>
                <SearchBar>
                    <SearchIcon><HiOutlineSearch /></SearchIcon>
                    <SearchInput
                        type="text"
                        placeholder="Search logs by action, user, or details..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </SearchBar>
                <FilterSelect value={severityFilter} onChange={(e) => setSeverityFilter(e.target.value)}>
                    <option value="all">All Severities</option>
                    <option value="info">Info</option>
                    <option value="warning">Warning</option>
                    <option value="critical">Critical</option>
                </FilterSelect>
                <FilterSelect defaultValue="all">
                    <option value="all">All Resources</option>
                    <option value="user">Users</option>
                    <option value="server">Servers</option>
                    <option value="security">Security</option>
                    <option value="settings">Settings</option>
                </FilterSelect>
                <FilterSelect defaultValue="today">
                    <option value="today">Today</option>
                    <option value="week">Last 7 Days</option>
                    <option value="month">Last 30 Days</option>
                    <option value="custom">Custom Range</option>
                </FilterSelect>
            </FiltersBar>

            <Card>
                <CardHeader>
                    <CardTitle>
                        <HiOutlineDocumentText /> Activity Logs ({filteredLogs.length})
                    </CardTitle>
                </CardHeader>
                <LogTable>
                    <Table>
                        <thead>
                            <tr>
                                <Th>Time</Th>
                                <Th>Severity</Th>
                                <Th>Action</Th>
                                <Th>User</Th>
                                <Th>Resource</Th>
                                <Th>IP Address</Th>
                                <Th>Details</Th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredLogs.map(log => (
                                <Tr key={log.id}>
                                    <Td style={{ color: '#ffffff', fontFamily: 'JetBrains Mono', fontSize: '12px' }}>
                                        {log.timestamp}
                                    </Td>
                                    <Td>
                                        <SeverityBadge $severity={log.severity}>
                                            {log.severity === 'critical' && <HiOutlineExclamation />}
                                            {log.severity}
                                        </SeverityBadge>
                                    </Td>
                                    <Td>
                                        <div css={tw`flex items-center gap-2`}>
                                            <ActionIcon $type={log.action}>
                                                {getActionIcon(log.action)}
                                            </ActionIcon>
                                            <span style={{ color: '#ffffff' }}>{log.action}</span>
                                        </div>
                                    </Td>
                                    <Td>{log.user}</Td>
                                    <Td>{log.resource} #{log.resourceId}</Td>
                                    <Td style={{ fontFamily: 'JetBrains Mono', fontSize: '12px' }}>{log.ipAddress}</Td>
                                    <Td>{log.details}</Td>
                                </Tr>
                            ))}
                        </tbody>
                    </Table>
                </LogTable>
                <Pagination>
                    <PageInfo>Showing 1-{filteredLogs.length} of {filteredLogs.length} logs</PageInfo>
                    <PageButtons>
                        <PageButton disabled>←</PageButton>
                        <PageButton $active>1</PageButton>
                        <PageButton>2</PageButton>
                        <PageButton>3</PageButton>
                        <PageButton>→</PageButton>
                    </PageButtons>
                </Pagination>
            </Card>
        </Container>
    );
};

export default AuditLoggerContainer;
