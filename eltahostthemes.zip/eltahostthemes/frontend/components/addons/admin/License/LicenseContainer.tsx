import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineKey, HiOutlineCheck, HiOutlineExclamation, HiOutlineRefresh, HiOutlineClock, HiOutlineShieldCheck } from 'react-icons/hi';

interface LicenseStatus {
    status: 'active' | 'expired' | 'grace_period' | 'invalid' | 'unlicensed';
    message: string;
    type?: string;
    expiresAt?: string;
    graceUntil?: string;
    features?: string[];
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #a855f7, #00d4ff, #a855f7);
    }
`;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const ContentGrid = styled.div`
    ${tw`grid gap-6`}
    grid-template-columns: 1fr 400px;

    @media (max-width: 1200px) {
        grid-template-columns: 1fr;
    }
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const CardBody = styled.div`
    ${tw`p-5`}
`;

const StatusCard = styled.div<{ $status: string }>`
    ${tw`p-6 rounded-xl text-center mb-6`}
    background: ${props => {
        switch(props.$status) {
            case 'active': return 'linear-gradient(145deg, rgba(0, 255, 136, 0.15) 0%, rgba(0, 212, 255, 0.1) 100%)';
            case 'grace_period': return 'linear-gradient(145deg, rgba(255, 204, 0, 0.15) 0%, rgba(255, 107, 0, 0.1) 100%)';
            default: return 'linear-gradient(145deg, rgba(255, 51, 102, 0.15) 0%, rgba(255, 107, 0, 0.1) 100%)';
        }
    }};
    border: 2px solid ${props => {
        switch(props.$status) {
            case 'active': return '#00ff88';
            case 'grace_period': return '#ffcc00';
            default: return '#ff3366';
        }
    }};
`;

const StatusIcon = styled.div<{ $status: string }>`
    ${tw`w-20 h-20 rounded-full flex items-center justify-center text-4xl mx-auto mb-4`}
    background: ${props => {
        switch(props.$status) {
            case 'active': return 'rgba(0, 255, 136, 0.2)';
            case 'grace_period': return 'rgba(255, 204, 0, 0.2)';
            default: return 'rgba(255, 51, 102, 0.2)';
        }
    }};
    color: ${props => {
        switch(props.$status) {
            case 'active': return '#00ff88';
            case 'grace_period': return '#ffcc00';
            default: return '#ff3366';
        }
    }};
`;

const StatusText = styled.h2`
    ${tw`text-2xl font-bold mb-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const StatusDesc = styled.p`
    ${tw`text-sm`}
    color: #a0b4c8;
`;

const FormGroup = styled.div`
    ${tw`mb-4`}
`;

const FormLabel = styled.label`
    ${tw`block text-sm font-medium mb-2`}
    color: #a0b4c8;
`;

const FormInput = styled.input`
    ${tw`w-full px-4 py-3 rounded-lg text-sm font-mono`}
    background: rgba(5, 10, 20, 0.8);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #ffffff;

    &:focus {
        outline: none;
        border-color: #a855f7;
        box-shadow: 0 0 20px rgba(168, 85, 247, 0.2);
    }

    &::placeholder {
        color: #5a7a9a;
    }
`;

const PrimaryButton = styled.button`
    ${tw`w-full py-3 rounded-lg font-bold uppercase tracking-wide flex items-center justify-center gap-2`}
    background: linear-gradient(135deg, #a855f7 0%, #00d4ff 100%);
    color: #ffffff;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(168, 85, 247, 0.3);
    }

    &:disabled {
        opacity: 0.5;
        cursor: not-allowed;
        transform: none;
    }
`;

const SecondaryButton = styled.button`
    ${tw`w-full py-3 rounded-lg font-bold uppercase tracking-wide flex items-center justify-center gap-2`}
    background: rgba(26, 48, 80, 0.5);
    color: #a0b4c8;
    border: 1px solid rgba(26, 48, 80, 0.8);
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #00d4ff;
        color: #00d4ff;
    }
`;

const InfoItem = styled.div`
    ${tw`flex items-center justify-between py-3`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.5);

    &:last-child {
        border-bottom: none;
    }
`;

const InfoLabel = styled.span`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const InfoValue = styled.span`
    ${tw`text-sm font-semibold`}
    color: #ffffff;
`;

const FeatureList = styled.div`
    ${tw`flex flex-col gap-2 mt-4`}
`;

const FeatureItem = styled.div<{ $enabled: boolean }>`
    ${tw`flex items-center gap-2 p-2 rounded-lg`}
    background: ${props => props.$enabled ? 'rgba(0, 255, 136, 0.1)' : 'rgba(90, 122, 154, 0.1)'};
    border: 1px solid ${props => props.$enabled ? 'rgba(0, 255, 136, 0.3)' : 'rgba(90, 122, 154, 0.3)'};
`;

const FeatureIcon = styled.span<{ $enabled: boolean }>`
    ${tw`w-5 h-5 rounded-full flex items-center justify-center text-xs`}
    background: ${props => props.$enabled ? 'rgba(0, 255, 136, 0.2)' : 'rgba(90, 122, 154, 0.2)'};
    color: ${props => props.$enabled ? '#00ff88' : '#5a7a9a'};
`;

const FeatureName = styled.span<{ $enabled: boolean }>`
    ${tw`text-sm`}
    color: ${props => props.$enabled ? '#ffffff' : '#5a7a9a'};
`;

const WarningBox = styled.div`
    ${tw`p-4 rounded-lg flex items-start gap-3 mt-4`}
    background: rgba(255, 204, 0, 0.1);
    border: 1px solid rgba(255, 204, 0, 0.3);
`;

const WarningIcon = styled.div`
    ${tw`w-6 h-6 rounded flex items-center justify-center flex-shrink-0`}
    background: rgba(255, 204, 0, 0.2);
    color: #ffcc00;
`;

const WarningText = styled.p`
    ${tw`text-sm`}
    color: #a0b4c8;
`;

const LicenseContainer: React.FC = () => {
    const [licenseKey, setLicenseKey] = useState('');
    const [loading, setLoading] = useState(false);

    // Mock license status
    const [licenseStatus] = useState<LicenseStatus>({
        status: 'active',
        message: 'License is active and valid',
        type: 'Enterprise',
        expiresAt: '2025-01-19',
        features: ['all_addons', 'billing_portal', 'custom_branding', 'priority_support', 'api_access'],
    });

    const allFeatures = [
        { id: 'all_addons', name: 'All Addons' },
        { id: 'billing_portal', name: 'Billing Portal' },
        { id: 'custom_branding', name: 'Custom Branding' },
        { id: 'priority_support', name: 'Priority Support' },
        { id: 'api_access', name: 'API Access' },
        { id: 'white_label', name: 'White Label' },
    ];

    const handleActivate = async () => {
        if (!licenseKey.trim()) return;
        setLoading(true);
        // API call would go here
        await new Promise(resolve => setTimeout(resolve, 2000));
        setLoading(false);
    };

    return (
        <Container>
            <PageHeader>
                <PageTitle>License Management</PageTitle>
                <PageSubtitle>Manage your Neon Gaming Panel license</PageSubtitle>
            </PageHeader>

            <ContentGrid>
                <Card>
                    <CardHeader>
                        <CardTitle>
                            <HiOutlineKey /> License Status
                        </CardTitle>
                    </CardHeader>
                    <CardBody>
                        <StatusCard $status={licenseStatus.status}>
                            <StatusIcon $status={licenseStatus.status}>
                                {licenseStatus.status === 'active' && <HiOutlineCheck />}
                                {licenseStatus.status === 'grace_period' && <HiOutlineClock />}
                                {['expired', 'invalid', 'unlicensed'].includes(licenseStatus.status) && <HiOutlineExclamation />}
                            </StatusIcon>
                            <StatusText>
                                {licenseStatus.status === 'active' && 'License Active'}
                                {licenseStatus.status === 'grace_period' && 'Grace Period'}
                                {licenseStatus.status === 'expired' && 'License Expired'}
                                {licenseStatus.status === 'invalid' && 'Invalid License'}
                                {licenseStatus.status === 'unlicensed' && 'No License'}
                            </StatusText>
                            <StatusDesc>{licenseStatus.message}</StatusDesc>
                        </StatusCard>

                        <InfoItem>
                            <InfoLabel>License Type</InfoLabel>
                            <InfoValue style={{ color: '#a855f7' }}>{licenseStatus.type || 'N/A'}</InfoValue>
                        </InfoItem>
                        <InfoItem>
                            <InfoLabel>Expires</InfoLabel>
                            <InfoValue>{licenseStatus.expiresAt || 'Never'}</InfoValue>
                        </InfoItem>
                        <InfoItem>
                            <InfoLabel>Domain</InfoLabel>
                            <InfoValue>{window.location.hostname}</InfoValue>
                        </InfoItem>

                        <FeatureList>
                            {allFeatures.map(feature => {
                                const enabled = licenseStatus.features?.includes(feature.id) || false;
                                return (
                                    <FeatureItem key={feature.id} $enabled={enabled}>
                                        <FeatureIcon $enabled={enabled}>
                                            {enabled ? <HiOutlineCheck /> : '×'}
                                        </FeatureIcon>
                                        <FeatureName $enabled={enabled}>{feature.name}</FeatureName>
                                    </FeatureItem>
                                );
                            })}
                        </FeatureList>
                    </CardBody>
                </Card>

                <div css={tw`flex flex-col gap-4`}>
                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineShieldCheck /> Activate License
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <FormGroup>
                                <FormLabel>License Key</FormLabel>
                                <FormInput
                                    type="text"
                                    placeholder="XXXX-XXXX-XXXX-XXXX"
                                    value={licenseKey}
                                    onChange={(e) => setLicenseKey(e.target.value)}
                                />
                            </FormGroup>

                            <PrimaryButton onClick={handleActivate} disabled={loading || !licenseKey.trim()}>
                                {loading ? 'Validating...' : 'Activate License'}
                            </PrimaryButton>

                            <div css={tw`mt-4`}>
                                <SecondaryButton>
                                    <HiOutlineRefresh /> Refresh Status
                                </SecondaryButton>
                            </div>

                            <WarningBox>
                                <WarningIcon><HiOutlineExclamation /></WarningIcon>
                                <WarningText>
                                    Your license is tied to this domain. Contact support if you need to transfer your license to a different domain.
                                </WarningText>
                            </WarningBox>
                        </CardBody>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineClock /> Grace Period Info
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <p css={tw`text-sm mb-4`} style={{ color: '#a0b4c8' }}>
                                If the license server becomes unreachable, your panel will continue to work for up to 15 days.
                                During this grace period, all features remain active.
                            </p>
                            <InfoItem>
                                <InfoLabel>Grace Period</InfoLabel>
                                <InfoValue>15 days</InfoValue>
                            </InfoItem>
                            <InfoItem>
                                <InfoLabel>Soft Disable</InfoLabel>
                                <InfoValue style={{ color: '#00ff88' }}>Yes</InfoValue>
                            </InfoItem>
                        </CardBody>
                    </Card>
                </div>
            </ContentGrid>
        </Container>
    );
};

export default LicenseContainer;
