import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineShieldCheck, HiOutlineBan, HiOutlineExclamation, HiOutlineCheck, HiOutlineEye, HiOutlineTrash, HiOutlinePlus } from 'react-icons/hi';

interface AbuseReport {
    id: string;
    type: 'ddos' | 'spam' | 'exploit' | 'tos_violation' | 'other';
    serverId: string;
    serverName: string;
    userId: string;
    userName: string;
    status: 'pending' | 'investigating' | 'resolved' | 'dismissed';
    severity: 'low' | 'medium' | 'high' | 'critical';
    reportedAt: string;
    description: string;
}

interface BlockedIP {
    ip: string;
    reason: string;
    blockedAt: string;
    expiresAt: string | null;
    blockedBy: string;
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #ff3366, #ffcc00, #ff3366);
    }
`;

const HeaderContent = styled.div`
    ${tw`flex items-center justify-between`}
`;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const HeaderActions = styled.div`
    ${tw`flex gap-3`}
`;

const PrimaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: linear-gradient(135deg, #ff3366 0%, #ff6b00 100%);
    color: #ffffff;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(255, 51, 102, 0.3);
    }
`;

const StatsGrid = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(4, 1fr);

    @media (max-width: 1000px) {
        grid-template-columns: repeat(2, 1fr);
    }
`;

const StatCard = styled.div<{ $color: string }>`
    ${tw`p-4 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 3px;
        height: 100%;
        background: ${props => props.$color};
    }
`;

const StatLabel = styled.span`
    ${tw`text-xs uppercase tracking-wide block mb-1`}
    color: #5a7a9a;
`;

const StatValue = styled.span<{ $color: string }>`
    ${tw`text-2xl font-bold`}
    color: ${props => props.$color};
    font-family: 'Rajdhani', sans-serif;
`;

const ContentGrid = styled.div`
    ${tw`grid gap-6`}
    grid-template-columns: 1fr 400px;

    @media (max-width: 1200px) {
        grid-template-columns: 1fr;
    }
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const CardBody = styled.div`
    ${tw`p-0`}
`;

const ReportList = styled.div`
    ${tw`max-h-[500px] overflow-y-auto`}
`;

const ReportItem = styled.div`
    ${tw`p-4`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.5);

    &:last-child {
        border-bottom: none;
    }

    &:hover {
        background: rgba(15, 31, 61, 0.5);
    }
`;

const ReportHeader = styled.div`
    ${tw`flex items-center justify-between mb-2`}
`;

const ReportInfo = styled.div`
    ${tw`flex items-center gap-3`}
`;

const ReportIcon = styled.div<{ $severity: string }>`
    ${tw`w-10 h-10 rounded-lg flex items-center justify-center text-lg`}
    background: ${props => {
        switch(props.$severity) {
            case 'low': return 'rgba(0, 255, 136, 0.15)';
            case 'medium': return 'rgba(255, 204, 0, 0.15)';
            case 'high': return 'rgba(255, 107, 0, 0.15)';
            case 'critical': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$severity) {
            case 'low': return '#00ff88';
            case 'medium': return '#ffcc00';
            case 'high': return '#ff6b00';
            case 'critical': return '#ff3366';
            default: return '#5a7a9a';
        }
    }};
`;

const ReportDetails = styled.div``;

const ReportType = styled.h4`
    ${tw`text-sm font-semibold flex items-center gap-2`}
    color: #ffffff;
`;

const ReportMeta = styled.div`
    ${tw`flex items-center gap-3 text-xs mt-1`}
    color: #5a7a9a;
`;

const SeverityBadge = styled.span<{ $severity: string }>`
    ${tw`px-2 py-0.5 rounded text-xs uppercase font-bold`}
    background: ${props => {
        switch(props.$severity) {
            case 'low': return 'rgba(0, 255, 136, 0.15)';
            case 'medium': return 'rgba(255, 204, 0, 0.15)';
            case 'high': return 'rgba(255, 107, 0, 0.15)';
            case 'critical': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$severity) {
            case 'low': return '#00ff88';
            case 'medium': return '#ffcc00';
            case 'high': return '#ff6b00';
            case 'critical': return '#ff3366';
            default: return '#5a7a9a';
        }
    }};
`;

const StatusBadge = styled.span<{ $status: string }>`
    ${tw`px-2 py-0.5 rounded text-xs uppercase`}
    background: ${props => {
        switch(props.$status) {
            case 'pending': return 'rgba(255, 204, 0, 0.15)';
            case 'investigating': return 'rgba(0, 212, 255, 0.15)';
            case 'resolved': return 'rgba(0, 255, 136, 0.15)';
            case 'dismissed': return 'rgba(90, 122, 154, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$status) {
            case 'pending': return '#ffcc00';
            case 'investigating': return '#00d4ff';
            case 'resolved': return '#00ff88';
            case 'dismissed': return '#5a7a9a';
            default: return '#5a7a9a';
        }
    }};
`;

const ReportDescription = styled.p`
    ${tw`text-sm mt-2`}
    color: #a0b4c8;
`;

const ReportActions = styled.div`
    ${tw`flex gap-2 mt-3`}
`;

const ActionButton = styled.button<{ $variant?: 'primary' | 'danger' | 'success' }>`
    ${tw`py-1.5 px-3 rounded-lg font-semibold text-xs flex items-center gap-1`}
    background: ${props => {
        switch(props.$variant) {
            case 'success': return 'rgba(0, 255, 136, 0.15)';
            case 'danger': return 'rgba(255, 51, 102, 0.15)';
            case 'primary': return 'rgba(0, 212, 255, 0.15)';
            default: return 'rgba(26, 48, 80, 0.5)';
        }
    }};
    border: 1px solid ${props => {
        switch(props.$variant) {
            case 'success': return 'rgba(0, 255, 136, 0.5)';
            case 'danger': return 'rgba(255, 51, 102, 0.5)';
            case 'primary': return 'rgba(0, 212, 255, 0.5)';
            default: return 'rgba(26, 48, 80, 0.8)';
        }
    }};
    color: ${props => {
        switch(props.$variant) {
            case 'success': return '#00ff88';
            case 'danger': return '#ff3366';
            case 'primary': return '#00d4ff';
            default: return '#a0b4c8';
        }
    }};
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-1px);
    }
`;

const IPList = styled.div`
    ${tw`flex flex-col gap-2`}
`;

const IPItem = styled.div`
    ${tw`p-3 rounded-lg flex items-center justify-between`}
    background: rgba(255, 51, 102, 0.1);
    border: 1px solid rgba(255, 51, 102, 0.3);
`;

const IPInfo = styled.div``;

const IPAddress = styled.span`
    ${tw`text-sm font-mono font-bold block`}
    color: #ff3366;
`;

const IPReason = styled.span`
    ${tw`text-xs`}
    color: #5a7a9a;
`;

const IconButton = styled.button`
    ${tw`w-8 h-8 rounded-lg flex items-center justify-center`}
    background: rgba(255, 51, 102, 0.15);
    border: 1px solid rgba(255, 51, 102, 0.5);
    color: #ff3366;
    cursor: pointer;
    transition: all 0.3s ease;

    &:hover {
        background: rgba(255, 51, 102, 0.3);
    }
`;

const AddIPButton = styled.button`
    ${tw`w-full py-3 rounded-lg font-semibold text-sm flex items-center justify-center gap-2`}
    background: rgba(26, 48, 80, 0.3);
    border: 1px dashed rgba(26, 48, 80, 0.8);
    color: #5a7a9a;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #ff3366;
        color: #ff3366;
    }
`;

// Mock data
const mockReports: AbuseReport[] = [
    { id: '1', type: 'ddos', serverId: 's1', serverName: 'FiveM Server', userId: 'u1', userName: 'BadActor', status: 'pending', severity: 'critical', reportedAt: '2024-01-19 15:30', description: 'Suspected DDoS attack detected from multiple IPs' },
    { id: '2', type: 'exploit', serverId: 's2', serverName: 'Minecraft Server', userId: 'u2', userName: 'Hacker123', status: 'investigating', severity: 'high', reportedAt: '2024-01-19 14:45', description: 'User attempting to exploit server vulnerabilities' },
    { id: '3', type: 'tos_violation', serverId: 's3', serverName: 'CS2 Server', userId: 'u3', userName: 'SpamUser', status: 'resolved', severity: 'medium', reportedAt: '2024-01-19 12:00', description: 'Server hosting prohibited content' },
    { id: '4', type: 'spam', serverId: 's4', serverName: 'ARK Server', userId: 'u4', userName: 'TestUser', status: 'dismissed', severity: 'low', reportedAt: '2024-01-18 18:00', description: 'False positive - legitimate high traffic' },
];

const mockBlockedIPs: BlockedIP[] = [
    { ip: '45.33.32.156', reason: 'DDoS attack', blockedAt: '2024-01-19 15:00', expiresAt: null, blockedBy: 'system' },
    { ip: '192.168.1.100', reason: 'Brute force attempts', blockedAt: '2024-01-19 14:30', expiresAt: '2024-01-20 14:30', blockedBy: 'admin' },
    { ip: '10.0.0.55', reason: 'Suspicious activity', blockedAt: '2024-01-18 10:00', expiresAt: '2024-01-25 10:00', blockedBy: 'admin' },
];

const AbuseProtectionContainer: React.FC = () => {
    const [reports] = useState<AbuseReport[]>(mockReports);
    const [blockedIPs] = useState<BlockedIP[]>(mockBlockedIPs);

    const pendingCount = reports.filter(r => r.status === 'pending').length;
    const criticalCount = reports.filter(r => r.severity === 'critical').length;

    return (
        <Container>
            <PageHeader>
                <HeaderContent>
                    <div>
                        <PageTitle>Abuse Protection</PageTitle>
                        <PageSubtitle>Monitor and handle abuse reports and security threats</PageSubtitle>
                    </div>
                    <HeaderActions>
                        <PrimaryButton>
                            <HiOutlineBan /> Block IP
                        </PrimaryButton>
                    </HeaderActions>
                </HeaderContent>
            </PageHeader>

            <StatsGrid>
                <StatCard $color="#ffcc00">
                    <StatLabel>Pending Reports</StatLabel>
                    <StatValue $color="#ffcc00">{pendingCount}</StatValue>
                </StatCard>
                <StatCard $color="#ff3366">
                    <StatLabel>Critical Alerts</StatLabel>
                    <StatValue $color="#ff3366">{criticalCount}</StatValue>
                </StatCard>
                <StatCard $color="#ff3366">
                    <StatLabel>Blocked IPs</StatLabel>
                    <StatValue $color="#ff3366">{blockedIPs.length}</StatValue>
                </StatCard>
                <StatCard $color="#00ff88">
                    <StatLabel>Resolved Today</StatLabel>
                    <StatValue $color="#00ff88">5</StatValue>
                </StatCard>
            </StatsGrid>

            <ContentGrid>
                <Card>
                    <CardHeader>
                        <CardTitle>
                            <HiOutlineExclamation /> Abuse Reports
                        </CardTitle>
                    </CardHeader>
                    <CardBody>
                        <ReportList>
                            {reports.map(report => (
                                <ReportItem key={report.id}>
                                    <ReportHeader>
                                        <ReportInfo>
                                            <ReportIcon $severity={report.severity}>
                                                <HiOutlineShieldCheck />
                                            </ReportIcon>
                                            <ReportDetails>
                                                <ReportType>
                                                    {report.type.replace('_', ' ').toUpperCase()}
                                                    <SeverityBadge $severity={report.severity}>{report.severity}</SeverityBadge>
                                                </ReportType>
                                                <ReportMeta>
                                                    <span>{report.serverName}</span>
                                                    <span>by {report.userName}</span>
                                                    <span>{report.reportedAt}</span>
                                                    <StatusBadge $status={report.status}>{report.status}</StatusBadge>
                                                </ReportMeta>
                                            </ReportDetails>
                                        </ReportInfo>
                                    </ReportHeader>
                                    <ReportDescription>{report.description}</ReportDescription>
                                    {report.status === 'pending' && (
                                        <ReportActions>
                                            <ActionButton $variant="primary">
                                                <HiOutlineEye /> Investigate
                                            </ActionButton>
                                            <ActionButton $variant="success">
                                                <HiOutlineCheck /> Resolve
                                            </ActionButton>
                                            <ActionButton>
                                                Dismiss
                                            </ActionButton>
                                        </ReportActions>
                                    )}
                                </ReportItem>
                            ))}
                        </ReportList>
                    </CardBody>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>
                            <HiOutlineBan /> Blocked IPs
                        </CardTitle>
                    </CardHeader>
                    <CardBody css={tw`p-5`}>
                        <IPList>
                            {blockedIPs.map((ip, index) => (
                                <IPItem key={index}>
                                    <IPInfo>
                                        <IPAddress>{ip.ip}</IPAddress>
                                        <IPReason>{ip.reason} • {ip.expiresAt ? `Expires ${ip.expiresAt}` : 'Permanent'}</IPReason>
                                    </IPInfo>
                                    <IconButton title="Unblock">
                                        <HiOutlineTrash />
                                    </IconButton>
                                </IPItem>
                            ))}
                            <AddIPButton>
                                <HiOutlinePlus /> Add IP to Blocklist
                            </AddIPButton>
                        </IPList>
                    </CardBody>
                </Card>
            </ContentGrid>
        </Container>
    );
};

export default AbuseProtectionContainer;
