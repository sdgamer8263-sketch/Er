import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineServer, HiOutlinePlus, HiOutlineCog, HiOutlineCheck, HiOutlineX, HiOutlineClock, HiOutlineRefresh, HiOutlineUsers, HiOutlineChip, HiOutlineDatabase } from 'react-icons/hi';

interface ProvisioningRequest {
    id: string;
    userId: string;
    userName: string;
    plan: string;
    game: string;
    status: 'pending' | 'provisioning' | 'completed' | 'failed';
    createdAt: string;
    node?: string;
    resources: {
        cpu: number;
        memory: number;
        disk: number;
    };
}

interface Node {
    id: string;
    name: string;
    location: string;
    status: 'online' | 'offline' | 'maintenance';
    usage: {
        cpu: number;
        memory: number;
        disk: number;
        servers: number;
        maxServers: number;
    };
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #00d4ff, #a855f7, #00d4ff);
    }
`;

const HeaderContent = styled.div`
    ${tw`flex items-center justify-between`}
`;

const HeaderText = styled.div``;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const HeaderActions = styled.div`
    ${tw`flex gap-3`}
`;

const PrimaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: linear-gradient(135deg, #00d4ff 0%, #a855f7 100%);
    color: #ffffff;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 212, 255, 0.3);
    }
`;

const StatsGrid = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(4, 1fr);

    @media (max-width: 1000px) {
        grid-template-columns: repeat(2, 1fr);
    }
`;

const StatCard = styled.div<{ $color: string }>`
    ${tw`p-4 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 3px;
        height: 100%;
        background: ${props => props.$color};
    }
`;

const StatLabel = styled.span`
    ${tw`text-xs uppercase tracking-wide block mb-1`}
    color: #5a7a9a;
`;

const StatValue = styled.span<{ $color: string }>`
    ${tw`text-2xl font-bold`}
    color: ${props => props.$color};
    font-family: 'Rajdhani', sans-serif;
`;

const ContentGrid = styled.div`
    ${tw`grid gap-6`}
    grid-template-columns: 1fr 400px;

    @media (max-width: 1200px) {
        grid-template-columns: 1fr;
    }
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const CardBody = styled.div`
    ${tw`p-0`}
`;

const RequestList = styled.div`
    ${tw`max-h-[500px] overflow-y-auto`}
`;

const RequestItem = styled.div`
    ${tw`p-4 flex items-center justify-between`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.5);

    &:last-child {
        border-bottom: none;
    }

    &:hover {
        background: rgba(15, 31, 61, 0.5);
    }
`;

const RequestInfo = styled.div`
    ${tw`flex items-center gap-3`}
`;

const RequestIcon = styled.div<{ $status: string }>`
    ${tw`w-10 h-10 rounded-lg flex items-center justify-center text-lg`}
    background: ${props => {
        switch(props.$status) {
            case 'pending': return 'rgba(255, 204, 0, 0.15)';
            case 'provisioning': return 'rgba(0, 212, 255, 0.15)';
            case 'completed': return 'rgba(0, 255, 136, 0.15)';
            case 'failed': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$status) {
            case 'pending': return '#ffcc00';
            case 'provisioning': return '#00d4ff';
            case 'completed': return '#00ff88';
            case 'failed': return '#ff3366';
            default: return '#5a7a9a';
        }
    }};
`;

const RequestDetails = styled.div``;

const RequestUser = styled.h4`
    ${tw`text-sm font-semibold`}
    color: #ffffff;
`;

const RequestMeta = styled.div`
    ${tw`flex items-center gap-3 text-xs mt-1`}
    color: #5a7a9a;
`;

const StatusBadge = styled.span<{ $status: string }>`
    ${tw`px-2 py-0.5 rounded text-xs uppercase font-bold`}
    background: ${props => {
        switch(props.$status) {
            case 'pending': return 'rgba(255, 204, 0, 0.15)';
            case 'provisioning': return 'rgba(0, 212, 255, 0.15)';
            case 'completed': return 'rgba(0, 255, 136, 0.15)';
            case 'failed': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$status) {
            case 'pending': return '#ffcc00';
            case 'provisioning': return '#00d4ff';
            case 'completed': return '#00ff88';
            case 'failed': return '#ff3366';
            default: return '#5a7a9a';
        }
    }};
`;

const RequestActions = styled.div`
    ${tw`flex gap-2`}
`;

const IconButton = styled.button<{ $variant?: 'success' | 'danger' }>`
    ${tw`w-8 h-8 rounded-lg flex items-center justify-center`}
    background: ${props => {
        switch(props.$variant) {
            case 'success': return 'rgba(0, 255, 136, 0.15)';
            case 'danger': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(26, 48, 80, 0.5)';
        }
    }};
    border: 1px solid ${props => {
        switch(props.$variant) {
            case 'success': return 'rgba(0, 255, 136, 0.5)';
            case 'danger': return 'rgba(255, 51, 102, 0.5)';
            default: return 'rgba(26, 48, 80, 0.8)';
        }
    }};
    color: ${props => {
        switch(props.$variant) {
            case 'success': return '#00ff88';
            case 'danger': return '#ff3366';
            default: return '#a0b4c8';
        }
    }};
    cursor: pointer;
    transition: all 0.3s ease;

    &:hover {
        transform: scale(1.1);
    }
`;

const NodeList = styled.div`
    ${tw`flex flex-col gap-3`}
`;

const NodeCard = styled.div<{ $status: string }>`
    ${tw`p-4 rounded-xl`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid ${props => {
        switch(props.$status) {
            case 'online': return 'rgba(0, 255, 136, 0.5)';
            case 'offline': return 'rgba(255, 51, 102, 0.5)';
            case 'maintenance': return 'rgba(255, 204, 0, 0.5)';
            default: return 'rgba(26, 48, 80, 0.8)';
        }
    }};
`;

const NodeHeader = styled.div`
    ${tw`flex items-center justify-between mb-3`}
`;

const NodeInfo = styled.div`
    ${tw`flex items-center gap-3`}
`;

const NodeIcon = styled.div<{ $status: string }>`
    ${tw`w-10 h-10 rounded-lg flex items-center justify-center text-lg`}
    background: ${props => {
        switch(props.$status) {
            case 'online': return 'rgba(0, 255, 136, 0.15)';
            case 'offline': return 'rgba(255, 51, 102, 0.15)';
            case 'maintenance': return 'rgba(255, 204, 0, 0.15)';
            default: return 'rgba(0, 212, 255, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$status) {
            case 'online': return '#00ff88';
            case 'offline': return '#ff3366';
            case 'maintenance': return '#ffcc00';
            default: return '#00d4ff';
        }
    }};
`;

const NodeDetails = styled.div``;

const NodeName = styled.h4`
    ${tw`text-sm font-semibold`}
    color: #ffffff;
`;

const NodeLocation = styled.span`
    ${tw`text-xs`}
    color: #5a7a9a;
`;

const NodeStats = styled.div`
    ${tw`grid grid-cols-3 gap-2 mt-3`}
`;

const NodeStat = styled.div`
    ${tw`text-center`}
`;

const NodeStatValue = styled.span`
    ${tw`text-sm font-bold block`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const NodeStatLabel = styled.span`
    ${tw`text-xs`}
    color: #5a7a9a;
`;

const ProgressBar = styled.div<{ $percentage: number; $color: string }>`
    ${tw`h-1 rounded-full mt-1 overflow-hidden`}
    background: rgba(15, 31, 61, 0.8);

    &::after {
        content: '';
        display: block;
        height: 100%;
        width: ${props => Math.min(props.$percentage, 100)}%;
        background: ${props => props.$color};
        transition: width 0.5s ease;
    }
`;

// Mock data
const mockRequests: ProvisioningRequest[] = [
    { id: '1', userId: 'u1', userName: 'JohnDoe', plan: 'Pro', game: 'Minecraft', status: 'pending', createdAt: '2024-01-19 15:30', resources: { cpu: 200, memory: 4096, disk: 20480 } },
    { id: '2', userId: 'u2', userName: 'GamerPro', plan: 'Elite', game: 'CS2', status: 'provisioning', createdAt: '2024-01-19 15:25', node: 'EU-01', resources: { cpu: 300, memory: 8192, disk: 40960 } },
    { id: '3', userId: 'u3', userName: 'ServerKing', plan: 'Basic', game: 'FiveM', status: 'completed', createdAt: '2024-01-19 15:00', node: 'US-01', resources: { cpu: 100, memory: 2048, disk: 10240 } },
    { id: '4', userId: 'u4', userName: 'TestUser', plan: 'Pro', game: 'ARK', status: 'failed', createdAt: '2024-01-19 14:45', resources: { cpu: 400, memory: 16384, disk: 81920 } },
];

const mockNodes: Node[] = [
    { id: '1', name: 'EU-01', location: 'Frankfurt, Germany', status: 'online', usage: { cpu: 45, memory: 62, disk: 38, servers: 24, maxServers: 50 } },
    { id: '2', name: 'US-01', location: 'New York, USA', status: 'online', usage: { cpu: 78, memory: 85, disk: 55, servers: 42, maxServers: 50 } },
    { id: '3', name: 'EU-02', location: 'Amsterdam, Netherlands', status: 'maintenance', usage: { cpu: 0, memory: 0, disk: 30, servers: 0, maxServers: 50 } },
];

const ProvisioningManagerContainer: React.FC = () => {
    const [requests] = useState<ProvisioningRequest[]>(mockRequests);
    const [nodes] = useState<Node[]>(mockNodes);

    const pendingCount = requests.filter(r => r.status === 'pending').length;
    const provisioningCount = requests.filter(r => r.status === 'provisioning').length;
    const completedToday = requests.filter(r => r.status === 'completed').length;
    const failedCount = requests.filter(r => r.status === 'failed').length;

    return (
        <Container>
            <PageHeader>
                <HeaderContent>
                    <HeaderText>
                        <PageTitle>Provisioning Manager</PageTitle>
                        <PageSubtitle>Manage server provisioning requests and node allocation</PageSubtitle>
                    </HeaderText>
                    <HeaderActions>
                        <PrimaryButton>
                            <HiOutlinePlus /> Manual Provision
                        </PrimaryButton>
                    </HeaderActions>
                </HeaderContent>
            </PageHeader>

            <StatsGrid>
                <StatCard $color="#ffcc00">
                    <StatLabel>Pending</StatLabel>
                    <StatValue $color="#ffcc00">{pendingCount}</StatValue>
                </StatCard>
                <StatCard $color="#00d4ff">
                    <StatLabel>Provisioning</StatLabel>
                    <StatValue $color="#00d4ff">{provisioningCount}</StatValue>
                </StatCard>
                <StatCard $color="#00ff88">
                    <StatLabel>Completed Today</StatLabel>
                    <StatValue $color="#00ff88">{completedToday}</StatValue>
                </StatCard>
                <StatCard $color="#ff3366">
                    <StatLabel>Failed</StatLabel>
                    <StatValue $color="#ff3366">{failedCount}</StatValue>
                </StatCard>
            </StatsGrid>

            <ContentGrid>
                <Card>
                    <CardHeader>
                        <CardTitle>
                            <HiOutlineClock /> Provisioning Queue
                        </CardTitle>
                    </CardHeader>
                    <CardBody>
                        <RequestList>
                            {requests.map(request => (
                                <RequestItem key={request.id}>
                                    <RequestInfo>
                                        <RequestIcon $status={request.status}>
                                            {request.status === 'pending' && <HiOutlineClock />}
                                            {request.status === 'provisioning' && <HiOutlineRefresh />}
                                            {request.status === 'completed' && <HiOutlineCheck />}
                                            {request.status === 'failed' && <HiOutlineX />}
                                        </RequestIcon>
                                        <RequestDetails>
                                            <RequestUser>{request.userName}</RequestUser>
                                            <RequestMeta>
                                                <span>{request.game}</span>
                                                <span>{request.plan} Plan</span>
                                                <span>{request.createdAt}</span>
                                                <StatusBadge $status={request.status}>
                                                    {request.status}
                                                </StatusBadge>
                                            </RequestMeta>
                                        </RequestDetails>
                                    </RequestInfo>
                                    {request.status === 'pending' && (
                                        <RequestActions>
                                            <IconButton $variant="success" title="Approve">
                                                <HiOutlineCheck />
                                            </IconButton>
                                            <IconButton $variant="danger" title="Reject">
                                                <HiOutlineX />
                                            </IconButton>
                                        </RequestActions>
                                    )}
                                    {request.status === 'failed' && (
                                        <RequestActions>
                                            <IconButton title="Retry">
                                                <HiOutlineRefresh />
                                            </IconButton>
                                        </RequestActions>
                                    )}
                                </RequestItem>
                            ))}
                        </RequestList>
                    </CardBody>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>
                            <HiOutlineServer /> Available Nodes
                        </CardTitle>
                    </CardHeader>
                    <CardBody css={tw`p-5`}>
                        <NodeList>
                            {nodes.map(node => (
                                <NodeCard key={node.id} $status={node.status}>
                                    <NodeHeader>
                                        <NodeInfo>
                                            <NodeIcon $status={node.status}>
                                                <HiOutlineServer />
                                            </NodeIcon>
                                            <NodeDetails>
                                                <NodeName>{node.name}</NodeName>
                                                <NodeLocation>{node.location}</NodeLocation>
                                            </NodeDetails>
                                        </NodeInfo>
                                        <StatusBadge $status={node.status === 'online' ? 'completed' : node.status === 'maintenance' ? 'pending' : 'failed'}>
                                            {node.status}
                                        </StatusBadge>
                                    </NodeHeader>
                                    <NodeStats>
                                        <NodeStat>
                                            <NodeStatValue>{node.usage.cpu}%</NodeStatValue>
                                            <NodeStatLabel>CPU</NodeStatLabel>
                                            <ProgressBar $percentage={node.usage.cpu} $color={node.usage.cpu > 80 ? '#ff3366' : '#00ff88'} />
                                        </NodeStat>
                                        <NodeStat>
                                            <NodeStatValue>{node.usage.memory}%</NodeStatValue>
                                            <NodeStatLabel>RAM</NodeStatLabel>
                                            <ProgressBar $percentage={node.usage.memory} $color={node.usage.memory > 80 ? '#ff3366' : '#00d4ff'} />
                                        </NodeStat>
                                        <NodeStat>
                                            <NodeStatValue>{node.usage.servers}/{node.usage.maxServers}</NodeStatValue>
                                            <NodeStatLabel>Servers</NodeStatLabel>
                                            <ProgressBar $percentage={(node.usage.servers / node.usage.maxServers) * 100} $color="#a855f7" />
                                        </NodeStat>
                                    </NodeStats>
                                </NodeCard>
                            ))}
                        </NodeList>
                    </CardBody>
                </Card>
            </ContentGrid>
        </Container>
    );
};

export default ProvisioningManagerContainer;
