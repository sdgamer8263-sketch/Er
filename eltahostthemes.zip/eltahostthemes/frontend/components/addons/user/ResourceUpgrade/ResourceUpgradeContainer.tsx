import React, { useState, useEffect } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineChip, HiOutlineServer, HiOutlineDatabase, HiOutlineArrowUp, HiOutlineRefresh } from 'react-icons/hi';

interface ResourcePlan {
    id: string;
    name: string;
    cpu: number;
    memory: number;
    disk: number;
    price: number;
}

interface CurrentResources {
    cpu: number;
    memory: number;
    disk: number;
    plan: string;
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #00ff88, #00d4ff, #00ff88);
    }
`;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const ContentGrid = styled.div`
    ${tw`grid gap-6`}
    grid-template-columns: 1fr 400px;

    @media (max-width: 1200px) {
        grid-template-columns: 1fr;
    }
`;

const MainContent = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const Sidebar = styled.div`
    ${tw`flex flex-col gap-4`}
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const CardBody = styled.div`
    ${tw`p-5`}
`;

const ResourceBar = styled.div`
    ${tw`mb-4`}
`;

const ResourceLabel = styled.div`
    ${tw`flex items-center justify-between mb-2`}
`;

const ResourceName = styled.span`
    ${tw`flex items-center gap-2 text-sm font-medium`}
    color: #a0b4c8;
`;

const ResourceValue = styled.span`
    ${tw`text-sm font-mono`}
    color: #ffffff;
`;

const ProgressTrack = styled.div`
    ${tw`h-2 rounded-full overflow-hidden`}
    background: rgba(15, 31, 61, 0.8);
`;

const ProgressFill = styled.div<{ $percentage: number; $color: string }>`
    ${tw`h-full rounded-full`}
    width: ${props => Math.min(props.$percentage, 100)}%;
    background: ${props => props.$color};
    box-shadow: 0 0 10px ${props => props.$color}80;
    transition: width 0.5s ease;
`;

const PlansGrid = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
`;

const PlanCard = styled.div<{ $selected?: boolean; $current?: boolean }>`
    ${tw`p-4 rounded-xl cursor-pointer relative`}
    background: ${props => props.$selected
        ? 'linear-gradient(145deg, rgba(0, 212, 255, 0.1) 0%, rgba(0, 255, 136, 0.05) 100%)'
        : 'rgba(15, 31, 61, 0.5)'};
    border: 2px solid ${props => {
        if (props.$current) return '#00ff88';
        if (props.$selected) return '#00d4ff';
        return 'rgba(26, 48, 80, 0.8)';
    }};
    transition: all 0.3s ease;

    ${props => props.$current && `
        &::after {
            content: 'CURRENT';
            position: absolute;
            top: -10px;
            right: 10px;
            padding: 2px 8px;
            background: #00ff88;
            color: #050a14;
            font-size: 10px;
            font-weight: 700;
            border-radius: 4px;
            font-family: 'Rajdhani', sans-serif;
        }
    `}

    &:hover {
        border-color: ${props => props.$current ? '#00ff88' : '#00d4ff'};
        transform: translateY(-2px);
    }
`;

const PlanName = styled.h4`
    ${tw`text-lg font-bold mb-3`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PlanSpecs = styled.div`
    ${tw`flex flex-col gap-2 mb-4`}
`;

const PlanSpec = styled.div`
    ${tw`flex items-center justify-between text-sm`}
    color: #a0b4c8;

    span:last-child {
        color: #ffffff;
        font-family: 'JetBrains Mono', monospace;
    }
`;

const PlanPrice = styled.div`
    ${tw`text-xl font-bold`}
    color: #00d4ff;
    font-family: 'Rajdhani', sans-serif;

    span {
        ${tw`text-sm font-normal`}
        color: #5a7a9a;
    }
`;

const UpgradeButton = styled.button<{ $disabled?: boolean }>`
    ${tw`w-full py-3 px-6 rounded-lg font-semibold uppercase tracking-wide flex items-center justify-center gap-2`}
    background: ${props => props.$disabled
        ? 'rgba(90, 122, 154, 0.3)'
        : 'linear-gradient(135deg, #00ff88 0%, #00d4ff 100%)'};
    color: ${props => props.$disabled ? '#5a7a9a' : '#050a14'};
    border: none;
    cursor: ${props => props.$disabled ? 'not-allowed' : 'pointer'};
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover:not(:disabled) {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 255, 136, 0.3);
    }
`;

const SummaryItem = styled.div`
    ${tw`flex items-center justify-between py-3`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.5);

    &:last-child {
        border-bottom: none;
    }
`;

const SummaryLabel = styled.span`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const SummaryValue = styled.span`
    ${tw`text-sm font-semibold`}
    color: #ffffff;
`;

const SummaryTotal = styled.div`
    ${tw`flex items-center justify-between pt-4 mt-4`}
    border-top: 2px solid rgba(26, 48, 80, 0.8);
`;

const TotalLabel = styled.span`
    ${tw`text-lg font-semibold`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const TotalValue = styled.span`
    ${tw`text-2xl font-bold`}
    color: #00ff88;
    font-family: 'Rajdhani', sans-serif;
`;

// Mock data
const mockPlans: ResourcePlan[] = [
    { id: 'starter', name: 'Starter', cpu: 100, memory: 2048, disk: 10240, price: 5 },
    { id: 'basic', name: 'Basic', cpu: 200, memory: 4096, disk: 20480, price: 10 },
    { id: 'pro', name: 'Pro', cpu: 300, memory: 8192, disk: 40960, price: 20 },
    { id: 'elite', name: 'Elite', cpu: 400, memory: 16384, disk: 81920, price: 35 },
    { id: 'ultimate', name: 'Ultimate', cpu: 500, memory: 32768, disk: 163840, price: 60 },
];

const mockCurrentResources: CurrentResources = {
    cpu: 200,
    memory: 4096,
    disk: 20480,
    plan: 'basic'
};

const ResourceUpgradeContainer: React.FC = () => {
    const [currentResources] = useState<CurrentResources>(mockCurrentResources);
    const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);

    const formatMemory = (mb: number): string => {
        if (mb >= 1024) return `${(mb / 1024).toFixed(0)} GB`;
        return `${mb} MB`;
    };

    const formatDisk = (mb: number): string => {
        if (mb >= 1024) return `${(mb / 1024).toFixed(0)} GB`;
        return `${mb} MB`;
    };

    const selectedPlanData = selectedPlan ? mockPlans.find(p => p.id === selectedPlan) : null;
    const currentPlanData = mockPlans.find(p => p.id === currentResources.plan);
    const priceDifference = selectedPlanData && currentPlanData
        ? selectedPlanData.price - currentPlanData.price
        : 0;

    const handleUpgrade = async () => {
        if (!selectedPlan || selectedPlan === currentResources.plan) return;

        setLoading(true);
        // API call would go here
        await new Promise(resolve => setTimeout(resolve, 2000));
        setLoading(false);
    };

    return (
        <Container>
            <PageHeader>
                <PageTitle>Resource Upgrade Manager</PageTitle>
                <PageSubtitle>Upgrade your server resources to handle more players and better performance</PageSubtitle>
            </PageHeader>

            <ContentGrid>
                <MainContent>
                    {/* Current Resources */}
                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineRefresh /> Current Resources
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <ResourceBar>
                                <ResourceLabel>
                                    <ResourceName><HiOutlineChip /> CPU</ResourceName>
                                    <ResourceValue>{currentResources.cpu}%</ResourceValue>
                                </ResourceLabel>
                                <ProgressTrack>
                                    <ProgressFill $percentage={currentResources.cpu / 5} $color="#ffcc00" />
                                </ProgressTrack>
                            </ResourceBar>

                            <ResourceBar>
                                <ResourceLabel>
                                    <ResourceName><HiOutlineServer /> Memory</ResourceName>
                                    <ResourceValue>{formatMemory(currentResources.memory)}</ResourceValue>
                                </ResourceLabel>
                                <ProgressTrack>
                                    <ProgressFill $percentage={(currentResources.memory / 32768) * 100} $color="#00ff88" />
                                </ProgressTrack>
                            </ResourceBar>

                            <ResourceBar>
                                <ResourceLabel>
                                    <ResourceName><HiOutlineDatabase /> Disk</ResourceName>
                                    <ResourceValue>{formatDisk(currentResources.disk)}</ResourceValue>
                                </ResourceLabel>
                                <ProgressTrack>
                                    <ProgressFill $percentage={(currentResources.disk / 163840) * 100} $color="#a855f7" />
                                </ProgressTrack>
                            </ResourceBar>
                        </CardBody>
                    </Card>

                    {/* Available Plans */}
                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineArrowUp /> Available Upgrades
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <PlansGrid>
                                {mockPlans.map(plan => (
                                    <PlanCard
                                        key={plan.id}
                                        $selected={selectedPlan === plan.id}
                                        $current={currentResources.plan === plan.id}
                                        onClick={() => setSelectedPlan(plan.id)}
                                    >
                                        <PlanName>{plan.name}</PlanName>
                                        <PlanSpecs>
                                            <PlanSpec>
                                                <span>CPU</span>
                                                <span>{plan.cpu}%</span>
                                            </PlanSpec>
                                            <PlanSpec>
                                                <span>RAM</span>
                                                <span>{formatMemory(plan.memory)}</span>
                                            </PlanSpec>
                                            <PlanSpec>
                                                <span>Disk</span>
                                                <span>{formatDisk(plan.disk)}</span>
                                            </PlanSpec>
                                        </PlanSpecs>
                                        <PlanPrice>
                                            €{plan.price.toFixed(2)}<span>/month</span>
                                        </PlanPrice>
                                    </PlanCard>
                                ))}
                            </PlansGrid>
                        </CardBody>
                    </Card>
                </MainContent>

                <Sidebar>
                    {/* Order Summary */}
                    <Card>
                        <CardHeader>
                            <CardTitle>Upgrade Summary</CardTitle>
                        </CardHeader>
                        <CardBody>
                            {selectedPlanData ? (
                                <>
                                    <SummaryItem>
                                        <SummaryLabel>Current Plan</SummaryLabel>
                                        <SummaryValue>{currentPlanData?.name}</SummaryValue>
                                    </SummaryItem>
                                    <SummaryItem>
                                        <SummaryLabel>New Plan</SummaryLabel>
                                        <SummaryValue>{selectedPlanData.name}</SummaryValue>
                                    </SummaryItem>
                                    <SummaryItem>
                                        <SummaryLabel>CPU Change</SummaryLabel>
                                        <SummaryValue style={{ color: selectedPlanData.cpu > currentResources.cpu ? '#00ff88' : '#ff3366' }}>
                                            {selectedPlanData.cpu > currentResources.cpu ? '+' : ''}{selectedPlanData.cpu - currentResources.cpu}%
                                        </SummaryValue>
                                    </SummaryItem>
                                    <SummaryItem>
                                        <SummaryLabel>RAM Change</SummaryLabel>
                                        <SummaryValue style={{ color: selectedPlanData.memory > currentResources.memory ? '#00ff88' : '#ff3366' }}>
                                            {selectedPlanData.memory > currentResources.memory ? '+' : ''}{formatMemory(selectedPlanData.memory - currentResources.memory)}
                                        </SummaryValue>
                                    </SummaryItem>
                                    <SummaryTotal>
                                        <TotalLabel>Price Difference</TotalLabel>
                                        <TotalValue style={{ color: priceDifference >= 0 ? '#00ff88' : '#ff3366' }}>
                                            {priceDifference >= 0 ? '+' : ''}€{priceDifference.toFixed(2)}/mo
                                        </TotalValue>
                                    </SummaryTotal>
                                </>
                            ) : (
                                <p css={tw`text-sm text-center py-4`} style={{ color: '#5a7a9a' }}>
                                    Select a plan to see upgrade details
                                </p>
                            )}
                        </CardBody>
                    </Card>

                    <UpgradeButton
                        $disabled={!selectedPlan || selectedPlan === currentResources.plan || loading}
                        onClick={handleUpgrade}
                    >
                        {loading ? (
                            <>Processing...</>
                        ) : (
                            <>
                                <HiOutlineArrowUp />
                                {selectedPlan === currentResources.plan ? 'Current Plan' : 'Upgrade Now'}
                            </>
                        )}
                    </UpgradeButton>
                </Sidebar>
            </ContentGrid>
        </Container>
    );
};

export default ResourceUpgradeContainer;
