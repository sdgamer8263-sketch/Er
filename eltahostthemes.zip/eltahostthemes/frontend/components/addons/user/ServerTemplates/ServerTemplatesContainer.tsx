import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineTemplate, HiOutlineDuplicate, HiOutlinePlus, HiOutlineDownload, HiOutlineTrash, HiOutlineClock, HiOutlineServer } from 'react-icons/hi';

interface Template {
    id: string;
    name: string;
    description: string;
    game: string;
    createdAt: string;
    size: string;
    isPublic: boolean;
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #a855f7, #00d4ff, #a855f7);
    }
`;

const HeaderContent = styled.div`
    ${tw`flex items-center justify-between`}
`;

const HeaderText = styled.div``;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const CreateButton = styled.button`
    ${tw`px-6 py-3 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2`}
    background: linear-gradient(135deg, #a855f7 0%, #00d4ff 100%);
    color: #ffffff;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(168, 85, 247, 0.3);
    }
`;

const TabsContainer = styled.div`
    ${tw`flex gap-2 p-1 rounded-xl`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.8);
    width: fit-content;
`;

const Tab = styled.button<{ $active?: boolean }>`
    ${tw`px-6 py-2 rounded-lg font-semibold text-sm uppercase tracking-wide`}
    background: ${props => props.$active ? 'linear-gradient(135deg, #00d4ff 0%, #a855f7 100%)' : 'transparent'};
    color: ${props => props.$active ? '#ffffff' : '#5a7a9a'};
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        color: #ffffff;
    }
`;

const TemplatesGrid = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
`;

const TemplateCard = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
    transition: all 0.3s ease;

    &:hover {
        border-color: #00d4ff;
        transform: translateY(-4px);
        box-shadow: 0 8px 32px rgba(0, 212, 255, 0.15);
    }
`;

const TemplateHeader = styled.div`
    ${tw`p-4 flex items-start justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const TemplateInfo = styled.div`
    ${tw`flex items-start gap-3`}
`;

const TemplateIcon = styled.div`
    ${tw`w-12 h-12 rounded-lg flex items-center justify-center text-xl`}
    background: rgba(168, 85, 247, 0.15);
    border: 1px solid #a855f7;
    color: #a855f7;
`;

const TemplateTitle = styled.h3`
    ${tw`text-lg font-bold`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const TemplateGame = styled.span`
    ${tw`text-xs px-2 py-1 rounded-md`}
    background: rgba(0, 212, 255, 0.15);
    border: 1px solid rgba(0, 212, 255, 0.5);
    color: #00d4ff;
`;

const TemplateBody = styled.div`
    ${tw`p-4`}
`;

const TemplateDescription = styled.p`
    ${tw`text-sm mb-4`}
    color: #a0b4c8;
`;

const TemplateMeta = styled.div`
    ${tw`flex items-center gap-4 text-xs mb-4`}
    color: #5a7a9a;
`;

const MetaItem = styled.span`
    ${tw`flex items-center gap-1`}
`;

const TemplateActions = styled.div`
    ${tw`flex gap-2`}
`;

const ActionButton = styled.button<{ $variant?: 'primary' | 'secondary' | 'danger' }>`
    ${tw`flex-1 py-2 px-4 rounded-lg font-semibold text-sm flex items-center justify-center gap-2`}
    background: ${props => {
        switch(props.$variant) {
            case 'primary': return 'linear-gradient(135deg, #00d4ff 0%, #a855f7 100%)';
            case 'danger': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(26, 48, 80, 0.5)';
        }
    }};
    border: 1px solid ${props => {
        switch(props.$variant) {
            case 'primary': return 'transparent';
            case 'danger': return '#ff3366';
            default: return 'rgba(26, 48, 80, 0.8)';
        }
    }};
    color: ${props => {
        switch(props.$variant) {
            case 'primary': return '#ffffff';
            case 'danger': return '#ff3366';
            default: return '#a0b4c8';
        }
    }};
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
    }
`;

const Modal = styled.div<{ $visible: boolean }>`
    ${tw`fixed inset-0 flex items-center justify-center z-50`}
    display: ${props => props.$visible ? 'flex' : 'none'};
    background: rgba(5, 10, 20, 0.8);
    backdrop-filter: blur(4px);
`;

const ModalContent = styled.div`
    ${tw`w-full max-w-md rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.95) 0%, rgba(10, 22, 40, 0.98) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const ModalHeader = styled.div`
    ${tw`px-6 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const ModalTitle = styled.h3`
    ${tw`text-lg font-bold`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const ModalClose = styled.button`
    ${tw`w-8 h-8 rounded-lg flex items-center justify-center text-lg`}
    background: rgba(255, 51, 102, 0.15);
    border: 1px solid rgba(255, 51, 102, 0.5);
    color: #ff3366;
    cursor: pointer;
    transition: all 0.3s ease;

    &:hover {
        background: rgba(255, 51, 102, 0.3);
    }
`;

const ModalBody = styled.div`
    ${tw`p-6`}
`;

const FormGroup = styled.div`
    ${tw`mb-4`}
`;

const FormLabel = styled.label`
    ${tw`block text-sm font-medium mb-2`}
    color: #a0b4c8;
`;

const FormInput = styled.input`
    ${tw`w-full px-4 py-3 rounded-lg text-sm`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #ffffff;
    font-family: 'Inter', sans-serif;
    transition: all 0.3s ease;

    &:focus {
        outline: none;
        border-color: #00d4ff;
        box-shadow: 0 0 20px rgba(0, 212, 255, 0.2);
    }

    &::placeholder {
        color: #5a7a9a;
    }
`;

const FormTextarea = styled.textarea`
    ${tw`w-full px-4 py-3 rounded-lg text-sm resize-none`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #ffffff;
    font-family: 'Inter', sans-serif;
    transition: all 0.3s ease;
    min-height: 100px;

    &:focus {
        outline: none;
        border-color: #00d4ff;
        box-shadow: 0 0 20px rgba(0, 212, 255, 0.2);
    }

    &::placeholder {
        color: #5a7a9a;
    }
`;

const FormCheckbox = styled.label`
    ${tw`flex items-center gap-3 cursor-pointer`}
    color: #a0b4c8;

    input {
        ${tw`w-5 h-5 rounded`}
        accent-color: #00d4ff;
    }
`;

const ModalFooter = styled.div`
    ${tw`px-6 py-4 flex gap-3`}
    background: rgba(15, 31, 61, 0.3);
    border-top: 1px solid rgba(26, 48, 80, 0.8);
`;

const EmptyState = styled.div`
    ${tw`flex flex-col items-center justify-center py-16 rounded-xl`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const EmptyIcon = styled.div`
    ${tw`w-20 h-20 rounded-xl flex items-center justify-center text-4xl mb-4`}
    background: rgba(168, 85, 247, 0.15);
    border: 1px solid rgba(168, 85, 247, 0.5);
    color: #a855f7;
`;

const EmptyTitle = styled.h3`
    ${tw`text-xl font-bold mb-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const EmptyDescription = styled.p`
    ${tw`text-sm mb-6`}
    color: #5a7a9a;
`;

// Mock data
const mockTemplates: Template[] = [
    {
        id: '1',
        name: 'CS2 Competitive Setup',
        description: 'Pre-configured competitive settings with essential plugins and configs',
        game: 'Counter-Strike 2',
        createdAt: '2024-01-15',
        size: '245 MB',
        isPublic: false
    },
    {
        id: '2',
        name: 'FiveM RP Base',
        description: 'Roleplay server base with ESX framework and essential scripts',
        game: 'FiveM',
        createdAt: '2024-01-10',
        size: '1.2 GB',
        isPublic: true
    },
    {
        id: '3',
        name: 'ARK PvE Cluster',
        description: 'PvE optimized settings with boosted rates and quality of life mods',
        game: 'ARK: Survival Evolved',
        createdAt: '2024-01-08',
        size: '890 MB',
        isPublic: false
    }
];

const ServerTemplatesContainer: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'my-templates' | 'public'>('my-templates');
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [templates] = useState<Template[]>(mockTemplates);

    const filteredTemplates = templates.filter(t =>
        activeTab === 'my-templates' ? !t.isPublic : t.isPublic
    );

    return (
        <Container>
            <PageHeader>
                <HeaderContent>
                    <HeaderText>
                        <PageTitle>Server Templates & Cloning</PageTitle>
                        <PageSubtitle>Save your server configurations and clone them to new servers</PageSubtitle>
                    </HeaderText>
                    <CreateButton onClick={() => setShowCreateModal(true)}>
                        <HiOutlinePlus />
                        Create Template
                    </CreateButton>
                </HeaderContent>
            </PageHeader>

            <TabsContainer>
                <Tab $active={activeTab === 'my-templates'} onClick={() => setActiveTab('my-templates')}>
                    <HiOutlineTemplate css={tw`inline mr-1`} /> My Templates
                </Tab>
                <Tab $active={activeTab === 'public'} onClick={() => setActiveTab('public')}>
                    <HiOutlineServer css={tw`inline mr-1`} /> Public Templates
                </Tab>
            </TabsContainer>

            {filteredTemplates.length > 0 ? (
                <TemplatesGrid>
                    {filteredTemplates.map(template => (
                        <TemplateCard key={template.id}>
                            <TemplateHeader>
                                <TemplateInfo>
                                    <TemplateIcon>
                                        <HiOutlineTemplate />
                                    </TemplateIcon>
                                    <div>
                                        <TemplateTitle>{template.name}</TemplateTitle>
                                        <TemplateGame>{template.game}</TemplateGame>
                                    </div>
                                </TemplateInfo>
                            </TemplateHeader>
                            <TemplateBody>
                                <TemplateDescription>{template.description}</TemplateDescription>
                                <TemplateMeta>
                                    <MetaItem>
                                        <HiOutlineClock /> {template.createdAt}
                                    </MetaItem>
                                    <MetaItem>
                                        <HiOutlineDatabase /> {template.size}
                                    </MetaItem>
                                </TemplateMeta>
                                <TemplateActions>
                                    <ActionButton $variant="primary">
                                        <HiOutlineDuplicate /> Clone
                                    </ActionButton>
                                    <ActionButton $variant="secondary">
                                        <HiOutlineDownload />
                                    </ActionButton>
                                    {!template.isPublic && (
                                        <ActionButton $variant="danger">
                                            <HiOutlineTrash />
                                        </ActionButton>
                                    )}
                                </TemplateActions>
                            </TemplateBody>
                        </TemplateCard>
                    ))}
                </TemplatesGrid>
            ) : (
                <EmptyState>
                    <EmptyIcon>
                        <HiOutlineTemplate />
                    </EmptyIcon>
                    <EmptyTitle>No Templates Found</EmptyTitle>
                    <EmptyDescription>
                        {activeTab === 'my-templates'
                            ? 'Create your first template to save your server configuration'
                            : 'No public templates available at this time'
                        }
                    </EmptyDescription>
                    {activeTab === 'my-templates' && (
                        <CreateButton onClick={() => setShowCreateModal(true)}>
                            <HiOutlinePlus /> Create Template
                        </CreateButton>
                    )}
                </EmptyState>
            )}

            {/* Create Template Modal */}
            <Modal $visible={showCreateModal} onClick={() => setShowCreateModal(false)}>
                <ModalContent onClick={e => e.stopPropagation()}>
                    <ModalHeader>
                        <ModalTitle>Create New Template</ModalTitle>
                        <ModalClose onClick={() => setShowCreateModal(false)}>×</ModalClose>
                    </ModalHeader>
                    <ModalBody>
                        <FormGroup>
                            <FormLabel>Template Name</FormLabel>
                            <FormInput type="text" placeholder="Enter template name..." />
                        </FormGroup>
                        <FormGroup>
                            <FormLabel>Description</FormLabel>
                            <FormTextarea placeholder="Describe what this template includes..." />
                        </FormGroup>
                        <FormGroup>
                            <FormCheckbox>
                                <input type="checkbox" />
                                <span>Include server files (configs, plugins, mods)</span>
                            </FormCheckbox>
                        </FormGroup>
                        <FormGroup>
                            <FormCheckbox>
                                <input type="checkbox" />
                                <span>Include database (if applicable)</span>
                            </FormCheckbox>
                        </FormGroup>
                        <FormGroup>
                            <FormCheckbox>
                                <input type="checkbox" />
                                <span>Make this template public</span>
                            </FormCheckbox>
                        </FormGroup>
                    </ModalBody>
                    <ModalFooter>
                        <ActionButton $variant="secondary" onClick={() => setShowCreateModal(false)} css={tw`flex-1`}>
                            Cancel
                        </ActionButton>
                        <ActionButton $variant="primary" css={tw`flex-1`}>
                            <HiOutlinePlus /> Create Template
                        </ActionButton>
                    </ModalFooter>
                </ModalContent>
            </Modal>
        </Container>
    );
};

// Fix missing import
const HiOutlineDatabase = styled.span``;

export default ServerTemplatesContainer;
