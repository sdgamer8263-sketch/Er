import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineArchive, HiOutlineClock, HiOutlineDownload, HiOutlineRefresh, HiOutlineTrash, HiOutlinePlus, HiOutlineCalendar, HiOutlineCheck, HiOutlineExclamation } from 'react-icons/hi';

interface Backup {
    id: string;
    name: string;
    size: string;
    createdAt: string;
    type: 'manual' | 'scheduled' | 'auto';
    status: 'completed' | 'in-progress' | 'failed';
    retention: string;
}

interface Schedule {
    id: string;
    name: string;
    frequency: 'hourly' | 'daily' | 'weekly';
    time: string;
    retention: number;
    enabled: boolean;
    lastRun: string;
    nextRun: string;
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #00ff88, #00d4ff, #00ff88);
    }
`;

const HeaderContent = styled.div`
    ${tw`flex items-center justify-between`}
`;

const HeaderText = styled.div``;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const HeaderActions = styled.div`
    ${tw`flex gap-3`}
`;

const PrimaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: linear-gradient(135deg, #00ff88 0%, #00d4ff 100%);
    color: #050a14;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 255, 136, 0.3);
    }
`;

const SecondaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: rgba(26, 48, 80, 0.5);
    color: #a0b4c8;
    border: 1px solid rgba(26, 48, 80, 0.8);
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #00d4ff;
        color: #00d4ff;
    }
`;

const StatsGrid = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(4, 1fr);

    @media (max-width: 1000px) {
        grid-template-columns: repeat(2, 1fr);
    }

    @media (max-width: 600px) {
        grid-template-columns: 1fr;
    }
`;

const StatCard = styled.div`
    ${tw`p-4 rounded-xl`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const StatLabel = styled.span`
    ${tw`text-xs uppercase tracking-wide block mb-1`}
    color: #5a7a9a;
    font-family: 'Rajdhani', sans-serif;
`;

const StatValue = styled.span`
    ${tw`text-2xl font-bold`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const StatSubtext = styled.span`
    ${tw`text-xs ml-1`}
    color: #5a7a9a;
`;

const ContentGrid = styled.div`
    ${tw`grid gap-6`}
    grid-template-columns: 1fr 380px;

    @media (max-width: 1200px) {
        grid-template-columns: 1fr;
    }
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const CardBody = styled.div`
    ${tw`p-0`}
`;

const BackupList = styled.div`
    ${tw`max-h-96 overflow-y-auto`}
`;

const BackupItem = styled.div`
    ${tw`flex items-center justify-between p-4`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.5);
    transition: background 0.2s ease;

    &:hover {
        background: rgba(15, 31, 61, 0.5);
    }

    &:last-child {
        border-bottom: none;
    }
`;

const BackupInfo = styled.div`
    ${tw`flex items-center gap-3`}
`;

const BackupIcon = styled.div<{ $status: string }>`
    ${tw`w-10 h-10 rounded-lg flex items-center justify-center text-lg`}
    background: ${props => {
        switch(props.$status) {
            case 'completed': return 'rgba(0, 255, 136, 0.15)';
            case 'in-progress': return 'rgba(255, 204, 0, 0.15)';
            case 'failed': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(0, 212, 255, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$status) {
            case 'completed': return '#00ff88';
            case 'in-progress': return '#ffcc00';
            case 'failed': return '#ff3366';
            default: return '#00d4ff';
        }
    }};
`;

const BackupDetails = styled.div``;

const BackupName = styled.h4`
    ${tw`text-sm font-semibold`}
    color: #ffffff;
`;

const BackupMeta = styled.div`
    ${tw`flex items-center gap-3 text-xs mt-1`}
    color: #5a7a9a;
`;

const BackupBadge = styled.span<{ $type: string }>`
    ${tw`px-2 py-0.5 rounded text-xs uppercase`}
    background: ${props => {
        switch(props.$type) {
            case 'manual': return 'rgba(0, 212, 255, 0.15)';
            case 'scheduled': return 'rgba(168, 85, 247, 0.15)';
            case 'auto': return 'rgba(0, 255, 136, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$type) {
            case 'manual': return '#00d4ff';
            case 'scheduled': return '#a855f7';
            case 'auto': return '#00ff88';
            default: return '#5a7a9a';
        }
    }};
`;

const BackupActions = styled.div`
    ${tw`flex gap-2`}
`;

const IconButton = styled.button<{ $variant?: 'primary' | 'danger' }>`
    ${tw`w-9 h-9 rounded-lg flex items-center justify-center`}
    background: ${props => props.$variant === 'danger' ? 'rgba(255, 51, 102, 0.15)' : 'rgba(26, 48, 80, 0.5)'};
    border: 1px solid ${props => props.$variant === 'danger' ? 'rgba(255, 51, 102, 0.5)' : 'rgba(26, 48, 80, 0.8)'};
    color: ${props => props.$variant === 'danger' ? '#ff3366' : '#a0b4c8'};
    cursor: pointer;
    transition: all 0.3s ease;

    &:hover {
        border-color: ${props => props.$variant === 'danger' ? '#ff3366' : '#00d4ff'};
        color: ${props => props.$variant === 'danger' ? '#ff3366' : '#00d4ff'};
    }
`;

const ScheduleList = styled.div``;

const ScheduleItem = styled.div`
    ${tw`p-4`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.5);

    &:last-child {
        border-bottom: none;
    }
`;

const ScheduleHeader = styled.div`
    ${tw`flex items-center justify-between mb-3`}
`;

const ScheduleName = styled.h4`
    ${tw`text-sm font-semibold flex items-center gap-2`}
    color: #ffffff;
`;

const ScheduleToggle = styled.label`
    ${tw`relative inline-block w-12 h-6 cursor-pointer`}

    input {
        ${tw`opacity-0 w-0 h-0`}
    }

    span {
        ${tw`absolute inset-0 rounded-full transition-colors`}
        background: rgba(26, 48, 80, 0.8);

        &::before {
            content: '';
            ${tw`absolute w-5 h-5 rounded-full transition-transform`}
            background: #ffffff;
            top: 2px;
            left: 2px;
        }
    }

    input:checked + span {
        background: linear-gradient(135deg, #00ff88 0%, #00d4ff 100%);
    }

    input:checked + span::before {
        transform: translateX(24px);
    }
`;

const ScheduleDetails = styled.div`
    ${tw`grid grid-cols-2 gap-2 text-xs`}
    color: #5a7a9a;
`;

const ScheduleDetail = styled.div`
    ${tw`flex items-center gap-1`}
`;

// Mock data
const mockBackups: Backup[] = [
    { id: '1', name: 'backup_2024-01-19_14-30', size: '2.4 GB', createdAt: '2024-01-19 14:30', type: 'manual', status: 'completed', retention: '30 days' },
    { id: '2', name: 'scheduled_daily_2024-01-19', size: '2.3 GB', createdAt: '2024-01-19 03:00', type: 'scheduled', status: 'completed', retention: '7 days' },
    { id: '3', name: 'auto_crash_2024-01-18', size: '2.1 GB', createdAt: '2024-01-18 22:15', type: 'auto', status: 'completed', retention: '14 days' },
    { id: '4', name: 'backup_2024-01-18_10-00', size: '-', createdAt: '2024-01-18 10:00', type: 'manual', status: 'failed', retention: '-' },
];

const mockSchedules: Schedule[] = [
    { id: '1', name: 'Daily Backup', frequency: 'daily', time: '03:00', retention: 7, enabled: true, lastRun: '2024-01-19 03:00', nextRun: '2024-01-20 03:00' },
    { id: '2', name: 'Weekly Full Backup', frequency: 'weekly', time: '04:00', retention: 30, enabled: true, lastRun: '2024-01-14 04:00', nextRun: '2024-01-21 04:00' },
];

const BackupManagerContainer: React.FC = () => {
    const [backups] = useState<Backup[]>(mockBackups);
    const [schedules, setSchedules] = useState<Schedule[]>(mockSchedules);

    const toggleSchedule = (id: string) => {
        setSchedules(prev => prev.map(s =>
            s.id === id ? { ...s, enabled: !s.enabled } : s
        ));
    };

    const totalSize = '6.8 GB';
    const completedBackups = backups.filter(b => b.status === 'completed').length;

    return (
        <Container>
            <PageHeader>
                <HeaderContent>
                    <HeaderText>
                        <PageTitle>Advanced Backup Manager</PageTitle>
                        <PageSubtitle>Create, schedule, and manage your server backups</PageSubtitle>
                    </HeaderText>
                    <HeaderActions>
                        <SecondaryButton>
                            <HiOutlineCalendar /> Schedule
                        </SecondaryButton>
                        <PrimaryButton>
                            <HiOutlinePlus /> Create Backup
                        </PrimaryButton>
                    </HeaderActions>
                </HeaderContent>
            </PageHeader>

            <StatsGrid>
                <StatCard>
                    <StatLabel>Total Backups</StatLabel>
                    <StatValue>{backups.length}</StatValue>
                </StatCard>
                <StatCard>
                    <StatLabel>Storage Used</StatLabel>
                    <StatValue>{totalSize}<StatSubtext>/ 50 GB</StatSubtext></StatValue>
                </StatCard>
                <StatCard>
                    <StatLabel>Completed</StatLabel>
                    <StatValue style={{ color: '#00ff88' }}>{completedBackups}</StatValue>
                </StatCard>
                <StatCard>
                    <StatLabel>Active Schedules</StatLabel>
                    <StatValue style={{ color: '#00d4ff' }}>{schedules.filter(s => s.enabled).length}</StatValue>
                </StatCard>
            </StatsGrid>

            <ContentGrid>
                <Card>
                    <CardHeader>
                        <CardTitle>
                            <HiOutlineArchive /> Backup History
                        </CardTitle>
                    </CardHeader>
                    <CardBody>
                        <BackupList>
                            {backups.map(backup => (
                                <BackupItem key={backup.id}>
                                    <BackupInfo>
                                        <BackupIcon $status={backup.status}>
                                            {backup.status === 'completed' && <HiOutlineCheck />}
                                            {backup.status === 'in-progress' && <HiOutlineRefresh />}
                                            {backup.status === 'failed' && <HiOutlineExclamation />}
                                        </BackupIcon>
                                        <BackupDetails>
                                            <BackupName>{backup.name}</BackupName>
                                            <BackupMeta>
                                                <span>{backup.createdAt}</span>
                                                <span>{backup.size}</span>
                                                <BackupBadge $type={backup.type}>{backup.type}</BackupBadge>
                                            </BackupMeta>
                                        </BackupDetails>
                                    </BackupInfo>
                                    <BackupActions>
                                        {backup.status === 'completed' && (
                                            <>
                                                <IconButton title="Restore">
                                                    <HiOutlineRefresh />
                                                </IconButton>
                                                <IconButton title="Download">
                                                    <HiOutlineDownload />
                                                </IconButton>
                                            </>
                                        )}
                                        <IconButton $variant="danger" title="Delete">
                                            <HiOutlineTrash />
                                        </IconButton>
                                    </BackupActions>
                                </BackupItem>
                            ))}
                        </BackupList>
                    </CardBody>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>
                            <HiOutlineClock /> Backup Schedules
                        </CardTitle>
                    </CardHeader>
                    <CardBody>
                        <ScheduleList>
                            {schedules.map(schedule => (
                                <ScheduleItem key={schedule.id}>
                                    <ScheduleHeader>
                                        <ScheduleName>
                                            <HiOutlineCalendar />
                                            {schedule.name}
                                        </ScheduleName>
                                        <ScheduleToggle>
                                            <input
                                                type="checkbox"
                                                checked={schedule.enabled}
                                                onChange={() => toggleSchedule(schedule.id)}
                                            />
                                            <span />
                                        </ScheduleToggle>
                                    </ScheduleHeader>
                                    <ScheduleDetails>
                                        <ScheduleDetail>
                                            <HiOutlineClock /> {schedule.frequency} at {schedule.time}
                                        </ScheduleDetail>
                                        <ScheduleDetail>
                                            <HiOutlineArchive /> Keep {schedule.retention} days
                                        </ScheduleDetail>
                                        <ScheduleDetail>
                                            Last: {schedule.lastRun}
                                        </ScheduleDetail>
                                        <ScheduleDetail>
                                            Next: {schedule.nextRun}
                                        </ScheduleDetail>
                                    </ScheduleDetails>
                                </ScheduleItem>
                            ))}
                        </ScheduleList>
                    </CardBody>
                </Card>
            </ContentGrid>
        </Container>
    );
};

export default BackupManagerContainer;
