import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineClock, HiOutlinePlay, HiOutlinePause, HiOutlineTrash, HiOutlinePlus, HiOutlineCalendar, HiOutlineTerminal, HiOutlineRefresh, HiOutlinePencil } from 'react-icons/hi';

interface ScheduledTask {
    id: string;
    name: string;
    command: string;
    schedule: string;
    nextRun: string;
    lastRun: string;
    lastStatus: 'success' | 'failed' | 'pending';
    enabled: boolean;
    type: 'command' | 'restart' | 'backup' | 'power';
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #00d4ff, #a855f7, #00d4ff);
    }
`;

const HeaderContent = styled.div`
    ${tw`flex items-center justify-between`}
`;

const HeaderText = styled.div``;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const PrimaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: linear-gradient(135deg, #00d4ff 0%, #a855f7 100%);
    color: #ffffff;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 212, 255, 0.3);
    }
`;

const QuickActionsGrid = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(4, 1fr);

    @media (max-width: 1000px) {
        grid-template-columns: repeat(2, 1fr);
    }

    @media (max-width: 600px) {
        grid-template-columns: 1fr;
    }
`;

const QuickAction = styled.button<{ $color: string }>`
    ${tw`p-4 rounded-xl flex flex-col items-center gap-3 cursor-pointer`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
    transition: all 0.3s ease;

    &:hover {
        border-color: ${props => props.$color};
        transform: translateY(-2px);
        box-shadow: 0 8px 25px ${props => props.$color}30;
    }
`;

const QuickActionIcon = styled.div<{ $color: string }>`
    ${tw`w-12 h-12 rounded-lg flex items-center justify-center text-2xl`}
    background: ${props => `${props.$color}15`};
    border: 1px solid ${props => props.$color};
    color: ${props => props.$color};
`;

const QuickActionLabel = styled.span`
    ${tw`text-sm font-semibold`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const QuickActionDesc = styled.span`
    ${tw`text-xs`}
    color: #5a7a9a;
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const TaskList = styled.div``;

const TaskItem = styled.div<{ $enabled: boolean }>`
    ${tw`p-4`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.5);
    opacity: ${props => props.$enabled ? 1 : 0.5};
    transition: all 0.3s ease;

    &:hover {
        background: rgba(15, 31, 61, 0.5);
    }

    &:last-child {
        border-bottom: none;
    }
`;

const TaskHeader = styled.div`
    ${tw`flex items-center justify-between mb-3`}
`;

const TaskInfo = styled.div`
    ${tw`flex items-center gap-3`}
`;

const TaskIcon = styled.div<{ $type: string }>`
    ${tw`w-10 h-10 rounded-lg flex items-center justify-center text-lg`}
    background: ${props => {
        switch(props.$type) {
            case 'command': return 'rgba(0, 212, 255, 0.15)';
            case 'restart': return 'rgba(168, 85, 247, 0.15)';
            case 'backup': return 'rgba(0, 255, 136, 0.15)';
            case 'power': return 'rgba(255, 204, 0, 0.15)';
            default: return 'rgba(0, 212, 255, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$type) {
            case 'command': return '#00d4ff';
            case 'restart': return '#a855f7';
            case 'backup': return '#00ff88';
            case 'power': return '#ffcc00';
            default: return '#00d4ff';
        }
    }};
`;

const TaskDetails = styled.div``;

const TaskName = styled.h4`
    ${tw`text-sm font-semibold`}
    color: #ffffff;
`;

const TaskSchedule = styled.span`
    ${tw`text-xs flex items-center gap-1`}
    color: #5a7a9a;
`;

const TaskActions = styled.div`
    ${tw`flex gap-2`}
`;

const IconButton = styled.button<{ $variant?: 'primary' | 'danger' | 'success' }>`
    ${tw`w-8 h-8 rounded-lg flex items-center justify-center`}
    background: ${props => {
        switch(props.$variant) {
            case 'danger': return 'rgba(255, 51, 102, 0.15)';
            case 'success': return 'rgba(0, 255, 136, 0.15)';
            case 'primary': return 'rgba(0, 212, 255, 0.15)';
            default: return 'rgba(26, 48, 80, 0.5)';
        }
    }};
    border: 1px solid ${props => {
        switch(props.$variant) {
            case 'danger': return 'rgba(255, 51, 102, 0.5)';
            case 'success': return 'rgba(0, 255, 136, 0.5)';
            case 'primary': return 'rgba(0, 212, 255, 0.5)';
            default: return 'rgba(26, 48, 80, 0.8)';
        }
    }};
    color: ${props => {
        switch(props.$variant) {
            case 'danger': return '#ff3366';
            case 'success': return '#00ff88';
            case 'primary': return '#00d4ff';
            default: return '#a0b4c8';
        }
    }};
    cursor: pointer;
    transition: all 0.3s ease;

    &:hover {
        transform: scale(1.1);
    }
`;

const TaskCommand = styled.div`
    ${tw`p-3 rounded-lg text-xs font-mono mb-3`}
    background: rgba(5, 10, 20, 0.8);
    border: 1px solid rgba(26, 48, 80, 0.5);
    color: #00d4ff;
`;

const TaskMeta = styled.div`
    ${tw`flex items-center gap-4 text-xs`}
    color: #5a7a9a;
`;

const TaskStatus = styled.span<{ $status: string }>`
    ${tw`px-2 py-0.5 rounded flex items-center gap-1`}
    background: ${props => {
        switch(props.$status) {
            case 'success': return 'rgba(0, 255, 136, 0.15)';
            case 'failed': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$status) {
            case 'success': return '#00ff88';
            case 'failed': return '#ff3366';
            default: return '#5a7a9a';
        }
    }};
`;

const Modal = styled.div<{ $visible: boolean }>`
    ${tw`fixed inset-0 flex items-center justify-center z-50`}
    display: ${props => props.$visible ? 'flex' : 'none'};
    background: rgba(5, 10, 20, 0.8);
    backdrop-filter: blur(4px);
`;

const ModalContent = styled.div`
    ${tw`w-full max-w-lg rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.95) 0%, rgba(10, 22, 40, 0.98) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const ModalHeader = styled.div`
    ${tw`px-6 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const ModalTitle = styled.h3`
    ${tw`text-lg font-bold`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const ModalClose = styled.button`
    ${tw`w-8 h-8 rounded-lg flex items-center justify-center text-lg`}
    background: rgba(255, 51, 102, 0.15);
    border: 1px solid rgba(255, 51, 102, 0.5);
    color: #ff3366;
    cursor: pointer;
    transition: all 0.3s ease;

    &:hover {
        background: rgba(255, 51, 102, 0.3);
    }
`;

const ModalBody = styled.div`
    ${tw`p-6`}
`;

const FormGroup = styled.div`
    ${tw`mb-4`}
`;

const FormLabel = styled.label`
    ${tw`block text-sm font-medium mb-2`}
    color: #a0b4c8;
`;

const FormInput = styled.input`
    ${tw`w-full px-4 py-3 rounded-lg text-sm`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #ffffff;
    font-family: 'Inter', sans-serif;
    transition: all 0.3s ease;

    &:focus {
        outline: none;
        border-color: #00d4ff;
        box-shadow: 0 0 20px rgba(0, 212, 255, 0.2);
    }

    &::placeholder {
        color: #5a7a9a;
    }
`;

const FormSelect = styled.select`
    ${tw`w-full px-4 py-3 rounded-lg text-sm`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #ffffff;
    font-family: 'Inter', sans-serif;
    transition: all 0.3s ease;

    &:focus {
        outline: none;
        border-color: #00d4ff;
        box-shadow: 0 0 20px rgba(0, 212, 255, 0.2);
    }

    option {
        background: #0a1628;
        color: #ffffff;
    }
`;

const CronHelper = styled.div`
    ${tw`grid grid-cols-5 gap-2 mt-2`}
`;

const CronField = styled.div`
    ${tw`text-center`}
`;

const CronInput = styled.input`
    ${tw`w-full px-2 py-2 rounded-lg text-sm text-center`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #ffffff;
    font-family: 'JetBrains Mono', monospace;

    &:focus {
        outline: none;
        border-color: #00d4ff;
    }
`;

const CronLabel = styled.span`
    ${tw`text-xs block mt-1`}
    color: #5a7a9a;
`;

const ModalFooter = styled.div`
    ${tw`px-6 py-4 flex gap-3`}
    background: rgba(15, 31, 61, 0.3);
    border-top: 1px solid rgba(26, 48, 80, 0.8);
`;

const SecondaryButton = styled.button`
    ${tw`flex-1 py-2.5 px-4 rounded-lg font-semibold text-sm`}
    background: rgba(26, 48, 80, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #a0b4c8;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #00d4ff;
        color: #00d4ff;
    }
`;

const SubmitButton = styled.button`
    ${tw`flex-1 py-2.5 px-4 rounded-lg font-semibold text-sm flex items-center justify-center gap-2`}
    background: linear-gradient(135deg, #00d4ff 0%, #a855f7 100%);
    border: none;
    color: #ffffff;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
    }
`;

// Mock data
const mockTasks: ScheduledTask[] = [
    {
        id: '1',
        name: 'Daily Server Restart',
        command: 'restart',
        schedule: '0 4 * * *',
        nextRun: '2024-01-20 04:00',
        lastRun: '2024-01-19 04:00',
        lastStatus: 'success',
        enabled: true,
        type: 'restart'
    },
    {
        id: '2',
        name: 'Hourly Save World',
        command: 'save-all',
        schedule: '0 * * * *',
        nextRun: '2024-01-19 16:00',
        lastRun: '2024-01-19 15:00',
        lastStatus: 'success',
        enabled: true,
        type: 'command'
    },
    {
        id: '3',
        name: 'Weekly Backup',
        command: 'backup',
        schedule: '0 3 * * 0',
        nextRun: '2024-01-21 03:00',
        lastRun: '2024-01-14 03:00',
        lastStatus: 'success',
        enabled: true,
        type: 'backup'
    },
    {
        id: '4',
        name: 'Broadcast Message',
        command: 'say Server restarting in 5 minutes!',
        schedule: '55 3 * * *',
        nextRun: '2024-01-20 03:55',
        lastRun: '2024-01-19 03:55',
        lastStatus: 'success',
        enabled: false,
        type: 'command'
    }
];

const SchedulerContainer: React.FC = () => {
    const [tasks, setTasks] = useState<ScheduledTask[]>(mockTasks);
    const [showModal, setShowModal] = useState(false);

    const toggleTask = (id: string) => {
        setTasks(prev => prev.map(task =>
            task.id === id ? { ...task, enabled: !task.enabled } : task
        ));
    };

    return (
        <Container>
            <PageHeader>
                <HeaderContent>
                    <HeaderText>
                        <PageTitle>Advanced Scheduler</PageTitle>
                        <PageSubtitle>Schedule commands, restarts, and automated tasks</PageSubtitle>
                    </HeaderText>
                    <PrimaryButton onClick={() => setShowModal(true)}>
                        <HiOutlinePlus /> New Task
                    </PrimaryButton>
                </HeaderContent>
            </PageHeader>

            <QuickActionsGrid>
                <QuickAction $color="#00d4ff">
                    <QuickActionIcon $color="#00d4ff">
                        <HiOutlineTerminal />
                    </QuickActionIcon>
                    <QuickActionLabel>Run Command</QuickActionLabel>
                    <QuickActionDesc>Execute a command now</QuickActionDesc>
                </QuickAction>
                <QuickAction $color="#a855f7">
                    <QuickActionIcon $color="#a855f7">
                        <HiOutlineRefresh />
                    </QuickActionIcon>
                    <QuickActionLabel>Quick Restart</QuickActionLabel>
                    <QuickActionDesc>Schedule restart in 5 min</QuickActionDesc>
                </QuickAction>
                <QuickAction $color="#00ff88">
                    <QuickActionIcon $color="#00ff88">
                        <HiOutlineCalendar />
                    </QuickActionIcon>
                    <QuickActionLabel>Daily Restart</QuickActionLabel>
                    <QuickActionDesc>Add daily restart task</QuickActionDesc>
                </QuickAction>
                <QuickAction $color="#ffcc00">
                    <QuickActionIcon $color="#ffcc00">
                        <HiOutlineClock />
                    </QuickActionIcon>
                    <QuickActionLabel>Countdown</QuickActionLabel>
                    <QuickActionDesc>Restart with countdown</QuickActionDesc>
                </QuickAction>
            </QuickActionsGrid>

            <Card>
                <CardHeader>
                    <CardTitle>
                        <HiOutlineClock /> Scheduled Tasks
                    </CardTitle>
                </CardHeader>
                <TaskList>
                    {tasks.map(task => (
                        <TaskItem key={task.id} $enabled={task.enabled}>
                            <TaskHeader>
                                <TaskInfo>
                                    <TaskIcon $type={task.type}>
                                        {task.type === 'command' && <HiOutlineTerminal />}
                                        {task.type === 'restart' && <HiOutlineRefresh />}
                                        {task.type === 'backup' && <HiOutlineCalendar />}
                                        {task.type === 'power' && <HiOutlinePlay />}
                                    </TaskIcon>
                                    <TaskDetails>
                                        <TaskName>{task.name}</TaskName>
                                        <TaskSchedule>
                                            <HiOutlineClock /> {task.schedule} (cron)
                                        </TaskSchedule>
                                    </TaskDetails>
                                </TaskInfo>
                                <TaskActions>
                                    <IconButton title="Edit">
                                        <HiOutlinePencil />
                                    </IconButton>
                                    <IconButton
                                        $variant={task.enabled ? 'success' : undefined}
                                        onClick={() => toggleTask(task.id)}
                                        title={task.enabled ? 'Disable' : 'Enable'}
                                    >
                                        {task.enabled ? <HiOutlinePause /> : <HiOutlinePlay />}
                                    </IconButton>
                                    <IconButton $variant="danger" title="Delete">
                                        <HiOutlineTrash />
                                    </IconButton>
                                </TaskActions>
                            </TaskHeader>
                            <TaskCommand>{task.command}</TaskCommand>
                            <TaskMeta>
                                <span>Next: {task.nextRun}</span>
                                <span>Last: {task.lastRun}</span>
                                <TaskStatus $status={task.lastStatus}>
                                    {task.lastStatus === 'success' && '✓'}
                                    {task.lastStatus === 'failed' && '✕'}
                                    {task.lastStatus}
                                </TaskStatus>
                            </TaskMeta>
                        </TaskItem>
                    ))}
                </TaskList>
            </Card>

            {/* Create Task Modal */}
            <Modal $visible={showModal} onClick={() => setShowModal(false)}>
                <ModalContent onClick={e => e.stopPropagation()}>
                    <ModalHeader>
                        <ModalTitle>Create Scheduled Task</ModalTitle>
                        <ModalClose onClick={() => setShowModal(false)}>×</ModalClose>
                    </ModalHeader>
                    <ModalBody>
                        <FormGroup>
                            <FormLabel>Task Name</FormLabel>
                            <FormInput type="text" placeholder="Enter task name..." />
                        </FormGroup>
                        <FormGroup>
                            <FormLabel>Task Type</FormLabel>
                            <FormSelect>
                                <option value="command">Console Command</option>
                                <option value="restart">Server Restart</option>
                                <option value="backup">Create Backup</option>
                                <option value="power">Power Action</option>
                            </FormSelect>
                        </FormGroup>
                        <FormGroup>
                            <FormLabel>Command</FormLabel>
                            <FormInput type="text" placeholder="say Hello World" />
                        </FormGroup>
                        <FormGroup>
                            <FormLabel>Schedule (Cron Expression)</FormLabel>
                            <CronHelper>
                                <CronField>
                                    <CronInput placeholder="*" defaultValue="0" />
                                    <CronLabel>Min</CronLabel>
                                </CronField>
                                <CronField>
                                    <CronInput placeholder="*" defaultValue="4" />
                                    <CronLabel>Hour</CronLabel>
                                </CronField>
                                <CronField>
                                    <CronInput placeholder="*" defaultValue="*" />
                                    <CronLabel>Day</CronLabel>
                                </CronField>
                                <CronField>
                                    <CronInput placeholder="*" defaultValue="*" />
                                    <CronLabel>Month</CronLabel>
                                </CronField>
                                <CronField>
                                    <CronInput placeholder="*" defaultValue="*" />
                                    <CronLabel>Week</CronLabel>
                                </CronField>
                            </CronHelper>
                        </FormGroup>
                    </ModalBody>
                    <ModalFooter>
                        <SecondaryButton onClick={() => setShowModal(false)}>
                            Cancel
                        </SecondaryButton>
                        <SubmitButton>
                            <HiOutlinePlus /> Create Task
                        </SubmitButton>
                    </ModalFooter>
                </ModalContent>
            </Modal>
        </Container>
    );
};

export default SchedulerContainer;
