import React, { useState } from 'react';
import tw from 'twin.macro';
import styled, { keyframes } from 'styled-components';
import { HiOutlineExclamationCircle, HiOutlineCheckCircle, HiOutlineBell, HiOutlineCog, HiOutlineRefresh, HiOutlineChartBar, HiOutlineClock, HiOutlineServer, HiOutlineChip } from 'react-icons/hi';

interface CrashEvent {
    id: string;
    timestamp: string;
    reason: string;
    exitCode: number;
    autoRestarted: boolean;
    logSnippet: string;
}

interface HealthMetric {
    name: string;
    value: number;
    max: number;
    unit: string;
    status: 'good' | 'warning' | 'critical';
}

interface AlertRule {
    id: string;
    name: string;
    condition: string;
    action: string;
    enabled: boolean;
}

const pulse = keyframes`
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
`;

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #ff3366, #ffcc00, #ff3366);
    }
`;

const HeaderContent = styled.div`
    ${tw`flex items-center justify-between`}
`;

const HeaderText = styled.div``;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const StatusBadge = styled.div<{ $status: 'healthy' | 'warning' | 'critical' }>`
    ${tw`px-4 py-2 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: ${props => {
        switch(props.$status) {
            case 'healthy': return 'rgba(0, 255, 136, 0.15)';
            case 'warning': return 'rgba(255, 204, 0, 0.15)';
            case 'critical': return 'rgba(255, 51, 102, 0.15)';
        }
    }};
    border: 1px solid ${props => {
        switch(props.$status) {
            case 'healthy': return '#00ff88';
            case 'warning': return '#ffcc00';
            case 'critical': return '#ff3366';
        }
    }};
    color: ${props => {
        switch(props.$status) {
            case 'healthy': return '#00ff88';
            case 'warning': return '#ffcc00';
            case 'critical': return '#ff3366';
        }
    }};
    font-family: 'Rajdhani', sans-serif;

    span {
        ${tw`w-2 h-2 rounded-full`}
        background: currentColor;
        animation: ${pulse} 2s ease-in-out infinite;
    }
`;

const HealthGrid = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(4, 1fr);

    @media (max-width: 1000px) {
        grid-template-columns: repeat(2, 1fr);
    }

    @media (max-width: 600px) {
        grid-template-columns: 1fr;
    }
`;

const HealthCard = styled.div<{ $status: string }>`
    ${tw`p-4 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 3px;
        height: 100%;
        background: ${props => {
            switch(props.$status) {
                case 'good': return '#00ff88';
                case 'warning': return '#ffcc00';
                case 'critical': return '#ff3366';
                default: return '#00d4ff';
            }
        }};
    }
`;

const HealthLabel = styled.span`
    ${tw`text-xs uppercase tracking-wide block mb-2`}
    color: #5a7a9a;
    font-family: 'Rajdhani', sans-serif;
`;

const HealthValue = styled.div`
    ${tw`flex items-baseline gap-1`}
`;

const HealthNumber = styled.span<{ $status: string }>`
    ${tw`text-2xl font-bold`}
    color: ${props => {
        switch(props.$status) {
            case 'good': return '#00ff88';
            case 'warning': return '#ffcc00';
            case 'critical': return '#ff3366';
            default: return '#ffffff';
        }
    }};
    font-family: 'Rajdhani', sans-serif;
`;

const HealthUnit = styled.span`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const HealthBar = styled.div`
    ${tw`h-1 rounded-full mt-3 overflow-hidden`}
    background: rgba(15, 31, 61, 0.8);
`;

const HealthFill = styled.div<{ $percentage: number; $status: string }>`
    ${tw`h-full rounded-full`}
    width: ${props => Math.min(props.$percentage, 100)}%;
    background: ${props => {
        switch(props.$status) {
            case 'good': return '#00ff88';
            case 'warning': return '#ffcc00';
            case 'critical': return '#ff3366';
            default: return '#00d4ff';
        }
    }};
    transition: width 0.5s ease;
`;

const ContentGrid = styled.div`
    ${tw`grid gap-6`}
    grid-template-columns: 1fr 380px;

    @media (max-width: 1200px) {
        grid-template-columns: 1fr;
    }
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const CardBody = styled.div`
    ${tw`p-0`}
`;

const CrashList = styled.div`
    ${tw`max-h-96 overflow-y-auto`}
`;

const CrashItem = styled.div`
    ${tw`p-4`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.5);

    &:last-child {
        border-bottom: none;
    }
`;

const CrashHeader = styled.div`
    ${tw`flex items-start justify-between mb-2`}
`;

const CrashInfo = styled.div`
    ${tw`flex items-center gap-3`}
`;

const CrashIcon = styled.div`
    ${tw`w-10 h-10 rounded-lg flex items-center justify-center text-lg`}
    background: rgba(255, 51, 102, 0.15);
    color: #ff3366;
`;

const CrashDetails = styled.div``;

const CrashReason = styled.h4`
    ${tw`text-sm font-semibold`}
    color: #ffffff;
`;

const CrashMeta = styled.div`
    ${tw`flex items-center gap-3 text-xs mt-1`}
    color: #5a7a9a;
`;

const CrashBadge = styled.span<{ $restarted: boolean }>`
    ${tw`px-2 py-0.5 rounded text-xs`}
    background: ${props => props.$restarted ? 'rgba(0, 255, 136, 0.15)' : 'rgba(255, 204, 0, 0.15)'};
    color: ${props => props.$restarted ? '#00ff88' : '#ffcc00'};
`;

const CrashLog = styled.pre`
    ${tw`mt-3 p-3 rounded-lg text-xs overflow-x-auto`}
    background: rgba(5, 10, 20, 0.8);
    border: 1px solid rgba(26, 48, 80, 0.5);
    color: #ff3366;
    font-family: 'JetBrains Mono', monospace;
    white-space: pre-wrap;
    word-break: break-all;
`;

const AlertList = styled.div``;

const AlertItem = styled.div`
    ${tw`p-4 flex items-center justify-between`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.5);

    &:last-child {
        border-bottom: none;
    }
`;

const AlertInfo = styled.div``;

const AlertName = styled.h4`
    ${tw`text-sm font-semibold mb-1`}
    color: #ffffff;
`;

const AlertCondition = styled.span`
    ${tw`text-xs block`}
    color: #5a7a9a;
`;

const AlertToggle = styled.label`
    ${tw`relative inline-block w-12 h-6 cursor-pointer`}

    input {
        ${tw`opacity-0 w-0 h-0`}
    }

    span {
        ${tw`absolute inset-0 rounded-full transition-colors`}
        background: rgba(26, 48, 80, 0.8);

        &::before {
            content: '';
            ${tw`absolute w-5 h-5 rounded-full transition-transform`}
            background: #ffffff;
            top: 2px;
            left: 2px;
        }
    }

    input:checked + span {
        background: linear-gradient(135deg, #00ff88 0%, #00d4ff 100%);
    }

    input:checked + span::before {
        transform: translateX(24px);
    }
`;

const AddRuleButton = styled.button`
    ${tw`w-full py-3 px-4 rounded-lg font-semibold text-sm flex items-center justify-center gap-2`}
    background: rgba(26, 48, 80, 0.3);
    border: 1px dashed rgba(26, 48, 80, 0.8);
    color: #5a7a9a;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #00d4ff;
        color: #00d4ff;
    }
`;

const UptimeCard = styled.div`
    ${tw`p-4 rounded-xl mb-4`}
    background: linear-gradient(145deg, rgba(0, 255, 136, 0.1) 0%, rgba(0, 212, 255, 0.05) 100%);
    border: 1px solid rgba(0, 255, 136, 0.3);
`;

const UptimeLabel = styled.span`
    ${tw`text-xs uppercase tracking-wide block mb-1`}
    color: #00ff88;
    font-family: 'Rajdhani', sans-serif;
`;

const UptimeValue = styled.span`
    ${tw`text-3xl font-bold`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const UptimeSubtext = styled.span`
    ${tw`text-sm ml-2`}
    color: #5a7a9a;
`;

// Mock data
const mockHealthMetrics: HealthMetric[] = [
    { name: 'CPU Usage', value: 45, max: 100, unit: '%', status: 'good' },
    { name: 'Memory', value: 6.2, max: 8, unit: 'GB', status: 'warning' },
    { name: 'Disk I/O', value: 12, max: 100, unit: 'MB/s', status: 'good' },
    { name: 'Network', value: 85, max: 100, unit: 'Mbps', status: 'good' },
];

const mockCrashEvents: CrashEvent[] = [
    {
        id: '1',
        timestamp: '2024-01-19 14:32:15',
        reason: 'Out of memory',
        exitCode: 137,
        autoRestarted: true,
        logSnippet: 'java.lang.OutOfMemoryError: Java heap space\n    at java.util.Arrays.copyOf(Arrays.java:3210)\n    at java.util.ArrayList.grow(ArrayList.java:265)'
    },
    {
        id: '2',
        timestamp: '2024-01-18 09:15:42',
        reason: 'Plugin conflict',
        exitCode: 1,
        autoRestarted: true,
        logSnippet: 'Error occurred while enabling PluginX v2.0\nCaused by: java.lang.NoClassDefFoundError: net/md_5/bungee/api/ChatColor'
    },
    {
        id: '3',
        timestamp: '2024-01-17 22:45:00',
        reason: 'Unexpected shutdown',
        exitCode: 143,
        autoRestarted: false,
        logSnippet: 'Server received SIGTERM signal\nGraceful shutdown initiated...'
    }
];

const mockAlertRules: AlertRule[] = [
    { id: '1', name: 'High CPU Alert', condition: 'CPU > 90% for 5 minutes', action: 'Discord webhook + Email', enabled: true },
    { id: '2', name: 'Memory Warning', condition: 'Memory > 85%', action: 'Discord webhook', enabled: true },
    { id: '3', name: 'Crash Detection', condition: 'Server crashes', action: 'Auto-restart + Email', enabled: true },
    { id: '4', name: 'Player Count Drop', condition: 'Players drop by 50%', action: 'Discord webhook', enabled: false },
];

const CrashMonitorContainer: React.FC = () => {
    const [alertRules, setAlertRules] = useState<AlertRule[]>(mockAlertRules);
    const [expandedCrash, setExpandedCrash] = useState<string | null>(null);

    const toggleAlert = (id: string) => {
        setAlertRules(prev => prev.map(rule =>
            rule.id === id ? { ...rule, enabled: !rule.enabled } : rule
        ));
    };

    const overallStatus = mockHealthMetrics.some(m => m.status === 'critical')
        ? 'critical'
        : mockHealthMetrics.some(m => m.status === 'warning')
            ? 'warning'
            : 'healthy';

    return (
        <Container>
            <PageHeader>
                <HeaderContent>
                    <HeaderText>
                        <PageTitle>Crash & Health Monitor</PageTitle>
                        <PageSubtitle>Monitor server health and get notified about crashes</PageSubtitle>
                    </HeaderText>
                    <StatusBadge $status={overallStatus}>
                        <span />
                        {overallStatus === 'healthy' && <><HiOutlineCheckCircle /> Server Healthy</>}
                        {overallStatus === 'warning' && <><HiOutlineBell /> Warning</>}
                        {overallStatus === 'critical' && <><HiOutlineExclamationCircle /> Critical</>}
                    </StatusBadge>
                </HeaderContent>
            </PageHeader>

            <HealthGrid>
                {mockHealthMetrics.map(metric => (
                    <HealthCard key={metric.name} $status={metric.status}>
                        <HealthLabel>{metric.name}</HealthLabel>
                        <HealthValue>
                            <HealthNumber $status={metric.status}>{metric.value}</HealthNumber>
                            <HealthUnit>{metric.unit}</HealthUnit>
                        </HealthValue>
                        <HealthBar>
                            <HealthFill
                                $percentage={(metric.value / metric.max) * 100}
                                $status={metric.status}
                            />
                        </HealthBar>
                    </HealthCard>
                ))}
            </HealthGrid>

            <ContentGrid>
                <Card>
                    <CardHeader>
                        <CardTitle>
                            <HiOutlineExclamationCircle /> Recent Crash Events
                        </CardTitle>
                    </CardHeader>
                    <CardBody>
                        <CrashList>
                            {mockCrashEvents.map(crash => (
                                <CrashItem key={crash.id}>
                                    <CrashHeader>
                                        <CrashInfo>
                                            <CrashIcon>
                                                <HiOutlineExclamationCircle />
                                            </CrashIcon>
                                            <CrashDetails>
                                                <CrashReason>{crash.reason}</CrashReason>
                                                <CrashMeta>
                                                    <span><HiOutlineClock css={tw`inline`} /> {crash.timestamp}</span>
                                                    <span>Exit code: {crash.exitCode}</span>
                                                    <CrashBadge $restarted={crash.autoRestarted}>
                                                        {crash.autoRestarted ? 'Auto-restarted' : 'Manual restart needed'}
                                                    </CrashBadge>
                                                </CrashMeta>
                                            </CrashDetails>
                                        </CrashInfo>
                                    </CrashHeader>
                                    {expandedCrash === crash.id ? (
                                        <CrashLog>{crash.logSnippet}</CrashLog>
                                    ) : (
                                        <button
                                            css={tw`text-xs mt-2`}
                                            style={{ color: '#00d4ff', background: 'none', border: 'none', cursor: 'pointer' }}
                                            onClick={() => setExpandedCrash(crash.id)}
                                        >
                                            View log snippet →
                                        </button>
                                    )}
                                </CrashItem>
                            ))}
                        </CrashList>
                    </CardBody>
                </Card>

                <div css={tw`flex flex-col gap-4`}>
                    <UptimeCard>
                        <UptimeLabel>Current Uptime</UptimeLabel>
                        <UptimeValue>
                            99.8%
                            <UptimeSubtext>Last 30 days</UptimeSubtext>
                        </UptimeValue>
                    </UptimeCard>

                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineBell /> Alert Rules
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <AlertList>
                                {alertRules.map(rule => (
                                    <AlertItem key={rule.id}>
                                        <AlertInfo>
                                            <AlertName>{rule.name}</AlertName>
                                            <AlertCondition>{rule.condition}</AlertCondition>
                                        </AlertInfo>
                                        <AlertToggle>
                                            <input
                                                type="checkbox"
                                                checked={rule.enabled}
                                                onChange={() => toggleAlert(rule.id)}
                                            />
                                            <span />
                                        </AlertToggle>
                                    </AlertItem>
                                ))}
                            </AlertList>
                            <div css={tw`p-4`}>
                                <AddRuleButton>
                                    <HiOutlineCog /> Add Alert Rule
                                </AddRuleButton>
                            </div>
                        </CardBody>
                    </Card>
                </div>
            </ContentGrid>
        </Container>
    );
};

export default CrashMonitorContainer;
