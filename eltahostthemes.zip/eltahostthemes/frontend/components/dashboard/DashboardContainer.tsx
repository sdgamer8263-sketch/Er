import React, { useEffect, useState } from 'react';
import { useStoreState } from 'easy-peasy';
import tw from 'twin.macro';
import styled from 'styled-components';
import StatsCard from './StatsCard';
import ServerCard from './ServerCard';
import { HiOutlineChip, HiOutlineServer, HiOutlineDatabase, HiOutlineCurrencyDollar } from 'react-icons/hi';

const DashboardWrapper = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const WelcomeHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #00d4ff, #a855f7, #00d4ff);
    }
`;

const WelcomeTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const WelcomeSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const StatsGrid = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(4, 1fr);

    @media (max-width: 1200px) {
        grid-template-columns: repeat(2, 1fr);
    }

    @media (max-width: 600px) {
        grid-template-columns: 1fr;
    }
`;

const SectionHeader = styled.div`
    ${tw`flex items-center justify-between mb-4`}
`;

const SectionTitle = styled.h2`
    ${tw`flex items-center gap-3 text-xl font-semibold uppercase tracking-wide`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const SectionIcon = styled.div`
    ${tw`w-9 h-9 rounded-lg flex items-center justify-center text-lg`}
    background: rgba(0, 212, 255, 0.15);
    border: 1px solid #00d4ff;
    color: #00d4ff;
`;

const ServerGrid = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(4, 1fr);

    @media (max-width: 1400px) {
        grid-template-columns: repeat(3, 1fr);
    }

    @media (max-width: 1000px) {
        grid-template-columns: repeat(2, 1fr);
    }

    @media (max-width: 600px) {
        grid-template-columns: 1fr;
    }
`;

const ColumnsLayout = styled.div`
    ${tw`grid gap-6`}
    grid-template-columns: 1fr 380px;

    @media (max-width: 1200px) {
        grid-template-columns: 1fr;
    }
`;

const MainColumn = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const SideColumn = styled.div`
    ${tw`flex flex-col gap-4`}
`;

const PortalCard = styled.div`
    ${tw`p-5 rounded-xl`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
    transition: all 0.3s ease;

    &:hover {
        border-color: rgba(42, 74, 106, 0.8);
        transform: translateY(-2px);
    }
`;

const PortalCardHeader = styled.div`
    ${tw`flex items-center justify-between mb-4`}
`;

const PortalCardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide`}
    color: #a0b4c8;
    font-family: 'Rajdhani', sans-serif;
`;

const PortalCardIcon = styled.div`
    ${tw`w-10 h-10 rounded-lg flex items-center justify-center text-xl`}
    background: rgba(0, 255, 136, 0.15);
    border: 1px solid #00ff88;
    color: #00ff88;
`;

const PortalCardValue = styled.div`
    ${tw`text-3xl font-bold`}
    color: #00ff88;
    font-family: 'Rajdhani', sans-serif;

    span {
        ${tw`text-lg`}
        color: #a0b4c8;
    }
`;

const ActivityCard = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const ActivityHeader = styled.div`
    ${tw`px-4 py-3 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const ActivityTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const ActivityList = styled.div`
    ${tw`max-h-72 overflow-y-auto`}
`;

const ActivityItem = styled.div`
    ${tw`flex items-start gap-3 p-4`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.5);
    transition: background 0.2s ease;

    &:hover {
        background: rgba(15, 31, 61, 0.5);
    }

    &:last-child {
        border-bottom: none;
    }
`;

const ActivityIcon = styled.div<{ $type: string }>`
    ${tw`w-8 h-8 rounded-lg flex items-center justify-center text-sm flex-shrink-0`}
    background: ${props => {
        switch(props.$type) {
            case 'success': return 'rgba(0, 255, 136, 0.15)';
            case 'warning': return 'rgba(255, 204, 0, 0.15)';
            case 'error': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(0, 212, 255, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$type) {
            case 'success': return '#00ff88';
            case 'warning': return '#ffcc00';
            case 'error': return '#ff3366';
            default: return '#00d4ff';
        }
    }};
`;

const ActivityContent = styled.div`
    ${tw`flex-1`}
`;

const ActivityText = styled.span`
    ${tw`text-sm block`}
    color: #ffffff;
`;

const ActivityTime = styled.span`
    ${tw`text-xs`}
    color: #5a7a9a;
`;

// Mock data - replace with real API calls
const mockServers = [
    { uuid: '1', name: 'Counter-Strike 2 Server', status: 'online' as const, game: 'CS2', ip: '192.168.1.30', port: 27015, players: { current: 8, max: 16 }, price: 20 },
    { uuid: '2', name: '7 Days to Die Server', status: 'offline' as const, game: '7D2D', ip: '192.168.1.31', port: 26900, players: { current: 0, max: 8 }, price: 14 },
    { uuid: '3', name: 'ARK: Survival Evolved', status: 'starting' as const, game: 'ARK', ip: '192.168.1.32', port: 27015, players: { current: 0, max: 70 }, price: 25 },
    { uuid: '4', name: 'FiveM Server', status: 'online' as const, game: 'FiveM', ip: '192.168.1.33', port: 30120, players: { current: 12, max: 84 }, price: 15 },
];

const mockActivity = [
    { id: 1, type: 'success', text: 'Premium Plugin Installed: AntiCheatPro', time: '5 minutes ago' },
    { id: 2, type: 'info', text: 'New FiveM Server Created', time: '2 hours ago' },
    { id: 3, type: 'success', text: 'Backup Created', time: 'Yesterday' },
    { id: 4, type: 'warning', text: 'server.properties edited', time: 'Yesterday' },
    { id: 5, type: 'error', text: 'Invoice Paid: Counter Strike 2 Server', time: '2 days ago' },
];

const DashboardContainer: React.FC = () => {
    const user = useStoreState((state: any) => state.user.data);
    const [stats, setStats] = useState({
        cpu: 42,
        memory: { used: 10.2, total: 16 },
        disk: { used: 210, total: 300 },
        income: 1250
    });

    return (
        <DashboardWrapper>
            {/* Welcome Header */}
            <WelcomeHeader>
                <WelcomeTitle>Welcome, {user?.username || 'Admin'}!</WelcomeTitle>
                <WelcomeSubtitle>Here's an overview of your gaming servers</WelcomeSubtitle>
            </WelcomeHeader>

            {/* Stats Grid */}
            <StatsGrid>
                <StatsCard
                    label="CPU Usage"
                    value={`${stats.cpu}%`}
                    icon={<HiOutlineChip />}
                    color="yellow"
                    progress={stats.cpu}
                />
                <StatsCard
                    label="RAM Usage"
                    value={`${stats.memory.used} GB`}
                    subtext={`/ ${stats.memory.total} GB`}
                    icon={<HiOutlineServer />}
                    color="green"
                    progress={(stats.memory.used / stats.memory.total) * 100}
                />
                <StatsCard
                    label="Disk Space"
                    value={`${stats.disk.used} GB`}
                    subtext={`/ ${stats.disk.total} GB`}
                    icon={<HiOutlineDatabase />}
                    color="purple"
                    progress={(stats.disk.used / stats.disk.total) * 100}
                />
                <StatsCard
                    label="Income"
                    value={`€${stats.income.toFixed(2)}`}
                    subtext="Last 30 Days: €1,250.00"
                    icon={<HiOutlineCurrencyDollar />}
                    color="cyan"
                />
            </StatsGrid>

            {/* Servers Section */}
            <div>
                <SectionHeader>
                    <SectionTitle>
                        <SectionIcon>
                            <HiOutlineServer />
                        </SectionIcon>
                        Your Servers
                    </SectionTitle>
                </SectionHeader>
                <ServerGrid>
                    {mockServers.map(server => (
                        <ServerCard key={server.uuid} {...server} />
                    ))}
                </ServerGrid>
            </div>

            {/* Portal & Activity */}
            <ColumnsLayout>
                <MainColumn>
                    <SectionHeader>
                        <SectionTitle>Client Portal</SectionTitle>
                    </SectionHeader>
                    <div css={tw`grid grid-cols-2 gap-4`}>
                        <PortalCard>
                            <PortalCardHeader>
                                <PortalCardTitle>Billing Overview</PortalCardTitle>
                                <PortalCardIcon>
                                    <HiOutlineCurrencyDollar />
                                </PortalCardIcon>
                            </PortalCardHeader>
                            <PortalCardValue>€750.00</PortalCardValue>
                            <p css={tw`text-sm mt-2`} style={{ color: '#5a7a9a' }}>5 Active Invoices</p>
                        </PortalCard>
                        <PortalCard>
                            <PortalCardHeader>
                                <PortalCardTitle>Store</PortalCardTitle>
                                <PortalCardIcon style={{ background: 'rgba(168, 85, 247, 0.15)', borderColor: '#a855f7', color: '#a855f7' }}>
                                    <HiOutlineDatabase />
                                </PortalCardIcon>
                            </PortalCardHeader>
                            <div css={tw`text-3xl font-bold`} style={{ color: '#a855f7', fontFamily: "'Rajdhani', sans-serif" }}>12 <span css={tw`text-lg`} style={{ color: '#a0b4c8' }}>Addons</span></div>
                        </PortalCard>
                    </div>
                </MainColumn>

                <SideColumn>
                    <ActivityCard>
                        <ActivityHeader>
                            <ActivityTitle>Recent Activity</ActivityTitle>
                        </ActivityHeader>
                        <ActivityList>
                            {mockActivity.map(item => (
                                <ActivityItem key={item.id}>
                                    <ActivityIcon $type={item.type}>
                                        {item.type === 'success' && '✓'}
                                        {item.type === 'warning' && '!'}
                                        {item.type === 'error' && '✕'}
                                        {item.type === 'info' && 'i'}
                                    </ActivityIcon>
                                    <ActivityContent>
                                        <ActivityText>{item.text}</ActivityText>
                                        <ActivityTime>{item.time}</ActivityTime>
                                    </ActivityContent>
                                </ActivityItem>
                            ))}
                        </ActivityList>
                    </ActivityCard>
                </SideColumn>
            </ColumnsLayout>
        </DashboardWrapper>
    );
};

export default DashboardContainer;
