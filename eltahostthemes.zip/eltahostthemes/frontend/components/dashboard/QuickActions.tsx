import React from 'react';
import { Link } from 'react-router-dom';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlinePlus, HiOutlineCog, HiOutlineSupport, HiOutlineDocumentText, HiOutlineCreditCard, HiOutlineShoppingCart } from 'react-icons/hi';

interface QuickAction {
    id: string;
    label: string;
    description: string;
    icon: React.ReactNode;
    href: string;
    color: 'cyan' | 'green' | 'purple' | 'yellow';
}

const ActionsContainer = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const ActionsHeader = styled.div`
    ${tw`px-4 py-3 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const ActionsTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const ActionsGrid = styled.div`
    ${tw`grid grid-cols-2 gap-3 p-4`}
`;

const ActionCard = styled(Link)<{ $color: string }>`
    ${tw`flex flex-col items-center gap-2 p-4 rounded-xl text-center`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.6);
    transition: all 0.3s ease;
    text-decoration: none;

    &:hover {
        transform: translateY(-2px);
        border-color: ${props => {
            switch(props.$color) {
                case 'cyan': return '#00d4ff';
                case 'green': return '#00ff88';
                case 'purple': return '#a855f7';
                case 'yellow': return '#ffcc00';
                default: return '#00d4ff';
            }
        }};
        box-shadow: 0 4px 20px ${props => {
            switch(props.$color) {
                case 'cyan': return 'rgba(0, 212, 255, 0.2)';
                case 'green': return 'rgba(0, 255, 136, 0.2)';
                case 'purple': return 'rgba(168, 85, 247, 0.2)';
                case 'yellow': return 'rgba(255, 204, 0, 0.2)';
                default: return 'rgba(0, 212, 255, 0.2)';
            }
        }};
    }
`;

const ActionIcon = styled.div<{ $color: string }>`
    ${tw`w-12 h-12 rounded-lg flex items-center justify-center text-2xl`}
    background: ${props => {
        switch(props.$color) {
            case 'cyan': return 'rgba(0, 212, 255, 0.15)';
            case 'green': return 'rgba(0, 255, 136, 0.15)';
            case 'purple': return 'rgba(168, 85, 247, 0.15)';
            case 'yellow': return 'rgba(255, 204, 0, 0.15)';
            default: return 'rgba(0, 212, 255, 0.15)';
        }
    }};
    border: 1px solid ${props => {
        switch(props.$color) {
            case 'cyan': return '#00d4ff';
            case 'green': return '#00ff88';
            case 'purple': return '#a855f7';
            case 'yellow': return '#ffcc00';
            default: return '#00d4ff';
        }
    }};
    color: ${props => {
        switch(props.$color) {
            case 'cyan': return '#00d4ff';
            case 'green': return '#00ff88';
            case 'purple': return '#a855f7';
            case 'yellow': return '#ffcc00';
            default: return '#00d4ff';
        }
    }};
`;

const ActionLabel = styled.span`
    ${tw`text-sm font-semibold`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const ActionDescription = styled.span`
    ${tw`text-xs`}
    color: #5a7a9a;
`;

const defaultActions: QuickAction[] = [
    {
        id: 'new-server',
        label: 'New Server',
        description: 'Create a server',
        icon: <HiOutlinePlus />,
        href: '/store',
        color: 'green'
    },
    {
        id: 'settings',
        label: 'Settings',
        description: 'Account settings',
        icon: <HiOutlineCog />,
        href: '/account',
        color: 'cyan'
    },
    {
        id: 'billing',
        label: 'Billing',
        description: 'Manage invoices',
        icon: <HiOutlineCreditCard />,
        href: '/billing',
        color: 'purple'
    },
    {
        id: 'store',
        label: 'Store',
        description: 'Browse addons',
        icon: <HiOutlineShoppingCart />,
        href: '/store/addons',
        color: 'yellow'
    },
    {
        id: 'support',
        label: 'Support',
        description: 'Get help',
        icon: <HiOutlineSupport />,
        href: '/support',
        color: 'cyan'
    },
    {
        id: 'docs',
        label: 'Documentation',
        description: 'Read guides',
        icon: <HiOutlineDocumentText />,
        href: '/docs',
        color: 'green'
    }
];

interface QuickActionsProps {
    actions?: QuickAction[];
}

const QuickActions: React.FC<QuickActionsProps> = ({ actions = defaultActions }) => {
    return (
        <ActionsContainer>
            <ActionsHeader>
                <ActionsTitle>Quick Actions</ActionsTitle>
            </ActionsHeader>
            <ActionsGrid>
                {actions.map(action => (
                    <ActionCard key={action.id} to={action.href} $color={action.color}>
                        <ActionIcon $color={action.color}>
                            {action.icon}
                        </ActionIcon>
                        <ActionLabel>{action.label}</ActionLabel>
                        <ActionDescription>{action.description}</ActionDescription>
                    </ActionCard>
                ))}
            </ActionsGrid>
        </ActionsContainer>
    );
};

export default QuickActions;
