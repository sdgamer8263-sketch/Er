import React, { useEffect, useRef } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';

interface DataPoint {
    timestamp: number;
    value: number;
}

interface ResourceGraphProps {
    title: string;
    data: DataPoint[];
    color: 'cyan' | 'green' | 'yellow' | 'purple';
    unit?: string;
    maxValue?: number;
}

const GraphContainer = styled.div`
    ${tw`rounded-xl p-4`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const GraphHeader = styled.div`
    ${tw`flex items-center justify-between mb-4`}
`;

const GraphTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide`}
    color: #a0b4c8;
    font-family: 'Rajdhani', sans-serif;
`;

const CurrentValue = styled.span<{ $color: string }>`
    ${tw`text-lg font-bold`}
    color: ${props => {
        switch(props.$color) {
            case 'cyan': return '#00d4ff';
            case 'green': return '#00ff88';
            case 'yellow': return '#ffcc00';
            case 'purple': return '#a855f7';
            default: return '#00d4ff';
        }
    }};
    font-family: 'Rajdhani', sans-serif;
`;

const CanvasWrapper = styled.div`
    ${tw`relative w-full`}
    height: 120px;
`;

const Canvas = styled.canvas`
    ${tw`w-full h-full`}
`;

const GridOverlay = styled.div`
    ${tw`absolute inset-0 pointer-events-none`}
    background-image:
        linear-gradient(to right, rgba(26, 48, 80, 0.3) 1px, transparent 1px),
        linear-gradient(to bottom, rgba(26, 48, 80, 0.3) 1px, transparent 1px);
    background-size: 20% 25%;
`;

const ResourceGraph: React.FC<ResourceGraphProps> = ({
    title,
    data,
    color,
    unit = '%',
    maxValue = 100
}) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    const getColor = (colorName: string): string => {
        switch(colorName) {
            case 'cyan': return '#00d4ff';
            case 'green': return '#00ff88';
            case 'yellow': return '#ffcc00';
            case 'purple': return '#a855f7';
            default: return '#00d4ff';
        }
    };

    const getGlowColor = (colorName: string): string => {
        switch(colorName) {
            case 'cyan': return 'rgba(0, 212, 255, 0.3)';
            case 'green': return 'rgba(0, 255, 136, 0.3)';
            case 'yellow': return 'rgba(255, 204, 0, 0.3)';
            case 'purple': return 'rgba(168, 85, 247, 0.3)';
            default: return 'rgba(0, 212, 255, 0.3)';
        }
    };

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas || data.length === 0) return;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        // Set canvas size
        const rect = canvas.getBoundingClientRect();
        canvas.width = rect.width * window.devicePixelRatio;
        canvas.height = rect.height * window.devicePixelRatio;
        ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

        const width = rect.width;
        const height = rect.height;
        const padding = 10;

        // Clear canvas
        ctx.clearRect(0, 0, width, height);

        // Calculate points
        const points = data.map((point, index) => ({
            x: padding + (index / (data.length - 1)) * (width - padding * 2),
            y: height - padding - (point.value / maxValue) * (height - padding * 2)
        }));

        // Draw gradient fill
        const gradient = ctx.createLinearGradient(0, 0, 0, height);
        gradient.addColorStop(0, getGlowColor(color));
        gradient.addColorStop(1, 'transparent');

        ctx.beginPath();
        ctx.moveTo(points[0].x, height - padding);
        points.forEach(point => ctx.lineTo(point.x, point.y));
        ctx.lineTo(points[points.length - 1].x, height - padding);
        ctx.closePath();
        ctx.fillStyle = gradient;
        ctx.fill();

        // Draw line with glow
        ctx.shadowColor = getColor(color);
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);

        // Smooth curve through points
        for (let i = 1; i < points.length - 1; i++) {
            const xc = (points[i].x + points[i + 1].x) / 2;
            const yc = (points[i].y + points[i + 1].y) / 2;
            ctx.quadraticCurveTo(points[i].x, points[i].y, xc, yc);
        }
        ctx.lineTo(points[points.length - 1].x, points[points.length - 1].y);

        ctx.strokeStyle = getColor(color);
        ctx.lineWidth = 2;
        ctx.stroke();

        // Draw end point
        const lastPoint = points[points.length - 1];
        ctx.beginPath();
        ctx.arc(lastPoint.x, lastPoint.y, 4, 0, Math.PI * 2);
        ctx.fillStyle = getColor(color);
        ctx.fill();

        ctx.shadowBlur = 0;

    }, [data, color, maxValue]);

    const currentValue = data.length > 0 ? data[data.length - 1].value : 0;

    return (
        <GraphContainer>
            <GraphHeader>
                <GraphTitle>{title}</GraphTitle>
                <CurrentValue $color={color}>
                    {currentValue.toFixed(1)}{unit}
                </CurrentValue>
            </GraphHeader>
            <CanvasWrapper>
                <GridOverlay />
                <Canvas ref={canvasRef} />
            </CanvasWrapper>
        </GraphContainer>
    );
};

export default ResourceGraph;
