import React from 'react';
import { Link } from 'react-router-dom';
import tw from 'twin.macro';
import styled, { keyframes } from 'styled-components';

type ServerStatus = 'online' | 'offline' | 'starting' | 'stopping';

interface ServerCardProps {
    uuid: string;
    name: string;
    status: ServerStatus;
    game?: string;
    image?: string;
    ip: string;
    port: number;
    players?: { current: number; max: number };
    cpu?: number;
    memory?: { current: number; max: number };
    price?: number;
}

const pulse = keyframes`
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
`;

const CardContainer = styled(Link)<{ $status: ServerStatus }>`
    ${tw`block relative overflow-hidden rounded-xl cursor-pointer`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
    transition: all 0.3s ease;
    text-decoration: none;

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: ${props => {
            switch(props.$status) {
                case 'online': return '#00ff88';
                case 'offline': return '#ff3366';
                case 'starting': return '#ffcc00';
                case 'stopping': return '#ff6b00';
                default: return '#5a7a9a';
            }
        }};
        transition: all 0.3s ease;
    }

    &:hover {
        border-color: #00d4ff;
        transform: translateY(-4px);
        box-shadow: 0 8px 32px rgba(0, 212, 255, 0.15);
    }

    &:hover::before {
        box-shadow: 0 0 20px ${props => {
            switch(props.$status) {
                case 'online': return 'rgba(0, 255, 136, 0.6)';
                case 'offline': return 'rgba(255, 51, 102, 0.6)';
                case 'starting': return 'rgba(255, 204, 0, 0.6)';
                case 'stopping': return 'rgba(255, 107, 0, 0.6)';
                default: return 'rgba(90, 122, 154, 0.6)';
            }
        }};
    }
`;

const ImageSection = styled.div`
    ${tw`relative h-28 overflow-hidden`}
    background: rgba(15, 31, 61, 0.5);
`;

const ServerImage = styled.img`
    ${tw`w-full h-full object-cover`}
    transition: transform 0.5s ease;

    ${CardContainer}:hover & {
        transform: scale(1.05);
    }
`;

const ImageOverlay = styled.div`
    ${tw`absolute inset-0`}
    background: linear-gradient(180deg, transparent 0%, rgba(5, 10, 20, 0.9) 100%);
`;

const GameBadge = styled.span`
    ${tw`absolute top-2 left-2 px-2 py-1 text-xs font-semibold rounded-md`}
    background: rgba(5, 10, 20, 0.8);
    border: 1px solid rgba(42, 74, 106, 0.8);
    color: #ffffff;
    backdrop-filter: blur(4px);
`;

const StatusBadge = styled.span<{ $status: ServerStatus }>`
    ${tw`absolute top-2 right-2 px-3 py-1 text-xs font-bold uppercase rounded-full flex items-center gap-1`}
    background: ${props => {
        switch(props.$status) {
            case 'online': return 'rgba(0, 255, 136, 0.2)';
            case 'offline': return 'rgba(255, 51, 102, 0.2)';
            case 'starting': return 'rgba(255, 204, 0, 0.2)';
            case 'stopping': return 'rgba(255, 107, 0, 0.2)';
            default: return 'rgba(90, 122, 154, 0.2)';
        }
    }};
    border: 1px solid ${props => {
        switch(props.$status) {
            case 'online': return '#00ff88';
            case 'offline': return '#ff3366';
            case 'starting': return '#ffcc00';
            case 'stopping': return '#ff6b00';
            default: return '#5a7a9a';
        }
    }};
    color: ${props => {
        switch(props.$status) {
            case 'online': return '#00ff88';
            case 'offline': return '#ff3366';
            case 'starting': return '#ffcc00';
            case 'stopping': return '#ff6b00';
            default: return '#5a7a9a';
        }
    }};
`;

const StatusDot = styled.span<{ $status: ServerStatus }>`
    ${tw`w-1.5 h-1.5 rounded-full`}
    background: currentColor;
    box-shadow: 0 0 6px currentColor;
    animation: ${props => props.$status === 'online' || props.$status === 'starting' ? pulse : 'none'} 2s ease-in-out infinite;
`;

const ContentSection = styled.div`
    ${tw`p-4`}
`;

const ServerName = styled.h3`
    ${tw`text-lg font-semibold truncate mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const ServerAddress = styled.div`
    ${tw`flex items-center gap-1 text-sm mb-3`}
    color: #5a7a9a;
    font-family: 'JetBrains Mono', monospace;
`;

const StatsRow = styled.div`
    ${tw`flex items-center gap-4 text-sm`}
    color: #a0b4c8;
`;

const StatItem = styled.span`
    ${tw`flex items-center gap-1`}

    svg {
        color: #5a7a9a;
    }
`;

const FooterSection = styled.div`
    ${tw`px-4 py-3 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-top: 1px solid rgba(26, 48, 80, 0.8);
`;

const Price = styled.span`
    ${tw`text-lg font-bold`}
    color: #00d4ff;
    font-family: 'Rajdhani', sans-serif;

    span {
        ${tw`text-sm font-normal`}
        color: #5a7a9a;
    }
`;

const ServerCard: React.FC<ServerCardProps> = ({
    uuid,
    name,
    status,
    game,
    image,
    ip,
    port,
    players,
    cpu,
    memory,
    price
}) => {
    const formatMemory = (mb: number): string => {
        if (mb >= 1024) return `${(mb / 1024).toFixed(1)}GB`;
        return `${mb}MB`;
    };

    return (
        <CardContainer to={`/server/${uuid}`} $status={status}>
            <ImageSection>
                {image ? (
                    <ServerImage src={image} alt={name} />
                ) : (
                    <div css={tw`w-full h-full flex items-center justify-center text-4xl`} style={{ color: '#2a4a6a' }}>
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                            <rect x="2" y="2" width="20" height="8" rx="2" ry="2"/>
                            <rect x="2" y="14" width="20" height="8" rx="2" ry="2"/>
                            <line x1="6" y1="6" x2="6.01" y2="6"/>
                            <line x1="6" y1="18" x2="6.01" y2="18"/>
                        </svg>
                    </div>
                )}
                <ImageOverlay />
                {game && <GameBadge>{game}</GameBadge>}
                <StatusBadge $status={status}>
                    <StatusDot $status={status} />
                    {status}
                </StatusBadge>
            </ImageSection>

            <ContentSection>
                <ServerName>{name}</ServerName>
                <ServerAddress>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <circle cx="12" cy="12" r="10"/>
                        <line x1="2" y1="12" x2="22" y2="12"/>
                        <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
                    </svg>
                    {ip}:{port}
                </ServerAddress>

                <StatsRow>
                    {players && (
                        <StatItem>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                                <circle cx="9" cy="7" r="4"/>
                                <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                                <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                            </svg>
                            {players.current}/{players.max}
                        </StatItem>
                    )}
                    {cpu !== undefined && (
                        <StatItem>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <rect x="4" y="4" width="16" height="16" rx="2"/>
                                <rect x="9" y="9" width="6" height="6"/>
                                <line x1="9" y1="1" x2="9" y2="4"/>
                                <line x1="15" y1="1" x2="15" y2="4"/>
                                <line x1="9" y1="20" x2="9" y2="23"/>
                                <line x1="15" y1="20" x2="15" y2="23"/>
                            </svg>
                            {cpu}%
                        </StatItem>
                    )}
                    {memory && (
                        <StatItem>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
                            </svg>
                            {formatMemory(memory.current)}
                        </StatItem>
                    )}
                </StatsRow>
            </ContentSection>

            {price !== undefined && (
                <FooterSection>
                    <Price>
                        €{price.toFixed(2)}<span>/month</span>
                    </Price>
                </FooterSection>
            )}
        </CardContainer>
    );
};

export default ServerCard;
