import React from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';

interface StatsCardProps {
    label: string;
    value: string | number;
    subtext?: string;
    icon: React.ReactNode;
    color: 'cyan' | 'green' | 'yellow' | 'purple' | 'red';
    progress?: number;
}

const CardContainer = styled.div<{ $color: string }>`
    ${tw`relative overflow-hidden rounded-xl p-5`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
    transition: all 0.3s ease;

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 3px;
        height: 100%;
        background: ${props => {
            switch(props.$color) {
                case 'cyan': return '#00d4ff';
                case 'green': return '#00ff88';
                case 'yellow': return '#ffcc00';
                case 'purple': return '#a855f7';
                case 'red': return '#ff3366';
                default: return '#00d4ff';
            }
        }};
        box-shadow: 0 0 15px ${props => {
            switch(props.$color) {
                case 'cyan': return 'rgba(0, 212, 255, 0.5)';
                case 'green': return 'rgba(0, 255, 136, 0.5)';
                case 'yellow': return 'rgba(255, 204, 0, 0.5)';
                case 'purple': return 'rgba(168, 85, 247, 0.5)';
                case 'red': return 'rgba(255, 51, 102, 0.5)';
                default: return 'rgba(0, 212, 255, 0.5)';
            }
        }};
    }

    &:hover {
        border-color: rgba(42, 74, 106, 0.8);
        transform: translateY(-2px);
    }
`;

const IconWrapper = styled.div<{ $color: string }>`
    ${tw`w-12 h-12 rounded-lg flex items-center justify-center text-2xl flex-shrink-0`}
    background: ${props => {
        switch(props.$color) {
            case 'cyan': return 'rgba(0, 212, 255, 0.15)';
            case 'green': return 'rgba(0, 255, 136, 0.15)';
            case 'yellow': return 'rgba(255, 204, 0, 0.15)';
            case 'purple': return 'rgba(168, 85, 247, 0.15)';
            case 'red': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(0, 212, 255, 0.15)';
        }
    }};
    border: 1px solid ${props => {
        switch(props.$color) {
            case 'cyan': return '#00d4ff';
            case 'green': return '#00ff88';
            case 'yellow': return '#ffcc00';
            case 'purple': return '#a855f7';
            case 'red': return '#ff3366';
            default: return '#00d4ff';
        }
    }};
    color: ${props => {
        switch(props.$color) {
            case 'cyan': return '#00d4ff';
            case 'green': return '#00ff88';
            case 'yellow': return '#ffcc00';
            case 'purple': return '#a855f7';
            case 'red': return '#ff3366';
            default: return '#00d4ff';
        }
    }};
`;

const Label = styled.span`
    ${tw`text-sm uppercase tracking-wide`}
    color: #5a7a9a;
    font-family: 'Rajdhani', sans-serif;
`;

const Value = styled.div`
    ${tw`text-2xl font-bold`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
    line-height: 1;
`;

const Subtext = styled.span`
    ${tw`text-xs mt-1`}
    color: #5a7a9a;
`;

const ProgressBar = styled.div<{ $color: string; $progress: number }>`
    ${tw`w-full h-1.5 rounded-full mt-4 overflow-hidden`}
    background: rgba(15, 31, 61, 0.8);

    &::after {
        content: '';
        display: block;
        height: 100%;
        width: ${props => props.$progress}%;
        border-radius: 9999px;
        background: ${props => {
            switch(props.$color) {
                case 'cyan': return '#00d4ff';
                case 'green': return '#00ff88';
                case 'yellow': return '#ffcc00';
                case 'purple': return '#a855f7';
                case 'red': return '#ff3366';
                default: return '#00d4ff';
            }
        }};
        box-shadow: 0 0 10px ${props => {
            switch(props.$color) {
                case 'cyan': return 'rgba(0, 212, 255, 0.5)';
                case 'green': return 'rgba(0, 255, 136, 0.5)';
                case 'yellow': return 'rgba(255, 204, 0, 0.5)';
                case 'purple': return 'rgba(168, 85, 247, 0.5)';
                case 'red': return 'rgba(255, 51, 102, 0.5)';
                default: return 'rgba(0, 212, 255, 0.5)';
            }
        }};
        transition: width 0.5s ease;
    }
`;

const StatsCard: React.FC<StatsCardProps> = ({
    label,
    value,
    subtext,
    icon,
    color,
    progress
}) => {
    return (
        <CardContainer $color={color}>
            <div css={tw`flex items-start gap-4`}>
                <IconWrapper $color={color}>
                    {icon}
                </IconWrapper>
                <div css={tw`flex-1`}>
                    <Label>{label}</Label>
                    <Value>{value}</Value>
                    {subtext && <Subtext>{subtext}</Subtext>}
                </div>
            </div>
            {progress !== undefined && (
                <ProgressBar $color={color} $progress={progress} />
            )}
        </CardContainer>
    );
};

export default StatsCard;
