import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineShoppingCart, HiOutlineCheck, HiOutlineStar, HiOutlineServer, HiOutlineChip, HiOutlineDatabase } from 'react-icons/hi';

interface Plan {
    id: string;
    name: string;
    description: string;
    price: number;
    period: 'monthly' | 'yearly';
    features: string[];
    popular?: boolean;
    resources: {
        cpu: number;
        memory: number;
        disk: number;
    };
    game?: string;
}

interface GameCategory {
    id: string;
    name: string;
    icon: string;
    plans: Plan[];
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden text-center`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #00d4ff, #a855f7, #00ff88, #00d4ff);
    }
`;

const PageTitle = styled.h1`
    ${tw`text-3xl font-bold mb-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm max-w-xl mx-auto`}
    color: #5a7a9a;
`;

const TabsContainer = styled.div`
    ${tw`flex gap-2 p-1.5 rounded-xl mx-auto w-fit`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const Tab = styled.button<{ $active?: boolean }>`
    ${tw`px-6 py-2.5 rounded-lg font-semibold text-sm uppercase tracking-wide flex items-center gap-2`}
    background: ${props => props.$active ? 'linear-gradient(135deg, #00d4ff 0%, #a855f7 100%)' : 'transparent'};
    color: ${props => props.$active ? '#ffffff' : '#5a7a9a'};
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        color: #ffffff;
    }
`;

const PlansGrid = styled.div`
    ${tw`grid gap-6`}
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
`;

const PlanCard = styled.div<{ $popular?: boolean }>`
    ${tw`rounded-xl overflow-hidden relative`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 2px solid ${props => props.$popular ? '#a855f7' : 'rgba(26, 48, 80, 0.8)'};
    transition: all 0.3s ease;

    ${props => props.$popular && `
        &::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #a855f7, #00d4ff, #a855f7);
        }
    `}

    &:hover {
        transform: translateY(-8px);
        border-color: ${props => props.$popular ? '#a855f7' : '#00d4ff'};
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
    }
`;

const PopularBadge = styled.div`
    ${tw`absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-bold uppercase flex items-center gap-1`}
    background: linear-gradient(135deg, #a855f7 0%, #00d4ff 100%);
    color: #ffffff;
`;

const PlanHeader = styled.div`
    ${tw`p-6 text-center`}
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const PlanName = styled.h3`
    ${tw`text-2xl font-bold mb-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PlanDescription = styled.p`
    ${tw`text-sm mb-4`}
    color: #5a7a9a;
`;

const PlanPrice = styled.div`
    ${tw`mb-2`}
`;

const PriceAmount = styled.span`
    ${tw`text-4xl font-bold`}
    color: #00ff88;
    font-family: 'Rajdhani', sans-serif;
`;

const PricePeriod = styled.span`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const PlanResources = styled.div`
    ${tw`flex justify-center gap-4 mt-4`}
`;

const ResourceItem = styled.div`
    ${tw`text-center`}
`;

const ResourceIcon = styled.div<{ $color: string }>`
    ${tw`w-10 h-10 rounded-lg flex items-center justify-center mx-auto mb-1`}
    background: ${props => `${props.$color}15`};
    color: ${props => props.$color};
`;

const ResourceValue = styled.span`
    ${tw`text-sm font-bold block`}
    color: #ffffff;
`;

const ResourceLabel = styled.span`
    ${tw`text-xs`}
    color: #5a7a9a;
`;

const PlanBody = styled.div`
    ${tw`p-6`}
`;

const FeatureList = styled.ul`
    ${tw`flex flex-col gap-3 mb-6`}
`;

const FeatureItem = styled.li`
    ${tw`flex items-center gap-3 text-sm`}
    color: #a0b4c8;
`;

const FeatureCheck = styled.span<{ $included: boolean }>`
    ${tw`w-5 h-5 rounded-full flex items-center justify-center text-xs`}
    background: ${props => props.$included ? 'rgba(0, 255, 136, 0.15)' : 'rgba(90, 122, 154, 0.15)'};
    color: ${props => props.$included ? '#00ff88' : '#5a7a9a'};
`;

const OrderButton = styled.button<{ $popular?: boolean }>`
    ${tw`w-full py-3 rounded-lg font-bold uppercase tracking-wide flex items-center justify-center gap-2`}
    background: ${props => props.$popular
        ? 'linear-gradient(135deg, #a855f7 0%, #00d4ff 100%)'
        : 'linear-gradient(135deg, #00ff88 0%, #00d4ff 100%)'};
    color: ${props => props.$popular ? '#ffffff' : '#050a14'};
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px ${props => props.$popular ? 'rgba(168, 85, 247, 0.3)' : 'rgba(0, 255, 136, 0.3)'};
    }
`;

const GameFilter = styled.div`
    ${tw`flex flex-wrap gap-2 justify-center mb-6`}
`;

const GameButton = styled.button<{ $active?: boolean }>`
    ${tw`px-4 py-2 rounded-lg font-semibold text-sm flex items-center gap-2`}
    background: ${props => props.$active ? 'rgba(0, 212, 255, 0.15)' : 'rgba(26, 48, 80, 0.5)'};
    border: 1px solid ${props => props.$active ? '#00d4ff' : 'rgba(26, 48, 80, 0.8)'};
    color: ${props => props.$active ? '#00d4ff' : '#5a7a9a'};
    cursor: pointer;
    transition: all 0.3s ease;

    &:hover {
        border-color: #00d4ff;
        color: #00d4ff;
    }
`;

// Mock data
const mockPlans: Plan[] = [
    {
        id: '1',
        name: 'Starter',
        description: 'Perfect for small communities',
        price: 5.99,
        period: 'monthly',
        resources: { cpu: 100, memory: 2048, disk: 10240 },
        features: ['24/7 Support', 'DDoS Protection', 'Daily Backups', 'Custom Domain'],
        game: 'minecraft'
    },
    {
        id: '2',
        name: 'Pro',
        description: 'For growing servers',
        price: 14.99,
        period: 'monthly',
        resources: { cpu: 200, memory: 4096, disk: 25600 },
        features: ['24/7 Priority Support', 'DDoS Protection', 'Hourly Backups', 'Custom Domain', 'Plugin Manager', 'Mod Support'],
        popular: true,
        game: 'minecraft'
    },
    {
        id: '3',
        name: 'Elite',
        description: 'Maximum performance',
        price: 29.99,
        period: 'monthly',
        resources: { cpu: 400, memory: 8192, disk: 51200 },
        features: ['24/7 Priority Support', 'DDoS Protection', 'Real-time Backups', 'Custom Domain', 'Plugin Manager', 'Mod Support', 'Dedicated Resources', 'Custom Startup'],
        game: 'minecraft'
    },
    {
        id: '4',
        name: 'Ultimate',
        description: 'Enterprise solution',
        price: 59.99,
        period: 'monthly',
        resources: { cpu: 800, memory: 16384, disk: 102400 },
        features: ['24/7 Dedicated Support', 'Advanced DDoS Protection', 'Real-time Backups', 'Multiple Domains', 'Plugin Manager', 'Mod Support', 'Dedicated Resources', 'Custom Startup', 'API Access', 'SLA Guarantee'],
        game: 'minecraft'
    },
];

const StorePlans: React.FC = () => {
    const [selectedGame, setSelectedGame] = useState('all');
    const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'yearly'>('monthly');

    const games = ['all', 'minecraft', 'fivem', 'cs2', 'ark', '7d2d'];

    const filteredPlans = selectedGame === 'all'
        ? mockPlans
        : mockPlans.filter(p => p.game === selectedGame);

    const formatMemory = (mb: number): string => {
        if (mb >= 1024) return `${(mb / 1024).toFixed(0)} GB`;
        return `${mb} MB`;
    };

    const formatDisk = (mb: number): string => {
        if (mb >= 1024) return `${(mb / 1024).toFixed(0)} GB`;
        return `${mb} MB`;
    };

    return (
        <Container>
            <PageHeader>
                <PageTitle>Game Server Hosting</PageTitle>
                <PageSubtitle>
                    High-performance game servers with instant setup, DDoS protection, and 24/7 support.
                    Choose your game and get started in minutes!
                </PageSubtitle>
            </PageHeader>

            <TabsContainer>
                <Tab $active={billingPeriod === 'monthly'} onClick={() => setBillingPeriod('monthly')}>
                    Monthly
                </Tab>
                <Tab $active={billingPeriod === 'yearly'} onClick={() => setBillingPeriod('yearly')}>
                    Yearly <span css={tw`text-xs px-1.5 py-0.5 rounded`} style={{ background: '#00ff88', color: '#050a14' }}>-20%</span>
                </Tab>
            </TabsContainer>

            <GameFilter>
                {games.map(game => (
                    <GameButton
                        key={game}
                        $active={selectedGame === game}
                        onClick={() => setSelectedGame(game)}
                    >
                        <HiOutlineServer />
                        {game === 'all' ? 'All Games' : game.toUpperCase()}
                    </GameButton>
                ))}
            </GameFilter>

            <PlansGrid>
                {filteredPlans.map(plan => (
                    <PlanCard key={plan.id} $popular={plan.popular}>
                        {plan.popular && (
                            <PopularBadge>
                                <HiOutlineStar /> Most Popular
                            </PopularBadge>
                        )}
                        <PlanHeader>
                            <PlanName>{plan.name}</PlanName>
                            <PlanDescription>{plan.description}</PlanDescription>
                            <PlanPrice>
                                <PriceAmount>
                                    €{billingPeriod === 'yearly'
                                        ? (plan.price * 12 * 0.8).toFixed(2)
                                        : plan.price.toFixed(2)}
                                </PriceAmount>
                                <PricePeriod>/{billingPeriod === 'yearly' ? 'year' : 'month'}</PricePeriod>
                            </PlanPrice>
                            <PlanResources>
                                <ResourceItem>
                                    <ResourceIcon $color="#ffcc00">
                                        <HiOutlineChip />
                                    </ResourceIcon>
                                    <ResourceValue>{plan.resources.cpu}%</ResourceValue>
                                    <ResourceLabel>CPU</ResourceLabel>
                                </ResourceItem>
                                <ResourceItem>
                                    <ResourceIcon $color="#00ff88">
                                        <HiOutlineServer />
                                    </ResourceIcon>
                                    <ResourceValue>{formatMemory(plan.resources.memory)}</ResourceValue>
                                    <ResourceLabel>RAM</ResourceLabel>
                                </ResourceItem>
                                <ResourceItem>
                                    <ResourceIcon $color="#a855f7">
                                        <HiOutlineDatabase />
                                    </ResourceIcon>
                                    <ResourceValue>{formatDisk(plan.resources.disk)}</ResourceValue>
                                    <ResourceLabel>Disk</ResourceLabel>
                                </ResourceItem>
                            </PlanResources>
                        </PlanHeader>
                        <PlanBody>
                            <FeatureList>
                                {plan.features.map((feature, index) => (
                                    <FeatureItem key={index}>
                                        <FeatureCheck $included={true}>
                                            <HiOutlineCheck />
                                        </FeatureCheck>
                                        {feature}
                                    </FeatureItem>
                                ))}
                            </FeatureList>
                            <OrderButton $popular={plan.popular}>
                                <HiOutlineShoppingCart /> Order Now
                            </OrderButton>
                        </PlanBody>
                    </PlanCard>
                ))}
            </PlansGrid>
        </Container>
    );
};

export default StorePlans;
