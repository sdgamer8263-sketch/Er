import React, { useState } from 'react';
import tw from 'twin.macro';
import styled from 'styled-components';
import { HiOutlineCreditCard, HiOutlineDocumentText, HiOutlineShoppingCart, HiOutlineCurrencyDollar, HiOutlineTag, HiOutlinePlus, HiOutlineDownload, HiOutlineCheck, HiOutlineClock, HiOutlineExclamation } from 'react-icons/hi';

interface Invoice {
    id: string;
    number: string;
    amount: number;
    status: 'paid' | 'pending' | 'overdue' | 'cancelled';
    dueDate: string;
    paidAt: string | null;
    items: string[];
}

interface Plan {
    id: string;
    name: string;
    description: string;
    price: number;
    period: 'monthly' | 'yearly';
    features: string[];
    popular?: boolean;
    resources: {
        cpu: number;
        memory: number;
        disk: number;
    };
}

interface PaymentMethod {
    id: string;
    type: 'card' | 'paypal';
    last4?: string;
    brand?: string;
    email?: string;
    isDefault: boolean;
}

const Container = styled.div`
    ${tw`flex flex-col gap-6`}
`;

const PageHeader = styled.div`
    ${tw`p-6 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, #00ff88, #00d4ff, #00ff88);
    }
`;

const HeaderContent = styled.div`
    ${tw`flex items-center justify-between`}
`;

const PageTitle = styled.h1`
    ${tw`text-2xl font-bold mb-1`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const PageSubtitle = styled.p`
    ${tw`text-sm`}
    color: #5a7a9a;
`;

const HeaderActions = styled.div`
    ${tw`flex gap-3`}
`;

const PrimaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: linear-gradient(135deg, #00ff88 0%, #00d4ff 100%);
    color: #050a14;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 255, 136, 0.3);
    }
`;

const SecondaryButton = styled.button`
    ${tw`px-5 py-2.5 rounded-lg font-semibold uppercase tracking-wide flex items-center gap-2 text-sm`}
    background: rgba(26, 48, 80, 0.5);
    color: #a0b4c8;
    border: 1px solid rgba(26, 48, 80, 0.8);
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #00d4ff;
        color: #00d4ff;
    }
`;

const StatsGrid = styled.div`
    ${tw`grid gap-4`}
    grid-template-columns: repeat(4, 1fr);

    @media (max-width: 1000px) {
        grid-template-columns: repeat(2, 1fr);
    }
`;

const StatCard = styled.div<{ $color: string }>`
    ${tw`p-4 rounded-xl relative overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);

    &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 3px;
        height: 100%;
        background: ${props => props.$color};
    }
`;

const StatLabel = styled.span`
    ${tw`text-xs uppercase tracking-wide block mb-1`}
    color: #5a7a9a;
`;

const StatValue = styled.span<{ $color: string }>`
    ${tw`text-2xl font-bold`}
    color: ${props => props.$color};
    font-family: 'Rajdhani', sans-serif;
`;

const ContentGrid = styled.div`
    ${tw`grid gap-6`}
    grid-template-columns: 1fr 400px;

    @media (max-width: 1200px) {
        grid-template-columns: 1fr;
    }
`;

const Card = styled.div`
    ${tw`rounded-xl overflow-hidden`}
    background: linear-gradient(145deg, rgba(15, 31, 61, 0.8) 0%, rgba(10, 22, 40, 0.9) 100%);
    border: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardHeader = styled.div`
    ${tw`px-5 py-4 flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border-bottom: 1px solid rgba(26, 48, 80, 0.8);
`;

const CardTitle = styled.h3`
    ${tw`text-sm font-semibold uppercase tracking-wide flex items-center gap-2`}
    color: #ffffff;
    font-family: 'Rajdhani', sans-serif;
`;

const CardBody = styled.div`
    ${tw`p-5`}
`;

const InvoiceList = styled.div`
    ${tw`flex flex-col gap-3`}
`;

const InvoiceItem = styled.div`
    ${tw`p-4 rounded-xl flex items-center justify-between`}
    background: rgba(15, 31, 61, 0.5);
    border: 1px solid rgba(26, 48, 80, 0.6);
    transition: all 0.3s ease;

    &:hover {
        border-color: rgba(42, 74, 106, 0.8);
    }
`;

const InvoiceInfo = styled.div`
    ${tw`flex items-center gap-3`}
`;

const InvoiceIcon = styled.div<{ $status: string }>`
    ${tw`w-10 h-10 rounded-lg flex items-center justify-center text-lg`}
    background: ${props => {
        switch(props.$status) {
            case 'paid': return 'rgba(0, 255, 136, 0.15)';
            case 'pending': return 'rgba(255, 204, 0, 0.15)';
            case 'overdue': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$status) {
            case 'paid': return '#00ff88';
            case 'pending': return '#ffcc00';
            case 'overdue': return '#ff3366';
            default: return '#5a7a9a';
        }
    }};
`;

const InvoiceDetails = styled.div``;

const InvoiceNumber = styled.h4`
    ${tw`text-sm font-semibold`}
    color: #ffffff;
`;

const InvoiceMeta = styled.div`
    ${tw`flex items-center gap-2 text-xs mt-1`}
    color: #5a7a9a;
`;

const StatusBadge = styled.span<{ $status: string }>`
    ${tw`px-2 py-0.5 rounded text-xs uppercase font-bold`}
    background: ${props => {
        switch(props.$status) {
            case 'paid': return 'rgba(0, 255, 136, 0.15)';
            case 'pending': return 'rgba(255, 204, 0, 0.15)';
            case 'overdue': return 'rgba(255, 51, 102, 0.15)';
            default: return 'rgba(90, 122, 154, 0.15)';
        }
    }};
    color: ${props => {
        switch(props.$status) {
            case 'paid': return '#00ff88';
            case 'pending': return '#ffcc00';
            case 'overdue': return '#ff3366';
            default: return '#5a7a9a';
        }
    }};
`;

const InvoiceAmount = styled.span`
    ${tw`text-lg font-bold`}
    color: #00ff88;
    font-family: 'Rajdhani', sans-serif;
`;

const PaymentMethodCard = styled.div<{ $default: boolean }>`
    ${tw`p-4 rounded-xl flex items-center justify-between mb-3`}
    background: rgba(15, 31, 61, 0.5);
    border: 2px solid ${props => props.$default ? '#00d4ff' : 'rgba(26, 48, 80, 0.6)'};
`;

const PaymentInfo = styled.div`
    ${tw`flex items-center gap-3`}
`;

const PaymentIcon = styled.div<{ $type: string }>`
    ${tw`w-12 h-8 rounded flex items-center justify-center text-sm font-bold`}
    background: ${props => props.$type === 'card' ? '#1a1f71' : '#003087'};
    color: #ffffff;
`;

const PaymentDetails = styled.div``;

const PaymentName = styled.h4`
    ${tw`text-sm font-semibold`}
    color: #ffffff;
`;

const PaymentSub = styled.span`
    ${tw`text-xs`}
    color: #5a7a9a;
`;

const DefaultBadge = styled.span`
    ${tw`px-2 py-1 rounded text-xs uppercase font-bold`}
    background: rgba(0, 212, 255, 0.15);
    color: #00d4ff;
`;

const AddPaymentButton = styled.button`
    ${tw`w-full py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2`}
    background: rgba(26, 48, 80, 0.3);
    border: 2px dashed rgba(26, 48, 80, 0.8);
    color: #5a7a9a;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;
    transition: all 0.3s ease;

    &:hover {
        border-color: #00d4ff;
        color: #00d4ff;
    }
`;

const CouponSection = styled.div`
    ${tw`mt-4 p-4 rounded-xl`}
    background: rgba(168, 85, 247, 0.1);
    border: 1px solid rgba(168, 85, 247, 0.3);
`;

const CouponInput = styled.div`
    ${tw`flex gap-2`}
`;

const Input = styled.input`
    ${tw`flex-1 px-4 py-2 rounded-lg text-sm`}
    background: rgba(5, 10, 20, 0.8);
    border: 1px solid rgba(26, 48, 80, 0.8);
    color: #ffffff;

    &:focus {
        outline: none;
        border-color: #a855f7;
    }

    &::placeholder {
        color: #5a7a9a;
    }
`;

const ApplyButton = styled.button`
    ${tw`px-4 py-2 rounded-lg font-semibold text-sm`}
    background: linear-gradient(135deg, #a855f7 0%, #00d4ff 100%);
    color: #ffffff;
    border: none;
    cursor: pointer;
    font-family: 'Rajdhani', sans-serif;

    &:hover {
        transform: translateY(-1px);
    }
`;

// Mock data
const mockInvoices: Invoice[] = [
    { id: '1', number: 'INV-2024-0042', amount: 25.00, status: 'pending', dueDate: '2024-01-25', paidAt: null, items: ['Minecraft Server - Pro Plan'] },
    { id: '2', number: 'INV-2024-0041', amount: 35.00, status: 'paid', dueDate: '2024-01-15', paidAt: '2024-01-14', items: ['FiveM Server - Elite Plan'] },
    { id: '3', number: 'INV-2024-0040', amount: 15.00, status: 'paid', dueDate: '2024-01-01', paidAt: '2023-12-30', items: ['CS2 Server - Basic Plan'] },
    { id: '4', number: 'INV-2024-0039', amount: 45.00, status: 'overdue', dueDate: '2024-01-10', paidAt: null, items: ['ARK Cluster - 3 Servers'] },
];

const mockPaymentMethods: PaymentMethod[] = [
    { id: '1', type: 'card', last4: '4242', brand: 'Visa', isDefault: true },
    { id: '2', type: 'paypal', email: 'user@example.com', isDefault: false },
];

const BillingDashboard: React.FC = () => {
    const [invoices] = useState<Invoice[]>(mockInvoices);
    const [paymentMethods] = useState<PaymentMethod[]>(mockPaymentMethods);

    const totalDue = invoices.filter(i => i.status !== 'paid').reduce((acc, i) => acc + i.amount, 0);
    const totalPaid = invoices.filter(i => i.status === 'paid').reduce((acc, i) => acc + i.amount, 0);
    const pendingCount = invoices.filter(i => i.status === 'pending').length;
    const overdueCount = invoices.filter(i => i.status === 'overdue').length;

    return (
        <Container>
            <PageHeader>
                <HeaderContent>
                    <div>
                        <PageTitle>Billing & Payments</PageTitle>
                        <PageSubtitle>Manage your invoices, payment methods, and subscriptions</PageSubtitle>
                    </div>
                    <HeaderActions>
                        <SecondaryButton>
                            <HiOutlineDownload /> Download Statement
                        </SecondaryButton>
                        <PrimaryButton>
                            <HiOutlineShoppingCart /> Browse Plans
                        </PrimaryButton>
                    </HeaderActions>
                </HeaderContent>
            </PageHeader>

            <StatsGrid>
                <StatCard $color="#ffcc00">
                    <StatLabel>Amount Due</StatLabel>
                    <StatValue $color="#ffcc00">€{totalDue.toFixed(2)}</StatValue>
                </StatCard>
                <StatCard $color="#00ff88">
                    <StatLabel>Paid This Month</StatLabel>
                    <StatValue $color="#00ff88">€{totalPaid.toFixed(2)}</StatValue>
                </StatCard>
                <StatCard $color="#00d4ff">
                    <StatLabel>Pending Invoices</StatLabel>
                    <StatValue $color="#00d4ff">{pendingCount}</StatValue>
                </StatCard>
                <StatCard $color="#ff3366">
                    <StatLabel>Overdue</StatLabel>
                    <StatValue $color="#ff3366">{overdueCount}</StatValue>
                </StatCard>
            </StatsGrid>

            <ContentGrid>
                <Card>
                    <CardHeader>
                        <CardTitle>
                            <HiOutlineDocumentText /> Recent Invoices
                        </CardTitle>
                        <SecondaryButton css={tw`py-1.5 px-3 text-xs`}>
                            View All
                        </SecondaryButton>
                    </CardHeader>
                    <CardBody>
                        <InvoiceList>
                            {invoices.map(invoice => (
                                <InvoiceItem key={invoice.id}>
                                    <InvoiceInfo>
                                        <InvoiceIcon $status={invoice.status}>
                                            {invoice.status === 'paid' && <HiOutlineCheck />}
                                            {invoice.status === 'pending' && <HiOutlineClock />}
                                            {invoice.status === 'overdue' && <HiOutlineExclamation />}
                                        </InvoiceIcon>
                                        <InvoiceDetails>
                                            <InvoiceNumber>{invoice.number}</InvoiceNumber>
                                            <InvoiceMeta>
                                                <span>{invoice.items[0]}</span>
                                                <span>•</span>
                                                <span>Due: {invoice.dueDate}</span>
                                                <StatusBadge $status={invoice.status}>{invoice.status}</StatusBadge>
                                            </InvoiceMeta>
                                        </InvoiceDetails>
                                    </InvoiceInfo>
                                    <InvoiceAmount>€{invoice.amount.toFixed(2)}</InvoiceAmount>
                                </InvoiceItem>
                            ))}
                        </InvoiceList>
                    </CardBody>
                </Card>

                <div css={tw`flex flex-col gap-4`}>
                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineCreditCard /> Payment Methods
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            {paymentMethods.map(method => (
                                <PaymentMethodCard key={method.id} $default={method.isDefault}>
                                    <PaymentInfo>
                                        <PaymentIcon $type={method.type}>
                                            {method.type === 'card' ? method.brand?.toUpperCase() : 'PP'}
                                        </PaymentIcon>
                                        <PaymentDetails>
                                            <PaymentName>
                                                {method.type === 'card'
                                                    ? `${method.brand} •••• ${method.last4}`
                                                    : 'PayPal'}
                                            </PaymentName>
                                            <PaymentSub>
                                                {method.type === 'card' ? 'Credit Card' : method.email}
                                            </PaymentSub>
                                        </PaymentDetails>
                                    </PaymentInfo>
                                    {method.isDefault && <DefaultBadge>Default</DefaultBadge>}
                                </PaymentMethodCard>
                            ))}
                            <AddPaymentButton>
                                <HiOutlinePlus /> Add Payment Method
                            </AddPaymentButton>
                        </CardBody>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>
                                <HiOutlineTag /> Have a Coupon?
                            </CardTitle>
                        </CardHeader>
                        <CardBody>
                            <CouponSection>
                                <CouponInput>
                                    <Input type="text" placeholder="Enter coupon code..." />
                                    <ApplyButton>Apply</ApplyButton>
                                </CouponInput>
                            </CouponSection>
                        </CardBody>
                    </Card>
                </div>
            </ContentGrid>
        </Container>
    );
};

export default BillingDashboard;
